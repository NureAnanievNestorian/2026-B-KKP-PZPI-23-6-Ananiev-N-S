package com.nestorian87.eter.data.repository

import com.google.common.truth.Truth.assertThat
import com.nestorian87.eter.domain.util.ProfileAvatarUpload
import org.junit.jupiter.api.Test
import java.io.File
import kotlin.io.path.createTempDirectory

class ProfileAvatarUploadTest {
    @Test
    fun `detectMediaType returns jpeg for tmp file with jpeg header`() {
        val file = createTempFile(name = "avatar.tmp").apply {
            writeBytes(byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0x00))
        }

        val mediaType = ProfileAvatarUpload.detectMediaType(file)

        assertThat(mediaType).isEqualTo("image/jpeg")
    }

    @Test
    fun `detectMediaType returns png for png header`() {
        val file = createTempFile(name = "avatar.tmp").apply {
            writeBytes(
                byteArrayOf(
                    0x89.toByte(),
                    0x50.toByte(),
                    0x4E.toByte(),
                    0x47.toByte(),
                    0x0D.toByte(),
                    0x0A.toByte(),
                    0x1A.toByte(),
                    0x0A.toByte(),
                )
            )
        }

        val mediaType = ProfileAvatarUpload.detectMediaType(file)

        assertThat(mediaType).isEqualTo("image/png")
    }

    @Test
    fun `resolveFileSuffix prefers content type over display name`() {
        val suffix = ProfileAvatarUpload.resolveFileSuffix(
            contentType = "image/webp",
            displayName = "avatar.jpeg",
        )

        assertThat(suffix).isEqualTo(".webp")
    }

    @Test
    fun `resolveFileSuffix falls back to supported display name extension`() {
        val suffix = ProfileAvatarUpload.resolveFileSuffix(
            contentType = null,
            displayName = "avatar.png",
        )

        assertThat(suffix).isEqualTo(".png")
    }

    private fun createTempFile(name: String): File {
        val directory = createTempDirectory().toFile()
        return File(directory, name)
    }
}
