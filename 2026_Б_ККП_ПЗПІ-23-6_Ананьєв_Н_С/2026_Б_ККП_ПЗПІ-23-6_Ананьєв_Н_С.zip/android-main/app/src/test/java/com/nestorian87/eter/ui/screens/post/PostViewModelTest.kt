package com.nestorian87.eter.ui.screens.post

import com.google.common.truth.Truth.assertThat
import com.nestorian87.eter.domain.model.PostCommentDraft
import org.junit.jupiter.api.Test

class PostViewModelTest {
    @Test
    fun `toRestoredUiState opens reply composer when reply draft exists`() {
        val restoredState = PostCommentDraft(
            postId = 42L,
            commentText = "general draft",
            replyDraftByCommentId = linkedMapOf(
                11L to "reply draft",
            ),
        ).toRestoredUiState(maxCommentLength = 5000)

        assertThat(restoredState.composerText).isEqualTo("general draft")
        assertThat(restoredState.openReplyComposerCommentId).isEqualTo(11L)
        assertThat(restoredState.replyDraftByCommentId).containsExactly(11L, "reply draft")
    }

    @Test
    fun `toRestoredUiState ignores blank reply drafts when restoring reply state`() {
        val restoredState = PostCommentDraft(
            postId = 42L,
            commentText = "general draft",
            replyDraftByCommentId = linkedMapOf(
                11L to "",
                12L to "reply draft",
            ),
        ).toRestoredUiState(maxCommentLength = 5000)

        assertThat(restoredState.openReplyComposerCommentId).isEqualTo(12L)
        assertThat(restoredState.replyDraftByCommentId).containsExactly(12L, "reply draft")
    }
}
