package com.nestorian87.eter.service

import com.google.common.truth.Truth.assertThat
import org.junit.jupiter.api.Test

class PushNotificationPayloadTest {
    @Test
    fun `from prefers data title and description`() {
        val payload = PushNotificationPayload.from(
            data = mapOf(
                "title" to "Data title",
                "desription" to "Data description",
            ),
            fallbackTitle = "Notification title",
            fallbackDescription = "Notification description",
        )

        assertThat(payload).isEqualTo(
            PushNotificationPayload(
                title = "Data title",
                description = "Data description",
            ),
        )
    }

    @Test
    fun `from falls back to notification fields when data fields are blank`() {
        val payload = PushNotificationPayload.from(
            data = mapOf(
                "title" to " ",
                "desription" to "",
            ),
            fallbackTitle = "Notification title",
            fallbackDescription = "Notification description",
        )

        assertThat(payload).isEqualTo(
            PushNotificationPayload(
                title = "Notification title",
                description = "Notification description",
            ),
        )
    }

    @Test
    fun `from returns null when title or description is missing`() {
        val payload = PushNotificationPayload.from(
            data = mapOf("title" to "Only title"),
        )

        assertThat(payload).isNull()
    }

    @Test
    fun `from supports legacy description key`() {
        val payload = PushNotificationPayload.from(
            data = mapOf(
                "title" to "Legacy title",
                "description" to "Legacy description",
            ),
        )

        assertThat(payload).isEqualTo(
            PushNotificationPayload(
                title = "Legacy title",
                description = "Legacy description",
            ),
        )
    }
}
