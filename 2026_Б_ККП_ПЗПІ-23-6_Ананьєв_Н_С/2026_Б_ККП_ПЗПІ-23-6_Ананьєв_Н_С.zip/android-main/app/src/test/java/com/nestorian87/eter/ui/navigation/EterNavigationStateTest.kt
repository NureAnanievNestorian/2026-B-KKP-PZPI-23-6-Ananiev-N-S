package com.nestorian87.eter.ui.navigation

import androidx.navigation3.runtime.NavBackStack
import androidx.navigation3.runtime.NavKey
import com.google.common.truth.Truth.assertThat
import org.junit.jupiter.api.Test

class EterNavigationStateTest {
    @Test
    fun `showMain repopulates feed stack before enabling authenticated navigation`() {
        val state = createNavigationState(initialAuthenticated = false)

        state.showAuth()
        state.showMain()

        assertThat(state.isAuthenticated).isTrue()
        assertThat(state.currentBackStack).isNotEmpty()
        assertThat(state.currentBackStack.last()).isEqualTo(FeedKey)
    }

    @Test
    fun `showAuth repopulates auth stack before switching away from main`() {
        val state = createNavigationState(initialAuthenticated = true)

        state.showAuth()

        assertThat(state.isAuthenticated).isFalse()
        assertThat(state.currentBackStack).isNotEmpty()
        assertThat(state.currentBackStack.last()).isEqualTo(LoginKey)
    }

    @Test
    fun `currentBackStack restores missing active main root on access`() {
        val state = createNavigationState(initialAuthenticated = true)
        state.mainBackStacks.getValue(TopLevelDestination.FEED).clear()

        val currentBackStack = state.currentBackStack

        assertThat(currentBackStack).isNotEmpty()
        assertThat(currentBackStack.last()).isEqualTo(FeedKey)
    }

    @Test
    fun `currentBackStack restores missing auth root on access`() {
        val state = createNavigationState(initialAuthenticated = false)
        state.authBackStack.clear()

        val currentBackStack = state.currentBackStack

        assertThat(currentBackStack).isNotEmpty()
        assertThat(currentBackStack.last()).isEqualTo(LoginKey)
    }

    private fun createNavigationState(initialAuthenticated: Boolean): EterNavigationState =
        EterNavigationState(
            initialAuthenticated = initialAuthenticated,
            authBackStack = NavBackStack(LoginKey),
            mainBackStacks = mapOf(
                TopLevelDestination.FEED to NavBackStack<NavKey>(FeedKey),
                TopLevelDestination.SEARCH to NavBackStack<NavKey>(SearchKey),
                TopLevelDestination.SUBSCRIPTIONS to NavBackStack<NavKey>(SubscriptionsKey),
                TopLevelDestination.CREATE to NavBackStack<NavKey>(CreateKey()),
                TopLevelDestination.FAVORITES to NavBackStack<NavKey>(FavoritesKey),
                TopLevelDestination.PROFILE to NavBackStack<NavKey>(ProfileKey),
            ),
        )
}
