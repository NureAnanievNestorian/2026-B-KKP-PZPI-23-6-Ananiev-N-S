package com.nestorian87.eter.ui.screens.postsynchronization

import com.google.common.truth.Truth.assertThat
import com.nestorian87.eter.domain.model.PostTextSynchronization
import org.junit.jupiter.api.Test

class PostSynchronizationModelsTest {
    @Test
    fun `buildSyncableLines preserves original line indices and locks first line zero`() {
        val lines = buildSyncableLines(
            """
            First line

            Third line
            """.trimIndent(),
        )

        assertThat(lines.map { it.lineIndex }).containsExactly(0, 2).inOrder()
        assertThat(lines.first().isLocked).isTrue()
        assertThat(lines.last().isLocked).isFalse()
    }

    @Test
    fun `buildSyncableLines locks first syncable line after leading blanks`() {
        val lines = buildSyncableLines(
            """


            First line
            Second line
            """.trimIndent(),
        )

        assertThat(lines.map { it.lineIndex }).containsExactly(2, 3).inOrder()
        assertThat(lines.first().isLocked).isTrue()
        assertThat(lines.last().isLocked).isFalse()
    }

    @Test
    fun `seedSynchronization preserves locked first line at zero`() {
        val syncableLines = buildSyncableLines("First line\nSecond line")

        val seeded = seedSynchronization(
            initialSynchronization = listOf(
                PostTextSynchronization(lineIndex = 0, audioStartMomentMs = 1_240),
                PostTextSynchronization(lineIndex = 1, audioStartMomentMs = 2_100),
            ),
            syncableLines = syncableLines,
        )

        assertThat(seeded[0]).isEqualTo(0)
        assertThat(seeded[1]).isEqualTo(2_100)
    }

    @Test
    fun `seedSynchronization preserves first syncable line at zero after leading blanks`() {
        val syncableLines = buildSyncableLines("\n\nFirst line\nSecond line")

        val seeded = seedSynchronization(
            initialSynchronization = listOf(
                PostTextSynchronization(lineIndex = 2, audioStartMomentMs = 1_240),
                PostTextSynchronization(lineIndex = 3, audioStartMomentMs = 2_100),
            ),
            syncableLines = syncableLines,
        )

        assertThat(seeded[2]).isEqualTo(0)
        assertThat(seeded[3]).isEqualTo(2_100)
    }

    @Test
    fun `validateSynchronization flags missing only when requested`() {
        val syncableLines = buildSyncableLines("First\nSecond")

        val withoutMissing = validateSynchronization(
            syncableLines = syncableLines,
            localSynchronization = mapOf(0 to 0),
            durationSeconds = 10,
            includeMissing = false,
        )
        val withMissing = validateSynchronization(
            syncableLines = syncableLines,
            localSynchronization = mapOf(0 to 0),
            durationSeconds = 10,
            includeMissing = true,
        )

        assertThat(withoutMissing).isEmpty()
        assertThat(withMissing[1]?.kind).isEqualTo(PostSynchronizationValidationKind.MISSING)
    }

    @Test
    fun `validateSynchronization requires strictly increasing timestamps`() {
        val syncableLines = buildSyncableLines("First\nSecond\nThird")

        val issues = validateSynchronization(
            syncableLines = syncableLines,
            localSynchronization = mapOf(
                0 to 0,
                1 to 2_000,
                2 to 2_000,
            ),
            durationSeconds = 10,
            includeMissing = true,
        )

        assertThat(issues[2]?.kind).isEqualTo(PostSynchronizationValidationKind.OUT_OF_ORDER)
    }

    @Test
    fun `buildSynchronizationPayload sorts items by original line index`() {
        val payload = buildSynchronizationPayload(
            localSynchronization = mapOf(
                5 to 7_100,
                0 to 0,
                2 to 1_540,
            ),
        )

        assertThat(payload.textSynchronization.map { it.lineIndex }).containsExactly(0, 2, 5)
            .inOrder()
    }
}
