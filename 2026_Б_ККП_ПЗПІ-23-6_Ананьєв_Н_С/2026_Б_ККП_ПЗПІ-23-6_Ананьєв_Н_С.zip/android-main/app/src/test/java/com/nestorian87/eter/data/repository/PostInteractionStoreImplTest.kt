package com.nestorian87.eter.data.repository

import com.google.common.truth.Truth.assertThat
import com.nestorian87.eter.domain.model.Post
import com.nestorian87.eter.domain.model.PostStatus
import org.junit.jupiter.api.Test

class PostInteractionStoreImplTest {
    private val store = PostInteractionStoreImpl()

    @Test
    fun `ensureLikeBase preserves previously seen liked state for stale post details`() {
        store.ensureLikeBase(post(isLiked = true, likesCount = 7))

        val merged = store.apply(post(isLiked = false, likesCount = 6))

        assertThat(merged.isLiked).isTrue()
        assertThat(merged.likesCount).isEqualTo(7)
    }

    @Test
    fun `ensureLikeBase does not overwrite a locally resolved unlike`() {
        store.resolveLike(postId = POST_ID, likesCount = 4, isLiked = false)
        store.ensureLikeBase(post(isLiked = true, likesCount = 5))

        val merged = store.apply(post(isLiked = true, likesCount = 5))

        assertThat(merged.isLiked).isFalse()
        assertThat(merged.likesCount).isEqualTo(4)
    }

    private fun post(
        isLiked: Boolean,
        likesCount: Int,
    ): Post = Post(
        postId = POST_ID,
        title = "Title",
        description = null,
        text = null,
        audioFileName = null,
        audioFileUrl = null,
        audioDurationSeconds = null,
        status = PostStatus.PUBLISHED,
        listens = 0,
        likesCount = likesCount,
        isLiked = isLiked,
        commentsCount = 0,
        originAuthorName = null,
        categories = emptyList(),
        authorId = 10L,
        author = null,
        slug = null,
        createdAt = "",
        updatedAt = "",
    )

    private companion object {
        const val POST_ID = 42L
    }
}
