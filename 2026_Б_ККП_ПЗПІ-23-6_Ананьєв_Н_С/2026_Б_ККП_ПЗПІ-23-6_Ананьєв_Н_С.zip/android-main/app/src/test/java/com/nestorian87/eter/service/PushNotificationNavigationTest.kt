package com.nestorian87.eter.service

import com.google.common.truth.Truth.assertThat
import org.junit.jupiter.api.Test

class PushNotificationNavigationTest {
    @Test
    fun `targetRoute maps notification payload with post and comment ids to focused post`() {
        val targetRoute = PushNotificationNavigation.targetRoute(
            mapOf(
                "notification" to """
                    {
                      "notificationId": 123,
                      "post": { "postId": 45 },
                      "comment": { "commentId": 67 }
                    }
                """.trimIndent(),
            ),
        )

        assertThat(targetRoute).isEqualTo(
            PushNotificationNavigation.TargetRoute.Post(
                postId = 45,
                focusComments = true,
            ),
        )
    }

    @Test
    fun `targetRoute maps notification payload with username to profile`() {
        val targetRoute = PushNotificationNavigation.targetRoute(
            mapOf(
                "notification" to """
                    {
                      "actor": { "username": "poet" }
                    }
                """.trimIndent(),
            ),
        )

        assertThat(targetRoute).isEqualTo(
            PushNotificationNavigation.TargetRoute.Profile(username = "poet"),
        )
    }

    @Test
    fun `targetRoute maps extras-style values with direct ids`() {
        val targetRoute = PushNotificationNavigation.targetRouteValues(
            mapOf(
                "postId" to 45,
                "commentId" to "67",
            ),
        )

        assertThat(targetRoute).isEqualTo(
            PushNotificationNavigation.TargetRoute.Post(
                postId = 45,
                focusComments = true,
            ),
        )
    }
}
