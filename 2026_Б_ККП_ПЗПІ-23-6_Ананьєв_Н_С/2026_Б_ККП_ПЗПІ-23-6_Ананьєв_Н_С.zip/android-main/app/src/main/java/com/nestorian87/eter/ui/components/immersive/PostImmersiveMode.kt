package com.nestorian87.eter.ui.components.immersive

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.nestorian87.eter.R
import com.nestorian87.eter.domain.model.Post
import com.nestorian87.eter.ui.components.audio.AudioWaveformSeekBar
import com.nestorian87.eter.ui.theme.EterSpacing

@Composable
fun PostImmersiveMode(
    visible: Boolean,
    post: Post?,
    isPlaying: Boolean,
    onTogglePlayback: () -> Unit,
    onSeek: (Float) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    currentTimeMs: Long? = null,
) {
    AnimatedVisibility(
        visible = visible && post != null,
        enter = fadeIn(animationSpec = tween(ImmersiveEnterDurationMs)),
        exit = fadeOut(animationSpec = tween(ImmersiveExitDurationMs)),
        modifier = modifier
            .fillMaxSize()
            .zIndex(ImmersiveOverlayZIndex),
    ) {
        post?.let { visiblePost ->
            ImmersiveModeContent(
                post = visiblePost,
                isPlaying = isPlaying,
                currentTimeMs = currentTimeMs,
                onTogglePlayback = onTogglePlayback,
                onSeek = onSeek,
                onClose = onClose,
            )
        }
    }
}

@Composable
private fun ImmersiveModeContent(
    post: Post,
    isPlaying: Boolean,
    currentTimeMs: Long?,
    onTogglePlayback: () -> Unit,
    onSeek: (Float) -> Unit,
    onClose: () -> Unit,
) {
    val state = rememberImmersiveModeState(
        post = post,
        isPlaying = isPlaying,
        currentTimeMs = currentTimeMs,
    )
    val untitledPostLabel = stringResource(R.string.post_untitled)
    val closeLabel = stringResource(R.string.report_close)
    val pauseLabel = stringResource(R.string.post_pause_content_description)
    val playLabel = stringResource(R.string.post_play_content_description)
    val grainCache = remember { GrainCache() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(state.colors.bgBase)
            .pointerInput(post.postId) {
                detectTapGestures(onTap = {})
            },
    ) {
        ImmersiveBackgroundLayer(
            post = post,
            isPlaying = isPlaying,
            state = state,
            grainCache = grainCache,
        )

        if (state.memoryLines.isNotEmpty()) {
            ImmersiveMemoryLayer(
                currentTimeMs = state.memoryFrameTickMs,
                memoryLines = state.memoryLines,
                colors = state.colors,
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = EterSpacing.xxLarge, vertical = EterSpacing.large),
        ) {
            ImmersiveHeader(
                title = post.title.orEmpty().ifBlank { untitledPostLabel },
                closeLabel = closeLabel,
                colors = state.colors,
                onClose = onClose,
            )

            ImmersiveDisplayText(
                text = state.displayText,
                hasSyncedLines = state.hasSyncedLines,
                silence = state.silence,
                descriptionPresent = !post.description.isNullOrBlank(),
                colors = state.colors,
            )

            ImmersiveControls(
                isPlaying = isPlaying,
                progressText = state.progressText,
                totalText = state.totalText,
                progressFraction = state.progressFraction,
                frame = state.frame,
                pauseLabel = pauseLabel,
                playLabel = playLabel,
                colors = state.colors,
                waveform = post.audioAnalysis?.waveform,
                onTogglePlayback = onTogglePlayback,
                onSeek = onSeek,
            )
        }
    }
}

@Composable
private fun ImmersiveBackgroundLayer(
    post: Post,
    isPlaying: Boolean,
    state: ImmersiveModeState,
    grainCache: GrainCache,
) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val accent = post.audioAnalysis?.accentAt(state.visualTimeMs) ?: accentFor(
            state.animationTimeMs,
            isPlaying
        )
        val silence = post.audioAnalysis?.isSilenceAt(state.visualTimeMs)
            ?: (!isPlaying || state.frame.energy < SilenceEnergyThreshold)
        drawImmersiveBackground(state.frame, accent, silence, state.colors)
        drawInk(state.frame, silence, state.animationTimeMs, state.colors)
        drawGrain(state.frame, state.colors, grainCache)
        drawBeatPulse(state.frame, accent, silence, state.animationTimeMs, state.colors)
        drawFocusVoiceField(state.frame, accent, silence, state.animationTimeMs, state.colors)
    }
}

@Composable
private fun ImmersiveMemoryLayer(
    currentTimeMs: Long,
    memoryLines: List<MemoryLine>,
    colors: ImmersiveColors,
) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        drawMemoryLines(
            lines = memoryLines,
            currentTimeMs = currentTimeMs,
            colors = colors,
        )
    }
}

@Composable
private fun ImmersiveHeader(
    title: String,
    closeLabel: String,
    colors: ImmersiveColors,
    onClose: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium),
    ) {
        Text(
            modifier = Modifier.weight(1f),
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
            color = colors.textStrong,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Surface(
            shape = CircleShape,
            color = colors.overlayBg,
            border = BorderStroke(1.dp, colors.overlayBorder),
        ) {
            IconButton(onClick = onClose) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = closeLabel,
                    tint = colors.textStrong,
                )
            }
        }
    }
}

@Composable
private fun ColumnScope.ImmersiveDisplayText(
    text: String?,
    hasSyncedLines: Boolean,
    silence: Boolean,
    descriptionPresent: Boolean,
    colors: ImmersiveColors,
) {
    Box(
        modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
            .padding(horizontal = EterSpacing.medium),
        contentAlignment = Alignment.Center,
    ) {
        AnimatedContent(
            targetState = text,
            transitionSpec = {
                fadeIn(tween(ImmersiveLineEnterDurationMs)) togetherWith
                        fadeOut(tween(ImmersiveLineExitDurationMs))
            },
            label = "immersive_line",
        ) { currentText ->
            if (currentText != null) {
                val silenceAlpha = if (silence) 0.70f else 1f
                Text(
                    modifier = Modifier.widthIn(max = ImmersiveDisplayTextMaxWidth),
                    text = currentText,
                    style = if (hasSyncedLines) {
                        MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Medium,
                            lineHeight = 34.sp,
                            letterSpacing = (-0.2).sp,
                        )
                    } else {
                        MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Medium,
                            fontStyle = if (descriptionPresent) FontStyle.Italic else FontStyle.Normal,
                            lineHeight = 30.sp,
                        )
                    },
                    color = colors.textNormal.copy(
                        alpha = colors.textNormal.alpha * silenceAlpha * 0.82f,
                    ),
                    textAlign = TextAlign.Center,
                    maxLines = if (hasSyncedLines) 3 else 5,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun ImmersiveControls(
    isPlaying: Boolean,
    progressText: String,
    totalText: String,
    progressFraction: Float,
    frame: VoiceFrame,
    pauseLabel: String,
    playLabel: String,
    colors: ImmersiveColors,
    waveform: String?,
    onTogglePlayback: () -> Unit,
    onSeek: (Float) -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = colors.controlsBg,
        border = BorderStroke(1.dp, colors.controlsBorder),
    ) {
        Row(
            modifier = Modifier.padding(EterSpacing.medium),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium),
        ) {
            Surface(
                modifier = Modifier.size(ImmersiveControlsPlayButtonSize),
                shape = CircleShape,
                color = if (isPlaying) colors.textNormal.copy(alpha = 0.92f) else colors.overlayBg,
                border = BorderStroke(1.dp, colors.overlayBorder),
                onClick = onTogglePlayback,
            ) {
                Box(contentAlignment = Alignment.Center) {
                    AnimatedContent(
                        targetState = isPlaying,
                        transitionSpec = {
                            fadeIn(tween(ImmersivePlayIconDurationMs)) togetherWith
                                    fadeOut(tween(ImmersivePlayIconDurationMs))
                        },
                        label = "immersive_play_icon",
                    ) { playing ->
                        Icon(
                            imageVector = if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = if (playing) pauseLabel else playLabel,
                            tint = if (playing) colors.playIconActive else colors.textNormal,
                            modifier = Modifier.size(ImmersiveControlsPlayIconSize),
                        )
                    }
                }
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
            ) {
                AudioWaveformSeekBar(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(ImmersiveWaveformHeight),
                    waveform = waveform,
                    progressFraction = progressFraction,
                    onSeek = onSeek,
                    playedColor = colors.waveformColor.copy(alpha = if (isPlaying) 0.86f else 0.66f),
                    unplayedColor = colors.waveformColor.copy(alpha = if (isPlaying) 0.34f else 0.24f),
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = progressText,
                        style = MaterialTheme.typography.labelLarge,
                        color = colors.textMuted,
                    )
                    Text(
                        text = totalText,
                        style = MaterialTheme.typography.labelLarge,
                        color = colors.textMuted,
                    )
                }
            }
        }
    }
}
