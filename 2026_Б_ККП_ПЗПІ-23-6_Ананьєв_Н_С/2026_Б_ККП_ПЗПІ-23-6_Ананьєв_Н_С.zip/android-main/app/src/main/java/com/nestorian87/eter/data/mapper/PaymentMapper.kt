package com.nestorian87.eter.data.mapper

import com.nestorian87.eter.data.remote.dto.CheckoutResultDto
import com.nestorian87.eter.data.remote.dto.SubscriptionCardDto
import com.nestorian87.eter.data.remote.dto.SubscriptionDto
import com.nestorian87.eter.data.remote.dto.SubscriptionTransactionDto
import com.nestorian87.eter.data.remote.dto.SubscriptionTransactionsResponseDto
import com.nestorian87.eter.domain.model.CheckoutResult
import com.nestorian87.eter.domain.model.Subscription
import com.nestorian87.eter.domain.model.SubscriptionCard
import com.nestorian87.eter.domain.model.SubscriptionStatus
import com.nestorian87.eter.domain.model.SubscriptionTransaction
import com.nestorian87.eter.domain.model.SubscriptionTransactionsPage
import com.nestorian87.eter.domain.model.TransactionStatus
import com.nestorian87.eter.domain.model.TransactionType

fun SubscriptionDto.toDomain(): Subscription = Subscription(
    subscriptionId = subscriptionId,
    userId = userId,
    status = SubscriptionStatus.fromString(status),
    startDate = startDate,
    nextPaymentDate = nextPaymentDate,
    cancellationDate = cancellationDate,
    walletId = walletId,
    card = card?.toDomain(),
)

fun SubscriptionCardDto.toDomain(): SubscriptionCard = SubscriptionCard(
    cardId = cardId,
    paymentSystem = paymentSystem,
    maskedNumber = maskedNumber,
)

fun CheckoutResultDto.toDomain(): CheckoutResult = CheckoutResult(
    invoiceId = invoiceId,
    checkoutUrl = checkoutUrl,
)

fun SubscriptionTransactionDto.toDomain(): SubscriptionTransaction = SubscriptionTransaction(
    transactionId = transactionId,
    invoiceId = invoiceId,
    status = status?.let { TransactionStatus.fromString(it) },
    type = TransactionType.fromString(type),
    amount = amount,
    currency = currency,
    isCardUpdating = isCardUpdating,
    modifiedDate = modifiedDate,
    createdAt = createdAt,
    updatedAt = updatedAt,
)

fun SubscriptionTransactionsResponseDto.toDomain(): SubscriptionTransactionsPage =
    SubscriptionTransactionsPage(
        items = items.map { it.toDomain() },
        total = total,
        offset = offset,
    )
