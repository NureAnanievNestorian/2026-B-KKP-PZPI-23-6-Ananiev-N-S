package com.nestorian87.eter.domain.model

data class SubscriptionTransaction(
    val transactionId: Long,
    val invoiceId: String,
    val status: TransactionStatus?,
    val type: TransactionType,
    val amount: String,
    val currency: String,
    val isCardUpdating: Boolean,
    val modifiedDate: String?,
    val createdAt: String,
    val updatedAt: String,
)
