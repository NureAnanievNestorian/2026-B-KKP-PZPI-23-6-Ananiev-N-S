package com.nestorian87.eter.ui.components.immersive

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.graphics.Color
import com.nestorian87.eter.domain.model.Post
import com.nestorian87.eter.domain.model.PostAudioAnalysis
import com.nestorian87.eter.domain.model.PostTextSynchronization
import kotlin.math.max
import kotlin.math.roundToLong

@Composable
internal fun rememberImmersiveModeState(
    post: Post,
    isPlaying: Boolean,
    currentTimeMs: Long?,
): ImmersiveModeState {
    val immersiveColors =
        if (androidx.compose.material3.MaterialTheme.colorScheme.background.luminanceCompat() > 0.5f) {
            LightImmersiveColors
        } else {
            DarkImmersiveColors
        }
    val analysis = remember(post.audioAnalysis) { post.audioAnalysis?.decodeVoiceAnalysis() }
    val textLines = remember(post.text) { splitPostTextLines(post.text) }
    val synchronization = remember(textLines, post.textSynchronization) {
        normalizeSynchronization(textLines.size, post.textSynchronization)
    }
    val currentTimeMsState = rememberUpdatedState(currentTimeMs)
    val isPlayingState = rememberUpdatedState(isPlaying)

    val visualTimeMsState = remember(post.postId) { mutableLongStateOf(currentTimeMs ?: 0L) }
    val openedAudioMsState = remember(post.postId) { mutableLongStateOf(currentTimeMs ?: 0L) }
    val animationTimeMsState = remember(post.postId) { mutableFloatStateOf(0f) }
    val smoothFrameState = remember(post.postId) { mutableStateOf(VoiceFrame()) }
    val externalAnchorMsState = remember(post.postId) { mutableLongStateOf(currentTimeMs ?: 0L) }
    val externalAnchorNanosState = remember(post.postId) { mutableLongStateOf(0L) }
    val memoryFrameTickState = remember(post.postId) { mutableLongStateOf(currentTimeMs ?: 0L) }

    LaunchedEffect(post.postId, currentTimeMs) {
        currentTimeMs?.let { value ->
            externalAnchorMsState.longValue = value
            externalAnchorNanosState.longValue = 0L
        }
    }

    LaunchedEffect(post.postId, analysis, synchronization) {
        var lastNanos = 0L
        var reactivePulse = 0f
        while (true) {
            withFrameNanos { frameNanos ->
                if (lastNanos == 0L) lastNanos = frameNanos
                val deltaMs = ((frameNanos - lastNanos) / 1_000_000L).coerceIn(0L, MaxFrameDeltaMs)
                lastNanos = frameNanos
                val playbackPositionMs = currentTimeMsState.value
                val playing = isPlayingState.value

                if (externalAnchorNanosState.longValue == 0L) {
                    externalAnchorNanosState.longValue = frameNanos
                }

                val newVisualMs = when {
                    playbackPositionMs != null && playing -> {
                        val elapsedMs =
                            ((frameNanos - externalAnchorNanosState.longValue) / 1_000_000L).coerceAtLeast(
                                0L
                            )
                        (externalAnchorMsState.longValue + elapsedMs).coerceAtMost(
                            analysis?.durationMs ?: Long.MAX_VALUE
                        )
                    }

                    playbackPositionMs != null -> externalAnchorMsState.longValue
                    playing -> (visualTimeMsState.longValue + deltaMs).coerceAtMost(
                        analysis?.durationMs ?: Long.MAX_VALUE
                    )

                    else -> visualTimeMsState.longValue
                }

                visualTimeMsState.longValue = newVisualMs
                memoryFrameTickState.longValue = if (playing) {
                    newVisualMs
                } else {
                    memoryFrameTickState.longValue + deltaMs
                }
                animationTimeMsState.floatValue += if (playing) {
                    deltaMs.toFloat()
                } else {
                    deltaMs.toFloat() * PausedAnimationSpeedMultiplier
                }

                val targetFrame = analysis?.readFrameAt(newVisualMs) ?: proceduralFrame(
                    animationTimeMsState.floatValue,
                    playing
                )
                val accent = post.audioAnalysis?.accentAt(newVisualMs) ?: accentFor(
                    animationTimeMsState.floatValue,
                    playing
                )
                val transient = max(targetFrame.peak, accent)
                reactivePulse = if (transient > reactivePulse) {
                    reactivePulse + (transient - reactivePulse) * ReactivePulseAttack
                } else {
                    reactivePulse + (transient - reactivePulse) * ReactivePulseRelease
                }
                smoothFrameState.value =
                    smoothFrameState.value.towards(targetFrame.withPulse(reactivePulse))
            }
        }
    }

    val silence by remember(post, analysis, isPlaying) {
        derivedStateOf {
            post.audioAnalysis?.isSilenceAt(visualTimeMsState.longValue)
                ?: (!isPlayingState.value || smoothFrameState.value.energy < SilenceEnergyThreshold)
        }
    }
    val progressText by remember { derivedStateOf { visualTimeMsState.longValue.toDurationText() } }
    val totalDurationMs = analysis?.durationMs
        ?: ((post.audioDurationSeconds?.toDouble() ?: 0.0) * 1000.0).roundToLong()
    val totalText = totalDurationMs.toDurationText()
    val progressFraction by remember(analysis, post.audioDurationSeconds) {
        derivedStateOf {
            if (totalDurationMs <= 0L) 0f else {
                (visualTimeMsState.longValue.toFloat() / totalDurationMs.toFloat()).coerceIn(0f, 1f)
            }
        }
    }

    val hasSyncedLines = synchronization.isNotEmpty() && textLines.isNotEmpty()
    val activeLineIndex by remember(synchronization) {
        derivedStateOf {
            computeActiveLineIndex(
                synchronization,
                visualTimeMsState.longValue + AnticipationMs
            )
        }
    }
    val isAfterLastLine by remember(synchronization, post.audioAnalysis) {
        derivedStateOf {
            computeIsAfterLastLine(
                synchronization = synchronization,
                analysis = post.audioAnalysis,
                activeLineIndex = activeLineIndex,
                currentTimeMs = visualTimeMsState.longValue,
            )
        }
    }
    val shouldHideLine by remember(synchronization, post.audioAnalysis) {
        derivedStateOf {
            computeShouldHideLine(
                synchronization = synchronization,
                analysis = post.audioAnalysis,
                activeLineIndex = activeLineIndex,
                currentTimeMs = visualTimeMsState.longValue,
                isAfterLastLine = isAfterLastLine,
            )
        }
    }
    val activeLine: String? by remember(textLines, synchronization) {
        derivedStateOf {
            if (hasSyncedLines && !shouldHideLine && activeLineIndex >= 0) {
                textLines.getOrNull(activeLineIndex)?.takeIf { it.isNotBlank() }
            } else {
                null
            }
        }
    }
    val memoryListTick by remember(synchronization) {
        derivedStateOf { visualTimeMsState.longValue / MemoryListRebuildIntervalMs }
    }
    val memoryLines =
        remember(textLines, synchronization, activeLineIndex, isAfterLastLine, memoryListTick) {
            computeMemoryLines(
                textLines = textLines,
                synchronization = synchronization,
                activeLineIndex = activeLineIndex,
                currentTimeMs = visualTimeMsState.longValue,
                openedAudioMs = openedAudioMsState.longValue,
                isAfterLastLine = isAfterLastLine,
            )
        }
    val displayText = if (hasSyncedLines) {
        activeLine
    } else {
        post.description?.takeIf { it.isNotBlank() } ?: post.title?.takeIf { it.isNotBlank() }
    }

    return ImmersiveModeState(
        colors = immersiveColors,
        frame = smoothFrameState.value,
        animationTimeMs = animationTimeMsState.floatValue,
        visualTimeMs = visualTimeMsState.longValue,
        memoryFrameTickMs = memoryFrameTickState.longValue,
        silence = silence,
        progressText = progressText,
        totalText = totalText,
        progressFraction = progressFraction,
        memoryLines = memoryLines,
        displayText = displayText,
        hasSyncedLines = hasSyncedLines,
        analysis = analysis,
    )
}

internal data class ImmersiveModeState(
    val colors: ImmersiveColors,
    val frame: VoiceFrame,
    val animationTimeMs: Float,
    val visualTimeMs: Long,
    val memoryFrameTickMs: Long,
    val silence: Boolean,
    val progressText: String,
    val totalText: String,
    val progressFraction: Float,
    val memoryLines: List<MemoryLine>,
    val displayText: String?,
    val hasSyncedLines: Boolean,
    val analysis: DecodedVoiceAnalysis?,
)

private fun splitPostTextLines(text: String?): List<String> =
    text
        ?.replace("\r\n", "\n")
        ?.replace("\r", "\n")
        ?.split("\n")
        ?: emptyList()

private fun normalizeSynchronization(
    textLineCount: Int,
    synchronization: List<PostTextSynchronization>,
): List<PostTextSynchronization> {
    if (synchronization.isEmpty() || textLineCount <= 0) return emptyList()

    val hasZeroIndex = synchronization.any { it.lineIndex == 0 }
    val minIndex = synchronization.minOf { it.lineIndex }
    val maxIndex = synchronization.maxOf { it.lineIndex }
    val shouldShiftToZeroBased = !hasZeroIndex && minIndex >= 1 && maxIndex <= textLineCount

    return synchronization
        .map { item ->
            if (shouldShiftToZeroBased) item.copy(lineIndex = item.lineIndex - 1) else item
        }
        .filter { item -> item.lineIndex in 0 until textLineCount }
        .distinctBy { item -> item.lineIndex to item.audioStartMomentMs }
        .sortedBy { item -> item.audioStartMomentMs }
}

private fun computeActiveLineIndex(
    synchronization: List<PostTextSynchronization>,
    displayTimeMs: Long,
): Int {
    if (synchronization.isEmpty()) return -1
    var index = -1
    for (synchronizationItem in synchronization) {
        if (synchronizationItem.audioStartMomentMs <= displayTimeMs) {
            index = synchronizationItem.lineIndex
        } else {
            break
        }
    }
    return index
}

private fun computeIsAfterLastLine(
    synchronization: List<PostTextSynchronization>,
    analysis: PostAudioAnalysis?,
    activeLineIndex: Int,
    currentTimeMs: Long,
): Boolean {
    if (synchronization.isEmpty()) return false
    val audioAnalysis = analysis ?: return false
    val lastLineIndex = synchronization.last().lineIndex
    val trailingStart = audioAnalysis.silences.lastOrNull {
        it.endMs >= audioAnalysis.durationMs - TrailingSilenceToleranceMs &&
                it.startMs < audioAnalysis.durationMs - TrailingSilenceToleranceMs
    }?.startMs ?: return false
    return activeLineIndex == lastLineIndex && currentTimeMs >= trailingStart
}

private fun computeShouldHideLine(
    synchronization: List<PostTextSynchronization>,
    analysis: PostAudioAnalysis?,
    activeLineIndex: Int,
    currentTimeMs: Long,
    isAfterLastLine: Boolean,
): Boolean {
    if (synchronization.isEmpty()) return false
    val audioAnalysis = analysis ?: return false

    val leadingEnd = audioAnalysis.silences
        .firstOrNull { it.startMs <= LeadingSilenceToleranceMs && it.endMs > LeadingSilenceToleranceMs }
        ?.endMs ?: 0L
    val firstLineIndex = synchronization.first().lineIndex
    if (activeLineIndex == firstLineIndex && leadingEnd > 0L && currentTimeMs < leadingEnd) return true

    return isAfterLastLine
}

private fun Color.luminanceCompat(): Float =
    red * 0.2126f + green * 0.7152f + blue * 0.0722f

private fun Long.toDurationText(): String {
    val totalSeconds = (this / 1000L).coerceAtLeast(0L)
    return "%d:%02d".format(totalSeconds / 60L, totalSeconds % 60L)
}

private fun List<PostTextSynchronization>.indexRangeText(): String {
    if (isEmpty()) return "empty"
    return "${minOf { it.lineIndex }}..${maxOf { it.lineIndex }}"
}

private fun VoiceFrame.shortText(): String =
    "e=${energy.format2()},p=${peak.format2()},l=${low.format2()},m=${mid.format2()},h=${high.format2()},z=${zcr.format2()}"

private fun Float.format2(): String =
    "% .2f".format(this).trim()
