package com.nestorian87.eter.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class SubscriptionDto(
    val subscriptionId: Long,
    val userId: Long,
    val status: String,
    val startDate: String? = null,
    val nextPaymentDate: String? = null,
    val cancellationDate: String? = null,
    val walletId: String? = null,
    val card: SubscriptionCardDto? = null,
)
