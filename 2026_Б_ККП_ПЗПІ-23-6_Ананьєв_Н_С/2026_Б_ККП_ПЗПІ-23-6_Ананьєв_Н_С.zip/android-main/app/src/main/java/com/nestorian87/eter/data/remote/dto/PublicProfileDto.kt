package com.nestorian87.eter.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class PublicProfileDto(
    val userId: Long,
    val name: String,
    val username: String,
    val photo: String? = null,
    val bio: String? = null,
    val link: String? = null,
    val isPremium: Boolean = false,
    val isSubscribed: Boolean = false,
    val createdAt: String,
    val followersCount: Int = 0,
    val followingCount: Int = 0,
    val postsCount: Int = 0,
)
