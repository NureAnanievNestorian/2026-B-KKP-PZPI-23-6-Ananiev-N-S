package com.nestorian87.eter.data.repository

import com.nestorian87.eter.domain.model.PaymentException
import retrofit2.HttpException

internal class PaymentServerErrorMapper {
    fun toCheckoutException(error: HttpException): Throwable {
        if (error.code() == 409) {
            return PaymentException(
                reasons = setOf(PaymentException.Reason.SUBSCRIPTION_ALREADY_ACTIVE),
                cause = error,
            )
        }
        return toCommonException(error)
    }

    fun toCancelException(error: HttpException): Throwable {
        if (error.code() == 403) {
            return PaymentException(
                reasons = setOf(PaymentException.Reason.CANCELLATION_NOT_ALLOWED),
                cause = error,
            )
        }
        return toCommonException(error)
    }

    fun toCardUpdateException(error: HttpException): Throwable {
        if (error.code() == 403) {
            return PaymentException(
                reasons = setOf(PaymentException.Reason.CARD_UPDATE_NOT_ALLOWED),
                cause = error,
            )
        }
        return toCommonException(error)
    }

    fun toCommonException(error: HttpException): Throwable = PaymentException(
        reasons = setOf(PaymentException.Reason.UNKNOWN),
        cause = error,
    )

}
