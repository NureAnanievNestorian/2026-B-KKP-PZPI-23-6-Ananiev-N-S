package com.nestorian87.eter.ui.app

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nestorian87.eter.domain.model.PendingPayment
import com.nestorian87.eter.domain.repository.AuthRepository
import com.nestorian87.eter.domain.repository.PendingPaymentStore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AppSessionViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    private val pendingPaymentStore: PendingPaymentStore,
) : ViewModel() {
    private val _uiState = MutableStateFlow(AppSessionUiState())
    val uiState: StateFlow<AppSessionUiState> = _uiState.asStateFlow()

    private val _pendingPaymentReturn = MutableStateFlow<PendingPayment?>(null)
    val pendingPaymentReturn: StateFlow<PendingPayment?> = _pendingPaymentReturn.asStateFlow()

    init {
        viewModelScope.launch {
            authRepository.session.collectLatest { session ->
                _uiState.value = _uiState.value.copy(
                    isAuthenticated = session != null,
                    isEmailVerified = session?.user?.isEmailVerified ?: false,
                )
            }
        }

        viewModelScope.launch {
            val restored = authRepository.restoreSession()
            if (restored || authRepository.session.value != null) {
                runCatching { authRepository.refreshCurrentUser() }
            }
            _uiState.value = _uiState.value.copy(isCheckingSession = false)
        }
    }

    fun onPaymentReturnIntent() {
        viewModelScope.launch {
            _pendingPaymentReturn.value = pendingPaymentStore.read()
        }
    }

    fun onPendingPaymentReturnConsumed() {
        _pendingPaymentReturn.value = null
    }
}
