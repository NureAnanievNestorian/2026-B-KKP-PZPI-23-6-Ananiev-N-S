package com.nestorian87.eter.ui.screens.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nestorian87.eter.domain.model.PaymentException
import com.nestorian87.eter.domain.model.PaymentSocketEvent
import com.nestorian87.eter.domain.model.PendingPayment
import com.nestorian87.eter.domain.model.SubscriptionStatus
import com.nestorian87.eter.domain.model.TransactionStatus
import com.nestorian87.eter.domain.repository.PaymentRepository
import com.nestorian87.eter.domain.repository.PaymentSocketManager
import com.nestorian87.eter.domain.repository.PendingPaymentStore
import com.nestorian87.eter.domain.repository.PostRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SubscriptionManagementViewModel @Inject constructor(
    private val paymentRepository: PaymentRepository,
    private val postRepository: PostRepository,
    private val paymentSocketManager: PaymentSocketManager,
    private val pendingPaymentStore: PendingPaymentStore,
) : ViewModel() {

    private val _uiState = MutableStateFlow(SubscriptionManagementUiState())
    val uiState: StateFlow<SubscriptionManagementUiState> = _uiState.asStateFlow()

    private val _effects = Channel<SubscriptionManagementEffect>(Channel.BUFFERED)
    val effects = _effects.receiveAsFlow()
    private var transactionsOffset = 0
    private var transactionsLoadJob: Job? = null

    init {
        loadData()
        paymentSocketManager.connect()
        observeSocketEvents()
    }

    fun onRetryClick() = loadData()

    fun onLoadMoreTransactions() {
        val state = _uiState.value
        if (
            state.isTransactionsLoading ||
            state.isLoadingMoreTransactions ||
            !state.canLoadMoreTransactions
        ) {
            return
        }

        loadTransactions(reset = false)
    }

    fun onBuyPremiumClick() {
        viewModelScope.launch {
            _uiState.update { it.copy(isCheckoutLoading = true) }
            runCatching { paymentRepository.createCheckout() }
                .onSuccess { result ->
                    _uiState.update { it.copy(isCheckoutLoading = false) }
                    result.checkoutUrl?.let { url ->
                        pendingPaymentStore.save(
                            PendingPayment(result.invoiceId, PendingPayment.PAYMENT_TYPE_CHECKOUT),
                        )
                        _effects.send(
                            SubscriptionManagementEffect.OpenUrl(
                                url = url,
                                invoiceId = result.invoiceId,
                                paymentType = PendingPayment.PAYMENT_TYPE_CHECKOUT,
                            ),
                        )
                    }
                }
                .onFailure {
                    _uiState.update { it.copy(isCheckoutLoading = false) }
                }
        }
    }

    fun onCancelClick() {
        _uiState.update { it.copy(showCancelDialog = true, cancelError = null) }
    }

    fun onCancelDismiss() {
        _uiState.update { it.copy(showCancelDialog = false, cancelError = null) }
    }

    fun onCancelConfirm() {
        viewModelScope.launch {
            _uiState.update { it.copy(isCancelLoading = true, cancelError = null) }
            runCatching { paymentRepository.cancelSubscription() }
                .onSuccess {
                    _uiState.update { state ->
                        state.copy(
                            isCancelLoading = false,
                            showCancelDialog = false,
                            subscription = state.subscription?.copy(
                                status = SubscriptionStatus.CANCELLED,
                                startDate = null,
                                nextPaymentDate = null,
                            ),
                        )
                    }
                }
                .onFailure { e ->
                    val reason = (e as? PaymentException)?.primaryReason
                    _uiState.update {
                        it.copy(
                            isCancelLoading = false,
                            cancelError = when (reason) {
                                PaymentException.Reason.NETWORK -> "network"
                                PaymentException.Reason.CANCELLATION_NOT_ALLOWED -> "not_allowed"
                                else -> "generic"
                            },
                        )
                    }
                }
        }
    }

    fun onChangeCardClick() {
        viewModelScope.launch {
            _uiState.update { it.copy(isCardUpdateLoading = true) }
            runCatching { paymentRepository.updateCard() }
                .onSuccess { result ->
                    _uiState.update { it.copy(isCardUpdateLoading = false) }
                    result.checkoutUrl?.let { url ->
                        pendingPaymentStore.save(
                            PendingPayment(
                                result.invoiceId,
                                PendingPayment.PAYMENT_TYPE_CARD_UPDATE
                            ),
                        )
                        _effects.send(
                            SubscriptionManagementEffect.OpenUrl(
                                url = url,
                                invoiceId = result.invoiceId,
                                paymentType = PendingPayment.PAYMENT_TYPE_CARD_UPDATE,
                            ),
                        )
                    }
                }
                .onFailure {
                    _uiState.update { it.copy(isCardUpdateLoading = false) }
                }
        }
    }

    private fun loadData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, loadError = null) }
            runCatching {
                val configDeferred = async { postRepository.getPublicConfig() }
                val subscriptionDeferred = async { paymentRepository.getSubscription() }
                configDeferred.await() to subscriptionDeferred.await()
            }.onSuccess { (config, subscription) ->
                val cardLinking = subscription?.isPremium == true && subscription.card == null
                if (subscription == null) {
                    transactionsOffset = 0
                }
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        subscription = subscription,
                        isCardLinking = cardLinking,
                        priceUsd = config.subscription.priceUsd,
                        freeDurationMinutes = config.recording.freeDurationLimitMinutes,
                        premiumDurationMinutes = config.recording.premiumDurationLimitMinutes,
                        transactions = if (subscription != null) it.transactions else emptyList(),
                        canLoadMoreTransactions = false,
                    )
                }
                if (subscription != null) {
                    loadTransactions(reset = true)
                }
            }.onFailure { e ->
                val reason = (e as? PaymentException)?.primaryReason
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        loadError = when (reason) {
                            PaymentException.Reason.NETWORK -> "network"
                            else -> "generic"
                        },
                    )
                }
            }
        }
    }

    private fun loadTransactions(reset: Boolean) {
        if (transactionsLoadJob?.isActive == true) {
            return
        }

        transactionsLoadJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isTransactionsLoading = reset,
                    isLoadingMoreTransactions = !reset,
                )
            }
            runCatching {
                paymentRepository.getTransactions(
                    offset = if (reset) 0 else transactionsOffset,
                    limit = TRANSACTIONS_PAGE_SIZE,
                )
            }
                .onSuccess { page ->
                    val mergedTransactions = if (reset) {
                        page.items
                    } else {
                        (_uiState.value.transactions + page.items).distinctBy { transaction ->
                            transaction.transactionId
                        }
                    }
                    transactionsOffset = page.offset + page.items.size
                    _uiState.update {
                        it.copy(
                            isTransactionsLoading = false,
                            isLoadingMoreTransactions = false,
                            transactions = mergedTransactions,
                            canLoadMoreTransactions = mergedTransactions.size < page.total,
                        )
                    }
                }
                .onFailure {
                    _uiState.update {
                        it.copy(
                            isTransactionsLoading = false,
                            isLoadingMoreTransactions = false,
                        )
                    }
                }
        }
    }

    private fun observeSocketEvents() {
        viewModelScope.launch {
            paymentSocketManager.events.collect { event ->
                when (event) {
                    is PaymentSocketEvent.TransactionUpdated -> {
                        _uiState.update { state ->
                            val list = state.transactions.toMutableList()
                            val idx =
                                list.indexOfFirst { it.transactionId == event.transaction.transactionId }
                            if (idx >= 0) list[idx] = event.transaction else list.add(
                                0,
                                event.transaction
                            )
                            state.copy(transactions = list)
                        }
                        if (
                            event.transaction.status == TransactionStatus.SUCCESS &&
                            !event.transaction.isCardUpdating
                        ) {
                            loadData()
                        }
                    }

                    is PaymentSocketEvent.CardLinked -> {
                        _uiState.update {
                            it.copy(subscription = event.subscription, isCardLinking = false)
                        }
                    }

                    is PaymentSocketEvent.CheckoutCreated -> {
                        event.result.checkoutUrl?.let { url ->
                            pendingPaymentStore.save(
                                PendingPayment(
                                    event.result.invoiceId,
                                    PendingPayment.PAYMENT_TYPE_CHECKOUT,
                                ),
                            )
                            _effects.send(
                                SubscriptionManagementEffect.OpenUrl(
                                    url = url,
                                    invoiceId = event.result.invoiceId,
                                    paymentType = PendingPayment.PAYMENT_TYPE_CHECKOUT,
                                ),
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onCleared() {
        paymentSocketManager.disconnect()
    }

    private companion object {
        const val TRANSACTIONS_PAGE_SIZE = 20
    }
}
