package com.nestorian87.eter.ui.screens.profile

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts.GetContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nestorian87.eter.R
import com.nestorian87.eter.ui.components.buttons.BackIconButton
import com.nestorian87.eter.ui.components.buttons.PrimaryActionButton
import com.nestorian87.eter.ui.components.forms.UnderlinedTextField
import com.nestorian87.eter.ui.components.layout.AuthorAvatar
import com.nestorian87.eter.ui.components.layout.FormScreenScaffold
import com.nestorian87.eter.ui.theme.EterPreview
import com.nestorian87.eter.ui.theme.EterScreenPreviews
import com.nestorian87.eter.ui.theme.EterSpacing

@Composable
fun EditProfileScreen(
    modifier: Modifier = Modifier,
    onBack: () -> Unit = {},
    onLoginRequested: () -> Unit = {},
    onOpenOwnProfile: () -> Unit = {},
    viewModel: ProfileViewModel = hiltViewModel<ProfileViewModel, ProfileViewModel.Factory> { factory ->
        factory.create(null, null)
    },
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val avatarPicker = rememberLauncherForActivityResult(GetContent()) { uri ->
        viewModel.onAvatarSelected(uri)
    }

    LaunchedEffect(uiState.isOwner) {
        if (uiState.isOwner) {
            viewModel.onEditProfileClick()
        }
    }

    LaunchedEffect(viewModel) {
        viewModel.effects.collect { effect ->
            when (effect) {
                ProfileEffect.NavigateToLogin -> onLoginRequested()
                ProfileEffect.NavigateToOwnProfile -> onOpenOwnProfile()
                ProfileEffect.ProfileSaved -> onBack()
                is ProfileEffect.ShareProfile -> Unit
            }
        }
    }

    EditProfileScreenContent(
        uiState = uiState.editDialog,
        modifier = modifier,
        onBack = onBack,
        onNameChanged = viewModel::onEditNameChanged,
        onUsernameChanged = viewModel::onEditUsernameChanged,
        onBioChanged = viewModel::onEditBioChanged,
        onLinkChanged = viewModel::onEditLinkChanged,
        onRemoveAvatarClick = viewModel::onRemoveAvatarClick,
        onSelectAvatarClick = { avatarPicker.launch("image/*") },
        onSaveClick = viewModel::onSaveProfileChanges,
    )
}

@Composable
private fun EditProfileScreenContent(
    uiState: EditProfileDialogUiState,
    onBack: () -> Unit,
    onNameChanged: (String) -> Unit,
    onUsernameChanged: (String) -> Unit,
    onBioChanged: (String) -> Unit,
    onLinkChanged: (String) -> Unit,
    onRemoveAvatarClick: () -> Unit,
    onSelectAvatarClick: () -> Unit,
    onSaveClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    FormScreenScaffold(
        modifier = modifier,
        contentPadding = PaddingValues(
            start = EterSpacing.xxLarge,
            end = EterSpacing.xxLarge,
            bottom = EterSpacing.small,
        ),
        bottomBar = {
            PrimaryActionButton(
                text = stringResource(R.string.profile_edit_save_cta),
                isLoading = uiState.isSaving,
                onClick = onSaveClick,
            )
        },
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(EterSpacing.large),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(EterSpacing.small),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                BackIconButton(onClick = onBack)
                Text(
                    text = stringResource(R.string.profile_edit_title),
                    style = MaterialTheme.typography.headlineLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                )
            }

            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
                ) {
                    Box(
                        modifier = Modifier.clickable(onClick = onSelectAvatarClick),
                    ) {
                        AuthorAvatar(
                            name = uiState.name.ifBlank { stringResource(R.string.profile_default_name) },
                            photoUrl = uiState.selectedAvatarUri
                                ?: if (uiState.removeAvatar) null else uiState.currentAvatarUrl,
                            size = 88.dp,
                        )
                        Surface(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(32.dp),
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary,
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Rounded.PhotoCamera,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(16.dp),
                                )
                            }
                        }
                    }
                    if (uiState.currentAvatarUrl != null || uiState.selectedAvatarUri != null) {
                        TextButton(
                            onClick = onRemoveAvatarClick,
                            contentPadding = PaddingValues(0.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                            )
                            Spacer(modifier = Modifier.size(EterSpacing.xSmall))
                            Text(
                                text = stringResource(R.string.profile_edit_avatar_remove),
                                color = MaterialTheme.colorScheme.error,
                            )
                        }
                    }
                }
            }

            uiState.avatarErrorResId?.let { resId ->
                Text(
                    text = stringResource(resId),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
            }

            UnderlinedTextField(
                value = uiState.name,
                onValueChange = onNameChanged,
                label = stringResource(R.string.profile_edit_name_label),
                placeholder = stringResource(R.string.profile_edit_name_placeholder),
                errorMessage = uiState.nameErrorResId?.let { stringResource(it) },
            )
            UnderlinedTextField(
                value = uiState.username,
                onValueChange = onUsernameChanged,
                label = stringResource(R.string.profile_edit_username_label),
                placeholder = stringResource(R.string.profile_edit_username_placeholder),
                errorMessage = uiState.usernameErrorResId?.let { stringResource(it) },
            )
            UnderlinedTextField(
                value = uiState.bio,
                onValueChange = onBioChanged,
                label = stringResource(R.string.profile_edit_bio_label),
                placeholder = stringResource(R.string.profile_edit_bio_placeholder),
                singleLine = false,
            )
            UnderlinedTextField(
                value = uiState.link,
                onValueChange = onLinkChanged,
                label = stringResource(R.string.profile_edit_link_label),
                placeholder = stringResource(R.string.profile_edit_link_placeholder),
                errorMessage = uiState.linkErrorResId?.let { stringResource(it) },
            )

            uiState.formErrorResId?.let { resId ->
                Text(
                    text = stringResource(resId),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
            }

            Spacer(modifier = Modifier.size(EterSpacing.xxLarge))
        }
    }
}

@EterScreenPreviews
@Composable
private fun EditProfileScreenPreview() {
    EterPreview {
        EditProfileScreenContent(
            uiState = EditProfileDialogUiState(
                name = "Nestorian",
                username = "nestorianananiev",
                bio = "Short bio",
                link = "https://eter.pp.ua",
            ),
            onBack = {},
            onNameChanged = {},
            onUsernameChanged = {},
            onBioChanged = {},
            onLinkChanged = {},
            onRemoveAvatarClick = {},
            onSelectAvatarClick = {},
            onSaveClick = {},
        )
    }
}
