package com.nestorian87.eter.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class ActiveViolationResponseDto(
    val complaintId: Long,
    val complaintReason: String,
    val status: String,
    val createdAt: String,
    val expiresAt: String? = null,
    val targetPost: ViolationTargetPostDto,
)

@Serializable
data class ViolationTargetPostDto(
    val postId: Long,
    val title: String? = null,
    val description: String? = null,
    val text: String? = null,
    val audioFileName: String? = null,
    val createdAt: String,
)
