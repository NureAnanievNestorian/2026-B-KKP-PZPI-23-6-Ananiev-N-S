package com.nestorian87.eter.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class NotificationTargetRoutePayloadDto(
    val postId: Long? = null,
    val postSlug: String? = null,
    val commentId: Long? = null,
    val postComplaintId: Long? = null,
    val username: String? = null,
)
