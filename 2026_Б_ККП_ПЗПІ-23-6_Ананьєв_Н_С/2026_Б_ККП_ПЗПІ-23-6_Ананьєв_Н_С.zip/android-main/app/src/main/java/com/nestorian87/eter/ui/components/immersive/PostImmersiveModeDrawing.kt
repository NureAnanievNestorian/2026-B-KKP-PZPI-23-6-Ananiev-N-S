package com.nestorian87.eter.ui.components.immersive

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

internal fun DrawScope.drawImmersiveBackground(
    frame: VoiceFrame,
    accent: Float,
    silence: Boolean,
    colors: ImmersiveColors,
) {
    val centerXFraction = 0.5f
    val centerYFraction = 0.44f
    val cornerAccentXFraction = 0.14f
    val cornerAccentYFraction = 0.84f
    val radialRadiusFraction = 0.32f
    val gradientEndXFraction = 0.7f

    val silenceFactor = if (silence) 0.54f else 1f
    val energy = frame.energy * silenceFactor
    val low = frame.low * silenceFactor
    val mid = frame.mid * silenceFactor
    val high = frame.high * silenceFactor
    val totalTone = max(0.001f, low + mid + high)
    val toneLow = low / totalTone
    val toneMid = mid / totalTone
    val toneHigh = high / totalTone
    val yOffset = low * -8.dp.toPx()

    drawRect(
        brush = Brush.linearGradient(
            colors = listOf(colors.bgBase, colors.bgMid, colors.bgEnd),
            start = Offset.Zero,
            end = Offset(size.width * gradientEndXFraction, size.height),
        ),
    )
    drawRect(
        brush = Brush.radialGradient(
            0f to colors.accent1.copy(alpha = colors.accent1A),
            1f to Color.Transparent,
            center = Offset(size.width * centerXFraction, size.height * centerYFraction),
            radius = size.width * radialRadiusFraction,
        ),
    )
    drawRect(
        brush = Brush.radialGradient(
            0f to colors.accent2.copy(alpha = colors.accent2A),
            1f to Color.Transparent,
            center = Offset(
                size.width * cornerAccentXFraction,
                size.height * cornerAccentYFraction
            ),
            radius = size.width * radialRadiusFraction,
        ),
    )

    val paperAlpha = max(0f, 0.64f + energy * 0.22f - if (silence) 0.16f else 0f)
    val paperCenter = Offset(size.width * centerXFraction, size.height * 0.46f + yOffset)
    drawRect(
        brush = Brush.radialGradient(
            0f to colors.toneHigh.copy(alpha = toneHigh * 0.18f * paperAlpha),
            0.36f to colors.toneMid.copy(alpha = toneMid * 0.19f * paperAlpha),
            0.58f to colors.toneLow.copy(alpha = toneLow * 0.16f * paperAlpha),
            0.78f to Color.Transparent,
            center = paperCenter,
            radius = max(size.width, size.height) * (0.5f + energy * 0.007f),
        ),
    )

    val spotAlpha = max(0f, 0.42f + mid * 0.36f + accent * 0.22f - if (silence) 0.14f else 0f)
    val blend = blendTone(colors, toneLow, toneMid, toneHigh)
    drawRect(
        brush = Brush.radialGradient(
            0f to blend.copy(alpha = spotAlpha),
            1f to Color.Transparent,
            center = Offset(size.width * centerXFraction, size.height * centerYFraction + yOffset),
            radius = max(size.width, size.height) * 0.42f,
        ),
    )
}

internal fun DrawScope.drawInk(
    frame: VoiceFrame,
    silence: Boolean,
    timeMs: Float,
    colors: ImmersiveColors,
) {
    val periodMs = 20_000f
    val inkSize = min(size.width, size.height) * 0.5f
    val inkScale = 0.98f + frame.low * 0.06f

    val lowPhase = (timeMs % periodMs) / periodMs
    val lowAlpha = max(0f, 0.2f + frame.low * 0.2f - if (silence) 0.08f else 0f)
    val lowCenter = Offset(
        x = -inkSize * 0.28f + sin(lowPhase * TwoPi) * size.width * 0.07f,
        y = -inkSize * 0.36f + sin(lowPhase * TwoPi + 1f) * size.height * -0.04f,
    )
    drawRect(
        brush = Brush.radialGradient(
            0f to colors.toneLow.copy(alpha = 0.2f * lowAlpha),
            0.68f to Color.Transparent,
            center = lowCenter,
            radius = inkSize * 0.5f * inkScale,
        ),
    )

    val highPhase = ((timeMs + 9_000f) % periodMs) / periodMs
    val highAlpha = max(0f, 0.18f + frame.high * 0.18f - if (silence) 0.08f else 0f)
    val highCenter = Offset(
        x = size.width + inkSize * 0.32f + sin(highPhase * TwoPi) * size.width * 0.07f,
        y = size.height + inkSize * 0.36f + sin(highPhase * TwoPi + 1f) * size.height * -0.04f,
    )
    drawRect(
        brush = Brush.radialGradient(
            0f to Color(0xFFE8BE84).copy(alpha = 0.16f * highAlpha),
            0.68f to Color.Transparent,
            center = highCenter,
            radius = inkSize * 0.5f * inkScale,
        ),
    )
}

internal fun DrawScope.drawBeatPulse(
    frame: VoiceFrame,
    accent: Float,
    silence: Boolean,
    timeMs: Float,
    colors: ImmersiveColors,
) {
    val pulse = max(frame.peak, accent) * if (silence) 0.42f else 1f
    if (pulse < 0.08f) return

    val center = Offset(size.width * 0.5f, size.height * 0.48f - frame.low * 18.dp.toPx())
    val baseRadius = min(size.width, size.height) * (0.18f + pulse * 0.06f)
    val phase = ((timeMs % 920f) / 920f).coerceIn(0f, 1f)
    val radius = baseRadius * (1f + phase * 0.42f)
    val alpha = (0.11f + pulse * 0.16f) * (1f - phase)

    drawCircle(
        brush = Brush.radialGradient(
            0f to colors.toneHigh.copy(alpha = alpha * 0.40f),
            0.58f to colors.toneMid.copy(alpha = alpha * 0.24f),
            1f to Color.Transparent,
            center = center,
            radius = radius,
        ),
        radius = radius,
        center = center,
    )
}

internal fun DrawScope.drawFocusVoiceField(
    frame: VoiceFrame,
    accent: Float,
    silence: Boolean,
    timeMs: Float,
    colors: ImmersiveColors,
) {
    val fieldWidth = size.width * 0.92f
    val fieldHeight = size.height * 0.56f
    val left = (size.width - fieldWidth) / 2f
    val top = size.height * 0.19f
    val silenceFactor = if (silence) 0.54f else 1f
    val energy = frame.energy * silenceFactor
    val opacity = max(0f, 0.62f + energy * 0.24f + accent * 0.18f - if (silence) 0.18f else 0f)
    val scaleFactor = 0.985f + energy * 0.026f + accent * 0.032f + frame.peak * 0.018f

    translate(left, top) {
        scale(scale = scaleFactor, pivot = Offset(fieldWidth / 2f, fieldHeight / 2f)) {
            drawVoiceGlows(Size(fieldWidth, fieldHeight), frame, accent, timeMs, colors, opacity)
            drawVoiceStrokes(
                Size(fieldWidth, fieldHeight),
                frame,
                accent,
                silence,
                timeMs,
                colors,
                opacity
            )
            drawVoiceSparks(Size(fieldWidth, fieldHeight), frame, accent, timeMs, colors)
        }
    }
}

private fun DrawScope.drawVoiceGlows(
    field: Size,
    frame: VoiceFrame,
    accent: Float,
    timeMs: Float,
    colors: ImmersiveColors,
    globalOpacity: Float,
) {
    GlowPresets.forEach { preset ->
        val toneValue = when (preset.tone) {
            VoiceTone.Low -> frame.low
            VoiceTone.Mid -> frame.mid
            VoiceTone.High -> frame.high
        }
        val energy = max(frame.energy, toneValue)
        val sizePct = preset.baseSize + energy * 28f + accent * 10f
        val opacity = (0.16f + energy * 0.28f + accent * 0.08f) * globalOpacity
        val color = when (preset.tone) {
            VoiceTone.Low -> colors.toneLow
            VoiceTone.Mid -> colors.toneMid
            VoiceTone.High -> colors.toneHigh
        }
        val center = Offset(
            x = (preset.x + sin(preset.seed * 1.7f) * frame.zcr * 0.05f) * field.width,
            y = (preset.y + cos(preset.seed * 1.2f) * frame.low * 0.04f) * field.height,
        )
        val rx = field.width * sizePct / 200f
        val ry = rx / 1.4f
        val phase = (((timeMs + preset.seed * -700f) % 11_000f) / 11_000f) * TwoPi
        val breathScale = 1.01f - cos(phase) * 0.07f
        scale(scaleX = breathScale, scaleY = (ry / rx) * breathScale, pivot = center) {
            drawCircle(
                brush = Brush.radialGradient(
                    0f to color.copy(alpha = opacity),
                    0.6f to color.copy(alpha = opacity * 0.35f),
                    1f to Color.Transparent,
                    center = center,
                    radius = rx,
                ),
                radius = rx,
                center = center,
            )
        }
    }
}

private fun DrawScope.drawVoiceStrokes(
    field: Size,
    frame: VoiceFrame,
    accent: Float,
    silence: Boolean,
    timeMs: Float,
    colors: ImmersiveColors,
    globalOpacity: Float,
) {
    val silenceFactor = if (silence) 0.54f else 1f
    val count = if (field.width < MobileCompactWidthBreakpoint.toPx()) 14 else StrokePresets.size
    StrokePresets.take(count).forEach { preset ->
        val rawLevel = (
                frame.energy * 0.22f * silenceFactor +
                        frame.low * preset.lowW * silenceFactor +
                        frame.mid * preset.midW * silenceFactor +
                        frame.high * preset.highW * silenceFactor +
                        frame.peak * preset.peakW * 1.45f * silenceFactor +
                        accent * 0.28f
                ) / 1.9f
        val level = min(1f, max(0.035f, rawLevel.pow(0.72f)))
        val isAccent = accent > AccentStrokeThreshold && preset.isAccentCandidate
        val isWhisper = frame.high > frame.low && preset.isWhisperCandidate
        val mobileScale = if (field.width < MobileCompactWidthBreakpoint.toPx()) 0.72f else 1f
        val halfLen = ((22f + level * 72f + accent * if (isAccent) 32f else 10f) * mobileScale) / 2f
        val halfHeight = (
                (1.4f + level * 2.8f + if (isAccent) accent * 1.5f else 0f) *
                        if (isWhisper) 0.72f else 1f
                ) / 2f
        val opacity = min(
            0.82f,
            0.12f + level * 0.52f + accent * if (isAccent) 0.22f else 0.08f,
        ) * if (isWhisper) 0.82f else 1f
        val scaleX = 0.72f + level * 0.54f

        val driftT = ((((timeMs + preset.driftDelay) % 8_000f) + 8_000f) % 8_000f) / 8_000f
        val driftScale = when {
            driftT <= 0.42f -> driftT / 0.42f
            driftT <= 0.76f -> 1f + ((driftT - 0.42f) / 0.34f) * -1.55f
            else -> -0.55f + ((driftT - 0.76f) / 0.24f) * 0.55f
        }
        val dyScale = when {
            driftT <= 0.42f -> driftScale
            driftT <= 0.76f -> 1f + ((driftT - 0.42f) / 0.34f) * -0.3f
            else -> 0.7f + ((driftT - 0.76f) / 0.24f) * -0.7f
        }
        val center = Offset(
            x = preset.x * field.width + preset.driftX * driftScale,
            y = preset.y * field.height + preset.driftY * dyScale,
        )
        translate(center.x, center.y) {
            rotate(preset.rotate) {
                scale(scaleX = scaleX, scaleY = 1f) {
                    val start = if (isAccent) colors.toneHigh else colors.toneMid
                    val end = if (isAccent) colors.toneMid else colors.toneLow
                    drawRoundRect(
                        brush = Brush.linearGradient(
                            0f to Color.Transparent,
                            0.3f to start.copy(alpha = opacity * globalOpacity),
                            0.7f to end.copy(alpha = opacity * (if (isAccent) 1f else 0.6f) * globalOpacity),
                            1f to Color.Transparent,
                            start = Offset(-halfLen, 0f),
                            end = Offset(halfLen, 0f),
                        ),
                        topLeft = Offset(-halfLen, -halfHeight),
                        size = Size(halfLen * 2f, halfHeight * 2f),
                        cornerRadius = CornerRadius(halfHeight, halfHeight),
                    )
                }
            }
        }
    }
}

private fun DrawScope.drawVoiceSparks(
    field: Size,
    frame: VoiceFrame,
    accent: Float,
    timeMs: Float,
    colors: ImmersiveColors,
) {
    repeat(7) { index ->
        val seed = index + 1f
        val opacity = max(0f, accent * 0.72f + frame.peak * 0.18f - 0.16f)
        if (opacity <= 0.005f) return@repeat
        val x = 0.5f + sin(seed * 2.37f) * (0.18f + frame.zcr * 0.12f)
        val y = 0.5f + cos(seed * 1.81f) * (0.16f + frame.high * 0.14f)
        val radius =
            ((3f + frame.high * 8f + accent * 6f) / 2f) * (0.4f + accent * 1.6f + frame.peak * 0.7f)
        val phase = ((timeMs + seed * -110f) % 680f) / 680f
        val bloom = 1f + sin(phase * TwoPi) * 0.15f
        drawCircle(
            color = colors.toneHigh.copy(alpha = opacity),
            radius = max(0.5f, radius * bloom),
            center = Offset(x * field.width, y * field.height),
        )
    }
}

internal fun DrawScope.drawGrain(
    frame: VoiceFrame,
    colors: ImmersiveColors,
    cache: GrainCache,
) {
    val opacity = 0.065f + frame.high * 0.055f
    val dotStep = 8.dp.toPx().roundToInt().coerceAtLeast(5)

    if (cache.cachedSize != size) {
        cache.cachedSize = size
        val canvasSize = size
        cache.points = buildList {
            var x = 0
            while (x < canvasSize.width.roundToInt()) {
                var y = 0
                while (y < canvasSize.height.roundToInt()) {
                    if (((x * 13 + y * 7) % 17) < 5) {
                        add(Offset(x.toFloat(), y.toFloat()))
                    }
                    y += dotStep
                }
                x += dotStep
            }
        }
    }

    if (cache.points.isNotEmpty()) {
        drawPoints(
            points = cache.points,
            pointMode = PointMode.Points,
            color = colors.grain.copy(alpha = opacity),
            strokeWidth = 1f,
        )
    }

    val verticalStep = 132.dp.toPx().roundToInt().coerceAtLeast(80)
    var x = 0
    while (x < size.width.roundToInt()) {
        drawRect(
            color = colors.grain.copy(alpha = opacity * 0.35f),
            topLeft = Offset(x.toFloat(), 0f),
            size = Size(1f, size.height),
        )
        x += verticalStep
    }
}

private fun blendTone(colors: ImmersiveColors, low: Float, mid: Float, high: Float): Color {
    val lowMid = lerp(colors.toneLow, colors.toneMid, mid.coerceIn(0f, 1f))
    return lerp(lowMid, colors.toneHigh, high.coerceIn(0f, 1f)).copy(
        alpha = (low + mid + high).coerceIn(0f, 1f),
    )
}
