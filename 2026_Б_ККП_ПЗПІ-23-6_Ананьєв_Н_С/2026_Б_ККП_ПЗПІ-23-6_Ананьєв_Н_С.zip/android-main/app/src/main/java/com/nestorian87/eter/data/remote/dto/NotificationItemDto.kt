package com.nestorian87.eter.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class NotificationItemDto(
    val notificationId: Long,
    val notificationType: String,
    val eventsCount: Int = 1,
    val isRead: Boolean = false,
    val isSeen: Boolean = false,
    val postId: Long? = null,
    val postSlug: String? = null,
    val postTitle: String? = null,
    val commentId: Long? = null,
    val postComplaintId: Long? = null,
    val previewText: String? = null,
    val commentPreviewText: String? = null,
    val replyPreviewText: String? = null,
    val targetType: String? = null,
    val targetLabel: String? = null,
    val targetRoutePayload: NotificationTargetRoutePayloadDto? = null,
    val lastEventAt: String,
    val createdAt: String,
    val readAt: String? = null,
    val seenAt: String? = null,
    val lastActor: NotificationActorDto? = null,
)
