package com.nestorian87.eter.ui.screens.feed

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nestorian87.eter.domain.model.Post
import com.nestorian87.eter.domain.model.PostException
import com.nestorian87.eter.domain.repository.PostInteractionStore
import com.nestorian87.eter.domain.repository.PostLikeController
import com.nestorian87.eter.domain.repository.PostRepository
import com.nestorian87.eter.ui.components.layout.PostCardUiModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FeedViewModel @Inject constructor(
    private val postRepository: PostRepository,
    private val postInteractionStore: PostInteractionStore,
    private val postLikeController: PostLikeController,
) : ViewModel() {
    private val _uiState = MutableStateFlow(FeedUiState())
    val uiState: StateFlow<FeedUiState> = _uiState.asStateFlow()

    private var loadJob: Job? = null
    private var didResetOnSnapshotExpired = false
    private var sourcePosts: List<Post> = emptyList()
    private var popularSnapshotId: String? = null
    private var popularNextCursor: String? = null

    init {
        observePostInteractions()
        loadInitial()
    }

    fun loadInitial() {
        if (loadJob?.isActive == true) {
            loadJob?.cancel()
        }

        sourcePosts = emptyList()
        popularSnapshotId = null
        popularNextCursor = null
        _uiState.update {
            it.copy(
                posts = PostListUiState(
                    isInitialLoading = true,
                ),
            )
        }
        loadPage(reset = true)
    }

    fun onLoadMore() {
        val state = _uiState.value.posts
        if (state.isInitialLoading || state.isLoadingMore || !state.canLoadMore) {
            return
        }

        _uiState.update {
            it.copy(
                posts = it.posts.copy(
                    isLoadingMore = true,
                    error = null,
                ),
            )
        }
        loadPage(reset = false)
    }

    fun onToggleLike(postId: Long) {
        val post = _uiState.value.posts.items.firstOrNull { it.post.postId == postId }?.post ?: return
        postLikeController.toggleLike(post)
    }

    private fun observePostInteractions() {
        viewModelScope.launch {
            postInteractionStore.overrides.collect { overrides ->
                _uiState.update { current ->
                    current.copy(
                        posts = current.posts.copy(
                            items = mapUiItems(sourcePosts),
                            pendingLikePostIds = overrides
                                .filterValues { it.isLikePending }
                                .keys,
                        ),
                    )
                }
            }
        }
    }

    private fun loadPage(reset: Boolean) {
        loadJob = viewModelScope.launch {
            loadPopularPage(reset = reset)
        }
    }

    private suspend fun loadPopularPage(reset: Boolean) {
        runCatching {
            postRepository.getPopularPosts(
                snapshotId = if (reset) null else popularSnapshotId,
                cursor = if (reset) null else popularNextCursor,
                limit = PAGE_SIZE,
            )
        }.onSuccess { page ->
            didResetOnSnapshotExpired = false
            val mergedItems = if (reset) {
                page.items
            } else {
                sourcePosts + page.items
            }
            sourcePosts = mergedItems.distinctBy(Post::postId)
            popularSnapshotId = page.snapshotId
            popularNextCursor = page.nextCursor

            _uiState.update { state ->
                state.copy(
                    posts = state.posts.copy(
                        items = mapUiItems(sourcePosts),
                        isInitialLoading = false,
                        isLoadingMore = false,
                        canLoadMore = page.hasMore,
                        error = null,
                    ),
                )
            }
        }.onFailure { error ->
            if (error is CancellationException) {
                throw error
            }

            if (
                error is PostException &&
                error.primaryReason == PostException.Reason.POPULAR_SNAPSHOT_EXPIRED &&
                !didResetOnSnapshotExpired
            ) {
                didResetOnSnapshotExpired = true
                loadInitial()
                return
            }

            _uiState.update { state ->
                state.copy(
                    posts = state.posts.copy(
                        isInitialLoading = false,
                        isLoadingMore = false,
                        error = error,
                    ),
                )
            }
        }
    }

    private fun mapUiItems(posts: List<Post>): List<PostCardUiModel> = posts.map { post ->
        postInteractionStore.ensureLikeBase(post)
        val merged = postInteractionStore.apply(post)
        PostCardUiModel(
            post = merged,
            isLiked = merged.isLiked,
        )
    }

    companion object {
        private const val PAGE_SIZE = 12
    }
}
