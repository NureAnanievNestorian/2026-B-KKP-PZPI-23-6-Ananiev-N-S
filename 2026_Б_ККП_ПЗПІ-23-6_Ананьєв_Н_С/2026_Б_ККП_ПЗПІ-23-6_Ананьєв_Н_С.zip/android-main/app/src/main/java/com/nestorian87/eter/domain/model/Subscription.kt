package com.nestorian87.eter.domain.model

data class Subscription(
    val subscriptionId: Long,
    val userId: Long,
    val status: SubscriptionStatus,
    val startDate: String?,
    val nextPaymentDate: String?,
    val cancellationDate: String?,
    val walletId: String?,
    val card: SubscriptionCard?,
) {
    val isPremium: Boolean get() = status.isPremium
}
