package com.nestorian87.eter.data.mapper

import com.nestorian87.eter.data.remote.dto.ActiveViolationResponseDto
import com.nestorian87.eter.data.remote.dto.ComplaintReasonItemDto
import com.nestorian87.eter.data.remote.dto.ProfileFollowListItemDto
import com.nestorian87.eter.data.remote.dto.ProfileFollowListPageResponseDto
import com.nestorian87.eter.data.remote.dto.ProfileMeDto
import com.nestorian87.eter.data.remote.dto.PublicProfileDto
import com.nestorian87.eter.data.remote.dto.ViolationTargetPostDto
import com.nestorian87.eter.domain.model.ActiveViolation
import com.nestorian87.eter.domain.model.ComplaintReasonItem
import com.nestorian87.eter.domain.model.FollowProfilesPage
import com.nestorian87.eter.domain.model.OwnProfile
import com.nestorian87.eter.domain.model.ProfileFollowListItem
import com.nestorian87.eter.domain.model.PublicProfile
import com.nestorian87.eter.domain.model.ViolationStatus
import com.nestorian87.eter.domain.model.ViolationTargetPost

fun ProfileMeDto.toOwnProfile(): OwnProfile = OwnProfile(
    userId = userId,
    name = name,
    username = username,
    email = email,
    photo = photo,
    bio = bio,
    link = link,
    isEmailVerified = isEmailVerified,
    isPremium = isPremium,
    createdAt = createdAt,
    followersCount = followersCount,
    followingCount = followingCount,
    postsCount = postsCount,
    currentViolationsCount = currentViolationsCount,
    maxViolationsBeforeBlock = maxViolationsBeforeBlock,
)

fun PublicProfileDto.toDomain(): PublicProfile = PublicProfile(
    userId = userId,
    name = name,
    username = username,
    photo = photo,
    bio = bio,
    link = link,
    isPremium = isPremium,
    isSubscribed = isSubscribed,
    createdAt = createdAt,
    followersCount = followersCount,
    followingCount = followingCount,
    postsCount = postsCount,
)

fun ProfileFollowListPageResponseDto.toDomain(): FollowProfilesPage = FollowProfilesPage(
    items = items.map(ProfileFollowListItemDto::toDomain),
    total = total,
    limit = limit,
    nextCursor = nextCursor,
    hasMore = hasMore,
)

fun ProfileFollowListItemDto.toDomain(): ProfileFollowListItem = ProfileFollowListItem(
    userId = userId,
    name = name,
    username = username,
    photo = photo,
    isPremium = isPremium,
    isSubscribed = isSubscribed,
)

fun ComplaintReasonItemDto.toDomain(): ComplaintReasonItem = ComplaintReasonItem(
    key = key,
    label = label,
)

fun ActiveViolationResponseDto.toDomain(): ActiveViolation = ActiveViolation(
    complaintId = complaintId,
    complaintReason = complaintReason,
    status = status.toViolationStatus(),
    createdAt = createdAt,
    expiresAt = expiresAt,
    targetPost = targetPost.toDomain(),
)

fun ViolationTargetPostDto.toDomain(): ViolationTargetPost = ViolationTargetPost(
    postId = postId,
    title = title,
    description = description,
    text = text,
    audioFileName = audioFileName,
    createdAt = createdAt,
)

private fun String.toViolationStatus(): ViolationStatus = when (lowercase()) {
    "pending" -> ViolationStatus.PENDING
    "resolved" -> ViolationStatus.RESOLVED
    "dismissed" -> ViolationStatus.DISMISSED
    else -> ViolationStatus.UNKNOWN
}
