package com.nestorian87.eter.domain.model

enum class SubscriptionStatus {
    CREATED,
    ACTIVE,
    PAST_DUE,
    CANCELLED,
    EXPIRED,
    UNKNOWN;

    val isPremium: Boolean get() = this == ACTIVE

    companion object {
        fun fromString(value: String): SubscriptionStatus = when (value.lowercase()) {
            "created" -> CREATED
            "active" -> ACTIVE
            "past_due" -> PAST_DUE
            "cancelled" -> CANCELLED
            "expired" -> EXPIRED
            else -> UNKNOWN
        }
    }
}
