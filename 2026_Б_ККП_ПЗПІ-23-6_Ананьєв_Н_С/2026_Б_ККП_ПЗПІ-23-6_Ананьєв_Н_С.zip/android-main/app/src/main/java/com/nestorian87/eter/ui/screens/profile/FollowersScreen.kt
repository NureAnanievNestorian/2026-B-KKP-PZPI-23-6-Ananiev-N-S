package com.nestorian87.eter.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nestorian87.eter.R
import com.nestorian87.eter.domain.model.ProfileFollowListItem
import com.nestorian87.eter.ui.components.buttons.BackIconButton
import com.nestorian87.eter.ui.components.buttons.PrimaryActionButton
import com.nestorian87.eter.ui.components.buttons.SecondaryActionButton
import com.nestorian87.eter.ui.components.feedback.EterLoadingIndicator
import com.nestorian87.eter.ui.components.forms.SearchInputField
import com.nestorian87.eter.ui.components.layout.AuthorAvatar
import com.nestorian87.eter.ui.theme.EterPreview
import com.nestorian87.eter.ui.theme.EterScreenPreviews
import com.nestorian87.eter.ui.theme.EterSpacing

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FollowersScreen(
    profileUserId: Long,
    initialTab: String,
    modifier: Modifier = Modifier,
    onBack: () -> Unit = {},
    onLoginRequested: () -> Unit = {},
    onOpenProfile: (Long) -> Unit = {},
    viewModel: ProfileViewModel = hiltViewModel<ProfileViewModel, ProfileViewModel.Factory> { factory ->
        factory.create(profileUserId, null)
    },
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val initialType = if (initialTab == "following") {
        ProfileFollowListType.FOLLOWING
    } else {
        ProfileFollowListType.FOLLOWERS
    }

    LaunchedEffect(viewModel, initialType) {
        viewModel.onOpenFollowDialog(initialType)
        viewModel.effects.collect { effect ->
            when (effect) {
                ProfileEffect.NavigateToLogin -> onLoginRequested()
                ProfileEffect.NavigateToOwnProfile -> Unit
                ProfileEffect.ProfileSaved -> Unit
                is ProfileEffect.ShareProfile -> Unit
            }
        }
    }

    FollowersScreenContent(
        uiState = uiState,
        modifier = modifier,
        onBack = onBack,
        onSelectTab = viewModel::onOpenFollowDialog,
        onSearchChanged = viewModel::onFollowDialogSearchChanged,
        onLoadMore = viewModel::onLoadMoreFollowItems,
        onToggleFollow = viewModel::onToggleFollowDialogItem,
        onOpenProfile = onOpenProfile,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FollowersScreenContent(
    uiState: ProfileUiState,
    onBack: () -> Unit,
    onSelectTab: (ProfileFollowListType) -> Unit,
    onSearchChanged: (String) -> Unit,
    onLoadMore: () -> Unit,
    onToggleFollow: (Long) -> Unit,
    onOpenProfile: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    val followState = uiState.followDialog
    var isSearchVisible by rememberSaveable(followState.searchQuery) {
        mutableStateOf(followState.searchQuery.isNotBlank())
    }

    Surface(
        modifier = modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.background,
                            MaterialTheme.colorScheme.surface,
                        ),
                    ),
                ),
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
                contentPadding = PaddingValues(
                    start = EterSpacing.xxLarge,
                    end = EterSpacing.xxLarge,
                    top = EterSpacing.large,
                    bottom = EterSpacing.hero,
                ),
            ) {
                item(key = "followers_header") {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            BackIconButton(onClick = onBack)
                            IconButton(
                                onClick = {
                                    isSearchVisible = !isSearchVisible
                                },
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Search,
                                    contentDescription = stringResource(R.string.search),
                                    modifier = Modifier.graphicsLayer(scaleX = -1f),
                                )
                            }
                        }

                        Text(
                            text = uiState.name.ifBlank { stringResource(R.string.profile_default_name) },
                            style = MaterialTheme.typography.headlineLarge,
                            color = MaterialTheme.colorScheme.onBackground,
                        )

                        PrimaryTabRow(
                            selectedTabIndex = if (followState.type == ProfileFollowListType.FOLLOWERS) 0 else 1,
                            containerColor = Color.Transparent,
                            divider = {
                                TabRowDefaults.SecondaryIndicator(
                                    modifier = Modifier.fillMaxWidth(),
                                    height = 0.5.dp,
                                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.16f),
                                )
                            },
                        ) {
                            Tab(
                                selected = followState.type == ProfileFollowListType.FOLLOWERS,
                                onClick = { onSelectTab(ProfileFollowListType.FOLLOWERS) },
                                text = { Text(text = stringResource(R.string.followers)) },
                            )
                            Tab(
                                selected = followState.type == ProfileFollowListType.FOLLOWING,
                                onClick = { onSelectTab(ProfileFollowListType.FOLLOWING) },
                                text = { Text(text = stringResource(R.string.following)) },
                            )
                        }

                        if (isSearchVisible || followState.searchQuery.isNotBlank()) {
                            SearchInputField(
                                value = followState.searchQuery,
                                onValueChange = onSearchChanged,
                                label = stringResource(R.string.profile_follow_search_label),
                                placeholder = stringResource(R.string.profile_follow_search_placeholder),
                            )
                        }
                    }
                }

                when {
                    followState.isInitialLoading -> {
                        item(key = "followers_loading") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = EterSpacing.hero),
                                contentAlignment = Alignment.Center,
                            ) {
                                EterLoadingIndicator()
                            }
                        }
                    }

                    followState.error != null && followState.items.isEmpty() -> {
                        item(key = "followers_error") {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = EterSpacing.large),
                                verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
                            ) {
                                Text(
                                    text = stringResource(R.string.profile_error_generic),
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                SecondaryActionButton(
                                    text = stringResource(R.string.feed_retry),
                                    onClick = { onSelectTab(followState.type) },
                                )
                                HorizontalDivider(
                                    color = MaterialTheme.colorScheme.outline.copy(
                                        alpha = 0.16f
                                    )
                                )
                            }
                        }
                    }

                    followState.items.isEmpty() -> {
                        item(key = "followers_empty") {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = EterSpacing.section),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
                            ) {
                                Text(
                                    text = stringResource(R.string.profile_follow_empty),
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                HorizontalDivider(
                                    color = MaterialTheme.colorScheme.outline.copy(
                                        alpha = 0.16f
                                    )
                                )
                            }
                        }
                    }

                    else -> {
                        items(
                            items = followState.items,
                            key = { item -> item.userId },
                        ) { item ->
                            FollowListRow(
                                item = item,
                                isYou = uiState.profileUserId == item.userId,
                                isAuthenticated = uiState.isAuthenticated,
                                isPending = followState.pendingUserIds.contains(item.userId),
                                onToggleFollow = { onToggleFollow(item.userId) },
                                onOpenProfile = { onOpenProfile(item.userId) },
                            )
                        }

                        if (followState.hasMore) {
                            item(key = "followers_load_more") {
                                SecondaryActionButton(
                                    text = stringResource(R.string.profile_load_more),
                                    enabled = !followState.isLoadingMore,
                                    onClick = onLoadMore,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FollowListRow(
    item: ProfileFollowListItem,
    isYou: Boolean,
    isAuthenticated: Boolean,
    isPending: Boolean,
    onToggleFollow: () -> Unit,
    onOpenProfile: () -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onOpenProfile)
                .padding(vertical = EterSpacing.small),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium),
        ) {
            AuthorAvatar(
                name = item.name,
                photoUrl = item.photo,
                size = 44.dp,
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
            ) {
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = if (isYou) {
                        stringResource(R.string.profile_follow_you)
                    } else {
                        stringResource(R.string.profile_username_format, item.username)
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (!isYou) {
                val buttonText = when {
                    !isAuthenticated -> stringResource(R.string.auth_login_short_cta)
                    item.isSubscribed -> stringResource(R.string.profile_unfollow_cta)
                    else -> stringResource(R.string.profile_follow_cta)
                }

                if (item.isSubscribed) {
                    SecondaryActionButton(
                        text = buttonText,
                        modifier = Modifier.width(136.dp),
                        enabled = !isPending,
                        onClick = onToggleFollow,
                        isSmall = true
                    )
                } else {
                    PrimaryActionButton(
                        text = buttonText,
                        modifier = Modifier.width(136.dp),
                        enabled = !isPending,
                        onClick = onToggleFollow,
                        isSmall = true
                    )
                }
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.14f))
    }
}

@EterScreenPreviews
@Composable
private fun FollowersScreenPreview() {
    EterPreview {
        FollowersScreenContent(
            uiState = ProfileUiState(
                isLoadingProfile = false,
                profileUserId = 1L,
                name = "Nestorian",
                followDialog = ProfileFollowDialogUiState(
                    type = ProfileFollowListType.FOLLOWERS,
                    items = listOf(
                        ProfileFollowListItem(
                            userId = 2L,
                            name = "Eter User",
                            username = "eter_user",
                            photo = null,
                            isPremium = false,
                            isSubscribed = true,
                        ),
                    ),
                ),
            ),
            onBack = {},
            onSelectTab = {},
            onSearchChanged = {},
            onLoadMore = {},
            onToggleFollow = {},
            onOpenProfile = {},
        )
    }
}
