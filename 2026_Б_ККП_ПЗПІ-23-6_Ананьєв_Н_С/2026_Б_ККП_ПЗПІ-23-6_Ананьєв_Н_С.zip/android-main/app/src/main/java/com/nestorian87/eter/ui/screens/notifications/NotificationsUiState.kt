package com.nestorian87.eter.ui.screens.notifications

import com.nestorian87.eter.domain.model.NotificationItem

data class NotificationsUiState(
    val items: List<NotificationItem> = emptyList(),
    val selectedFilter: NotificationsFilter = NotificationsFilter.ALL,
    val unreadCount: Int = 0,
    val unseenCount: Int = 0,
    val isInitialLoading: Boolean = true,
    val isLoadingMore: Boolean = false,
    val canLoadMore: Boolean = false,
    val isMarkAllReadLoading: Boolean = false,
    val pendingNotificationIds: Set<Long> = emptySet(),
    val error: Throwable? = null,
)

enum class NotificationsFilter {
    ALL,
    UNREAD,
    COMMENTS,
    FOLLOWS,
}
