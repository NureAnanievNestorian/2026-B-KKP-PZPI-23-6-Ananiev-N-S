package com.nestorian87.eter.domain.model

data class PushNotificationSettings(
    val disabledTypes: Set<NotificationType> = emptySet(),
)
