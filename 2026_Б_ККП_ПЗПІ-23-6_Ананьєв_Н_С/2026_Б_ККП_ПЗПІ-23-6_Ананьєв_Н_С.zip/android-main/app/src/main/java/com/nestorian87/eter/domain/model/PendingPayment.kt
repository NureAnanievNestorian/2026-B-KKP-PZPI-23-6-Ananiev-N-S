package com.nestorian87.eter.domain.model

import kotlinx.serialization.Serializable

@Serializable
data class PendingPayment(
    val invoiceId: String,
    val paymentType: String,
) {
    companion object {
        const val PAYMENT_TYPE_CHECKOUT = "checkout"
        const val PAYMENT_TYPE_CARD_UPDATE = "card_update"
        val supportedPaymentTypes = setOf(PAYMENT_TYPE_CHECKOUT, PAYMENT_TYPE_CARD_UPDATE)
    }
}
