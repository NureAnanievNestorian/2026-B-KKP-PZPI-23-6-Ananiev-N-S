package com.nestorian87.eter.data.repository

import com.nestorian87.eter.data.mapper.toDomain
import com.nestorian87.eter.data.remote.api.Api
import com.nestorian87.eter.data.remote.dto.SubscriptionDto
import com.nestorian87.eter.domain.model.CheckoutResult
import com.nestorian87.eter.domain.model.Subscription
import com.nestorian87.eter.domain.model.SubscriptionTransactionsPage
import com.nestorian87.eter.domain.repository.PaymentRepository
import kotlinx.serialization.json.Json
import retrofit2.HttpException
import javax.inject.Inject

class PaymentRepositoryImpl @Inject constructor(
    private val api: Api,
    private val json: Json,
) : PaymentRepository {
    private val serverErrorMapper = PaymentServerErrorMapper()

    override suspend fun getSubscription(): Subscription? = executePaymentRequest(
        httpErrorMapper = serverErrorMapper::toCommonException,
    ) {
        val response = api.getSubscription()
        if (!response.isSuccessful) throw HttpException(response)
        val body = response.body()?.string()
        if (body.isNullOrBlank()) return@executePaymentRequest null
        json.decodeFromString<SubscriptionDto>(body).toDomain()
    }

    override suspend fun createCheckout(): CheckoutResult = executePaymentRequest(
        httpErrorMapper = serverErrorMapper::toCheckoutException,
    ) {
        api.createSubscriptionCheckout().toDomain()
    }

    override suspend fun cancelSubscription() = executePaymentRequest(
        httpErrorMapper = serverErrorMapper::toCancelException,
    ) {
        api.cancelSubscription()
        Unit
    }

    override suspend fun getTransactions(
        offset: Int,
        limit: Int,
    ): SubscriptionTransactionsPage = executePaymentRequest(
        httpErrorMapper = serverErrorMapper::toCommonException,
    ) {
        api.getSubscriptionTransactions(offset = offset, limit = limit).toDomain()
    }

    override suspend fun updateCard(): CheckoutResult = executePaymentRequest(
        httpErrorMapper = serverErrorMapper::toCardUpdateException,
    ) {
        api.updateSubscriptionCard().toDomain()
    }
}
