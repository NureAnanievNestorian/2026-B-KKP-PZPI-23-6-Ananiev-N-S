package com.nestorian87.eter.data.local.datastore

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import com.nestorian87.eter.domain.model.PostCommentDraft
import com.nestorian87.eter.domain.repository.PostCommentDraftRepository
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PostCommentDraftRepositoryImpl @Inject constructor(
    private val dataStore: DataStore<Preferences>,
    private val json: Json,
) : PostCommentDraftRepository {
    override suspend fun getDraft(postId: Long): PostCommentDraft? =
        dataStore.data
            .catch { emit(emptyPreferences()) }
            .map { preferences -> preferences[draftKey(postId)] }
            .first()
            ?.let { encoded ->
                runCatching {
                    json.decodeFromString(PersistedPostCommentDraft.serializer(), encoded)
                        .toDomain()
                }.getOrNull()
            }

    override suspend fun saveDraft(draft: PostCommentDraft) {
        dataStore.edit { preferences ->
            preferences[draftKey(draft.postId)] = json.encodeToString(
                PersistedPostCommentDraft.serializer(),
                draft.toPersisted(),
            )
        }
    }

    override suspend fun deleteDraft(postId: Long) {
        dataStore.edit { preferences ->
            preferences.remove(draftKey(postId))
        }
    }

    private fun draftKey(postId: Long) = stringPreferencesKey("post_comment_draft_$postId")
}

@Serializable
private data class PersistedPostCommentDraft(
    val postId: Long,
    val commentText: String = "",
    val replyDraftByCommentId: Map<Long, String> = emptyMap(),
)

private fun PersistedPostCommentDraft.toDomain(): PostCommentDraft = PostCommentDraft(
    postId = postId,
    commentText = commentText,
    replyDraftByCommentId = replyDraftByCommentId,
)

private fun PostCommentDraft.toPersisted(): PersistedPostCommentDraft = PersistedPostCommentDraft(
    postId = postId,
    commentText = commentText,
    replyDraftByCommentId = replyDraftByCommentId,
)
