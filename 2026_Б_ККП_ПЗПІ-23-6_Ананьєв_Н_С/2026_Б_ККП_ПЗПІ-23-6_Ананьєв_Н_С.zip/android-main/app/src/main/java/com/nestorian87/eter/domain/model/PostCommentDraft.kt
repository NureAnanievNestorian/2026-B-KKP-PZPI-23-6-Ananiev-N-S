package com.nestorian87.eter.domain.model

data class PostCommentDraft(
    val postId: Long,
    val commentText: String = "",
    val replyDraftByCommentId: Map<Long, String> = emptyMap(),
)
