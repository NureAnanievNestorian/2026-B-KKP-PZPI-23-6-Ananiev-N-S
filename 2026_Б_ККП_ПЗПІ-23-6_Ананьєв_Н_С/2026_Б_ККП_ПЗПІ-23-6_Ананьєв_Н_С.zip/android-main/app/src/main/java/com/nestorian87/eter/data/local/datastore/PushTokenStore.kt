package com.nestorian87.eter.data.local.datastore

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PushTokenStore @Inject constructor(
    private val dataStore: DataStore<Preferences>,
) {
    suspend fun readToken(): String? =
        dataStore.data
            .catch { emit(emptyPreferences()) }
            .map { preferences -> preferences[TokenKey] }
            .first()
            ?.trim()
            ?.takeIf { it.isNotEmpty() }

    suspend fun saveToken(token: String) {
        dataStore.edit { preferences ->
            preferences[TokenKey] = token.trim()
        }
    }

    suspend fun clearToken() {
        dataStore.edit { preferences ->
            preferences.remove(TokenKey)
        }
    }

    private companion object {
        val TokenKey = stringPreferencesKey("android_push_token")
    }
}
