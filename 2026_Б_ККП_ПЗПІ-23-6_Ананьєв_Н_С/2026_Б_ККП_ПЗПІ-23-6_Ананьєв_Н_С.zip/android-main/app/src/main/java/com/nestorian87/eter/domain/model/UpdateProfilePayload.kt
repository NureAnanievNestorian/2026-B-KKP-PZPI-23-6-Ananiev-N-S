package com.nestorian87.eter.domain.model

data class UpdateProfilePayload(
    val name: String,
    val username: String,
    val bio: String? = null,
    val link: String? = null,
)
