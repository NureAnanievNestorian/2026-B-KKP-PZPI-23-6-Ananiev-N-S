package com.nestorian87.eter.ui.screens.payment

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nestorian87.eter.R
import com.nestorian87.eter.domain.model.SubscriptionTransaction
import com.nestorian87.eter.domain.model.TransactionStatus
import com.nestorian87.eter.domain.model.TransactionType
import com.nestorian87.eter.domain.model.toCurrencySymbol
import com.nestorian87.eter.ui.components.buttons.PrimaryActionButton
import com.nestorian87.eter.ui.components.buttons.SecondaryActionButton
import com.nestorian87.eter.ui.components.feedback.EterLoadingIndicator
import com.nestorian87.eter.ui.theme.EditorialPanelShape
import com.nestorian87.eter.ui.theme.EterPreview
import com.nestorian87.eter.ui.theme.EterScreenPreviews
import com.nestorian87.eter.ui.theme.EterSpacing

@Composable
fun PaymentReturnScreen(
    modifier: Modifier = Modifier,
    invoiceId: String,
    paymentType: String,
    onBack: () -> Unit = {},
) {
    val viewModel: PaymentReturnViewModel =
        hiltViewModel<PaymentReturnViewModel, PaymentReturnViewModel.Factory> { factory ->
            factory.create(invoiceId, paymentType)
        }
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        viewModel.effects.collect { effect ->
            when (effect) {
                is PaymentReturnEffect.NavigateAway -> onBack()
            }
        }
    }

    PaymentReturnContent(
        uiState = uiState,
        onDismiss = onBack,
        modifier = modifier,
    )
}

@Composable
private fun PaymentReturnContent(
    uiState: PaymentReturnUiState,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f)),
        contentAlignment = Alignment.BottomCenter,
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = EditorialPanelShape,
            color = MaterialTheme.colorScheme.background,
            tonalElevation = 0.dp,
            border = androidx.compose.foundation.BorderStroke(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f),
            ),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = EterSpacing.small, vertical = EterSpacing.xSmall),
                    horizontalArrangement = Arrangement.End,
                ) {
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = stringResource(R.string.payment_return_close),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                when (uiState.phase) {
                    PaymentReturnPhase.CHECKING -> CheckingContent()
                    PaymentReturnPhase.SUCCESS_CHECKOUT -> SuccessContent(
                        message = stringResource(R.string.payment_return_success_checkout),
                        onDone = onDismiss,
                    )

                    PaymentReturnPhase.SUCCESS_CARD -> SuccessContent(
                        message = stringResource(R.string.payment_return_success_card),
                        onDone = onDismiss,
                    )

                    PaymentReturnPhase.FAILURE -> FailureContent(
                        transactions = uiState.failureTransactions,
                        onRetry = onDismiss,
                    )
                }

                Spacer(Modifier.height(EterSpacing.xxLarge))
            }
        }
    }
}

@Composable
private fun CheckingContent(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = EterSpacing.large)
            .padding(bottom = EterSpacing.xxLarge),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(EterSpacing.large),
    ) {
        EterLoadingIndicator()
        Text(
            text = stringResource(R.string.payment_return_checking),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun SuccessContent(
    message: String,
    onDone: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = EterSpacing.large),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(EterSpacing.large),
    ) {
        Icon(
            imageVector = Icons.Filled.CheckCircle,
            contentDescription = null,
            tint = Color(0xFF4CAF50),
            modifier = Modifier.size(56.dp),
        )
        Text(
            text = message,
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(EterSpacing.small))
        PrimaryActionButton(
            text = stringResource(R.string.payment_return_done),
            onClick = onDone,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun FailureContent(
    transactions: List<SubscriptionTransaction>,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = EterSpacing.large),
        verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
        ) {
            Icon(
                imageVector = Icons.Filled.Error,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(56.dp),
            )
            Text(
                text = stringResource(R.string.payment_return_failure_title),
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center,
            )
            Text(
                text = stringResource(R.string.payment_return_failure_message),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
        }

        if (transactions.isNotEmpty()) {
            Spacer(Modifier.height(EterSpacing.small))
            transactions.forEach { transaction ->
                ReturnTransactionCard(transaction = transaction)
            }

            Spacer(Modifier.height(EterSpacing.small))
        }

        SecondaryActionButton(
            text = stringResource(R.string.payment_return_retry),
            onClick = onRetry,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun ReturnTransactionCard(
    transaction: SubscriptionTransaction,
    modifier: Modifier = Modifier,
) {
    val statusText = stringResource(
        when (transaction.status) {
            TransactionStatus.SUCCESS -> R.string.subscription_transaction_status_success
            TransactionStatus.FAILURE -> R.string.subscription_transaction_status_failure
            TransactionStatus.PROCESSING -> R.string.subscription_transaction_status_processing
            TransactionStatus.CREATED -> R.string.subscription_transaction_status_pending
            TransactionStatus.HOLD -> R.string.subscription_transaction_status_hold
            TransactionStatus.REVERSED -> R.string.subscription_transaction_status_reversed
            TransactionStatus.EXPIRED -> R.string.subscription_transaction_status_expired
            TransactionStatus.UNKNOWN, null -> R.string.subscription_transaction_status_unknown
        },
    )
    val statusColor = when (transaction.status) {
        TransactionStatus.SUCCESS -> Color(0xFF4CAF50)
        TransactionStatus.FAILURE, TransactionStatus.REVERSED, TransactionStatus.EXPIRED ->
            MaterialTheme.colorScheme.error

        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = EditorialPanelShape,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.18f),
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f),
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(EterSpacing.medium),
            verticalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
        ) {
            ReturnTransactionField(
                label = stringResource(R.string.subscription_transaction_date_label),
                value = transaction.createdAt.take(10).formatYmdToDisplay(),
            )
            ReturnTransactionField(
                label = stringResource(R.string.subscription_transaction_amount_label),
                value = "${transaction.amount.formatAmount()}${transaction.currency.toCurrencySymbol()}",
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = stringResource(R.string.subscription_transaction_status_label),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.width(80.dp),
                )
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                    color = statusColor,
                )
            }
        }
    }
}

@Composable
private fun ReturnTransactionField(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(80.dp),
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
        )
    }
}

private fun String.formatYmdToDisplay(): String {
    if (length < 10 || this[4] != '-') return this
    val parts = substring(0, 10).split("-")
    return "${parts[2]}.${parts[1]}.${parts[0]}"
}

private fun String.formatAmount(): String {
    val d = toDoubleOrNull() ?: return this
    return if (d % 1.0 == 0.0) d.toInt().toString() else this
}

@EterScreenPreviews
@Composable
private fun PaymentReturnCheckingPreview() {
    EterPreview {
        PaymentReturnContent(
            uiState = PaymentReturnUiState(phase = PaymentReturnPhase.CHECKING),
            onDismiss = {},
        )
    }
}

@EterScreenPreviews
@Composable
private fun PaymentReturnSuccessPreview() {
    EterPreview {
        PaymentReturnContent(
            uiState = PaymentReturnUiState(phase = PaymentReturnPhase.SUCCESS_CHECKOUT),
            onDismiss = {},
        )
    }
}

@EterScreenPreviews
@Composable
private fun PaymentReturnFailurePreview() {
    EterPreview {
        PaymentReturnContent(
            uiState = PaymentReturnUiState(
                phase = PaymentReturnPhase.FAILURE,
                failureTransactions = listOf(
                    SubscriptionTransaction(
                        transactionId = 1,
                        invoiceId = "inv-1",
                        status = TransactionStatus.FAILURE,
                        type = TransactionType.CHARGE,
                        amount = "5.00",
                        currency = "USD",
                        isCardUpdating = false,
                        modifiedDate = null,
                        createdAt = "2025-05-19T10:00:00.000Z",
                        updatedAt = "2025-05-19T10:00:00.000Z",
                    ),
                ),
            ),
            onDismiss = {},
        )
    }
}
