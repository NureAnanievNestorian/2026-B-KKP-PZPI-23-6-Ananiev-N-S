package com.nestorian87.eter.ui.screens.create

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import com.nestorian87.eter.R
import com.nestorian87.eter.ui.components.layout.PlaceholderScreen
import com.nestorian87.eter.ui.theme.EterPreview
import com.nestorian87.eter.ui.theme.EterScreenPreviews

@Composable
fun LyricSyncScreen(modifier: Modifier = Modifier) {
    PlaceholderScreen(
        title = stringResource(R.string.lyric_sync),
        description = stringResource(R.string.lyric_sync_placeholder_description),
        modifier = modifier,
    )
}

@EterScreenPreviews
@Composable
private fun LyricSyncScreenPreview() {
    EterPreview {
        LyricSyncScreen()
    }
}
