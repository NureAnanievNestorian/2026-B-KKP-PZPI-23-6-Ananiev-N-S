package com.nestorian87.eter.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class SubscriptionCardDto(
    val cardId: Long,
    val paymentSystem: String,
    val maskedNumber: String,
)
