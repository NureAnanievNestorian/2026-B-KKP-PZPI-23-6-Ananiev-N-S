package com.nestorian87.eter.data.repository

import com.nestorian87.eter.data.mapper.toDomain
import com.nestorian87.eter.data.mapper.toOwnProfile
import com.nestorian87.eter.data.remote.api.Api
import com.nestorian87.eter.data.remote.dto.UpdateProfileRequestDto
import com.nestorian87.eter.domain.model.ActiveViolation
import com.nestorian87.eter.domain.model.FollowProfilesPage
import com.nestorian87.eter.domain.model.FollowProfilesQuery
import com.nestorian87.eter.domain.model.OwnProfile
import com.nestorian87.eter.domain.model.PublicProfile
import com.nestorian87.eter.domain.model.UpdateProfilePayload
import com.nestorian87.eter.domain.repository.ProfileRepository
import com.nestorian87.eter.domain.util.ProfileAvatarUpload
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import javax.inject.Inject

class ProfileRepositoryImpl @Inject constructor(
    private val api: Api,
    json: Json,
) : ProfileRepository {
    private val serverErrorMapper = ProfileServerErrorMapper(json)

    override suspend fun getMyProfile(): OwnProfile = executeProfileRequest(
        httpErrorMapper = serverErrorMapper::toCommonException,
    ) {
        api.getProfileMe().toOwnProfile()
    }

    override suspend fun getPublicProfile(userId: Long): PublicProfile = executeProfileRequest(
        httpErrorMapper = serverErrorMapper::toCommonException,
    ) {
        api.getProfile(userId = userId).toDomain()
    }

    override suspend fun getPublicProfile(username: String): PublicProfile = executeProfileRequest(
        httpErrorMapper = serverErrorMapper::toCommonException,
    ) {
        api.getProfileByUsername(username = username.trim()).toDomain()
    }

    override suspend fun updateMyProfile(payload: UpdateProfilePayload): OwnProfile =
        executeProfileRequest(
            httpErrorMapper = serverErrorMapper::toUpdateProfileException,
        ) {
            api.updateProfileMe(
                request = UpdateProfileRequestDto(
                    name = payload.name.trim(),
                    username = payload.username.trim(),
                    bio = payload.bio?.trim()?.takeIf { it.isNotEmpty() },
                    link = payload.link?.trim()?.takeIf { it.isNotEmpty() },
                ),
            ).toOwnProfile()
        }

    override suspend fun updateMyAvatar(avatarFile: File): OwnProfile = executeProfileRequest(
        httpErrorMapper = serverErrorMapper::toUpdateProfileException,
    ) {
        api.updateProfileMeAvatar(
            avatar = avatarFile.toAvatarPart(),
        ).toOwnProfile()
    }

    override suspend fun removeMyAvatar(): OwnProfile = executeProfileRequest(
        httpErrorMapper = serverErrorMapper::toUpdateProfileException,
    ) {
        api.deleteProfileMeAvatar().toOwnProfile()
    }

    override suspend fun followProfile(userId: Long): PublicProfile = executeProfileRequest(
        httpErrorMapper = serverErrorMapper::toCommonException,
    ) {
        api.followProfile(userId = userId).toDomain()
    }

    override suspend fun unfollowProfile(userId: Long): PublicProfile = executeProfileRequest(
        httpErrorMapper = serverErrorMapper::toCommonException,
    ) {
        api.unfollowProfile(userId = userId).toDomain()
    }

    override suspend fun getMyFollowers(query: FollowProfilesQuery): FollowProfilesPage =
        executeProfileRequest(
            httpErrorMapper = serverErrorMapper::toCommonException,
        ) {
            api.getMyFollowers(
                search = query.search?.trim()?.takeIf { it.isNotEmpty() },
                cursor = query.cursor,
                limit = query.limit,
            ).toDomain()
        }

    override suspend fun getMyFollowing(query: FollowProfilesQuery): FollowProfilesPage =
        executeProfileRequest(
            httpErrorMapper = serverErrorMapper::toCommonException,
        ) {
            api.getMyFollowing(
                search = query.search?.trim()?.takeIf { it.isNotEmpty() },
                cursor = query.cursor,
                limit = query.limit,
            ).toDomain()
        }

    override suspend fun getFollowers(
        userId: Long,
        query: FollowProfilesQuery,
    ): FollowProfilesPage = executeProfileRequest(
        httpErrorMapper = serverErrorMapper::toCommonException,
    ) {
        api.getFollowers(
            userId = userId,
            search = query.search?.trim()?.takeIf { it.isNotEmpty() },
            cursor = query.cursor,
            limit = query.limit,
        ).toDomain()
    }

    override suspend fun getFollowing(
        userId: Long,
        query: FollowProfilesQuery,
    ): FollowProfilesPage = executeProfileRequest(
        httpErrorMapper = serverErrorMapper::toCommonException,
    ) {
        api.getFollowing(
            userId = userId,
            search = query.search?.trim()?.takeIf { it.isNotEmpty() },
            cursor = query.cursor,
            limit = query.limit,
        ).toDomain()
    }

    override suspend fun getMyViolations(): List<ActiveViolation> = executeProfileRequest(
        httpErrorMapper = serverErrorMapper::toCommonException,
    ) {
        api.getMyViolations().map { it.toDomain() }
    }

    private fun File.toAvatarPart(): MultipartBody.Part {
        return MultipartBody.Part.createFormData(
            name = AVATAR_PART_NAME,
            filename = name,
            body = asRequestBody(ProfileAvatarUpload.detectMediaType(this).toMediaType()),
        )
    }

    private companion object {
        const val AVATAR_PART_NAME = "avatar"
    }
}
