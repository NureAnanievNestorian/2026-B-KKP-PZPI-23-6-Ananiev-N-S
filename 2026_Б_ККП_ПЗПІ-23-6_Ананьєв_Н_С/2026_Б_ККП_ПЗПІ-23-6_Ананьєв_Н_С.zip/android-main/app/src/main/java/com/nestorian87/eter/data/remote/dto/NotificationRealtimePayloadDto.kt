package com.nestorian87.eter.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class NotificationRealtimePayloadDto(
    val notification: NotificationItemDto,
    val unreadCount: Int = 0,
    val unseenCount: Int = 0,
)
