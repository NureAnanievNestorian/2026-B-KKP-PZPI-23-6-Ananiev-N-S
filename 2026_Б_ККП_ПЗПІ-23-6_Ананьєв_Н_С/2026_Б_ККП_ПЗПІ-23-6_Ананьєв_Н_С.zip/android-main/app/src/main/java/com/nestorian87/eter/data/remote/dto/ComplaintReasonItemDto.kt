package com.nestorian87.eter.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class ComplaintReasonItemDto(
    val key: String,
    val label: String,
)
