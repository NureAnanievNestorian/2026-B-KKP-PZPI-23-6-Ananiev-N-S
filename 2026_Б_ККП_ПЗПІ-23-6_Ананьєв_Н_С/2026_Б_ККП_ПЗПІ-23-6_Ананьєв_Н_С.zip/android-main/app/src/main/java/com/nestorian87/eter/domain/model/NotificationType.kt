package com.nestorian87.eter.domain.model

enum class NotificationType {
    POST_LIKED,
    POST_COMMENTED,
    COMMENT_REPLIED,
    COMMENT_LIKED,
    USER_FOLLOWED,
    POST_VIOLATION_CONFIRMED,
    UNKNOWN,
}
