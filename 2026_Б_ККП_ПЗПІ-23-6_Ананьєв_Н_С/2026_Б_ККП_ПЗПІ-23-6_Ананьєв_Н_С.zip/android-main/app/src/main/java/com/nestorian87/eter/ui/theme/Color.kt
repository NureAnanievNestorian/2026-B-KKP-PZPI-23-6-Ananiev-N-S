package com.nestorian87.eter.ui.theme

import androidx.compose.ui.graphics.Color

val Terracotta = Color(0xFF8B4A2E)
val BurntClay = Color(0xFF6E3721)
val WarmBeige = Color(0xFFF0EBE1)
val Paper = Color(0xFFF7F3EC)
val Umber = Color(0xFF3A3028)
val Mushroom = Color(0xFFA8998C)
val Sandstone = Color(0xFFE5DACB)
val Sepia = Color(0xFF5A4337)
val CopperGlow = Color(0xFFB56A44)
val QuietRose = Color(0xFFF2E4DA)

val Espresso = Color(0xFF1F1713)
val Mocha = Color(0xFF2B211C)
val ClayLight = Color(0xFFD08C6A)
val Cream = Color(0xFFF5EEE6)
val Taupe = Color(0xFFC7B8AA)
val Linen = Color(0xFFD8CFC4)
val Ink = Color(0xFF15100E)
val Cocoa = Color(0xFF221915)
val AshRose = Color(0xFF8F7A6E)
