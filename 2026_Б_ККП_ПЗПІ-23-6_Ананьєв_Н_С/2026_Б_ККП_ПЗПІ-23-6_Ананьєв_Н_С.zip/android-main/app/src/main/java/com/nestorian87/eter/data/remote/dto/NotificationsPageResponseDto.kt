package com.nestorian87.eter.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class NotificationsPageResponseDto(
    val items: List<NotificationItemDto> = emptyList(),
    val limit: Int = 20,
    val nextCursor: String? = null,
    val hasMore: Boolean = false,
    val unreadCount: Int = 0,
    val unseenCount: Int = 0,
)
