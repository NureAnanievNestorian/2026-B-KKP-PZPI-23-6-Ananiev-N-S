package com.nestorian87.eter.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.navigation3.rememberViewModelStoreNavEntryDecorator
import androidx.navigation3.runtime.entryProvider
import androidx.navigation3.runtime.rememberSaveableStateHolderNavEntryDecorator
import androidx.navigation3.ui.NavDisplay
import com.nestorian87.eter.ui.screens.auth.emailConfirmation.EmailConfirmationScreen
import com.nestorian87.eter.ui.screens.auth.forgotPassword.ForgotPasswordScreen
import com.nestorian87.eter.ui.screens.auth.login.LoginScreen
import com.nestorian87.eter.ui.screens.auth.register.RegisterScreen
import com.nestorian87.eter.ui.screens.create.RecordAudioScreen
import com.nestorian87.eter.ui.screens.editpost.EditPostScreen
import com.nestorian87.eter.ui.screens.favorites.FavoritesScreen
import com.nestorian87.eter.ui.screens.feed.FeedScreen
import com.nestorian87.eter.ui.screens.notifications.NotificationsScreen
import com.nestorian87.eter.ui.screens.payment.PaymentReturnScreen
import com.nestorian87.eter.ui.screens.post.PostScreen
import com.nestorian87.eter.ui.screens.postsynchronization.PostSynchronizationScreen
import com.nestorian87.eter.ui.screens.profile.EditProfileScreen
import com.nestorian87.eter.ui.screens.profile.FollowersScreen
import com.nestorian87.eter.ui.screens.profile.PaymentWebViewScreen
import com.nestorian87.eter.ui.screens.profile.ProfileScreen
import com.nestorian87.eter.ui.screens.profile.SettingsScreen
import com.nestorian87.eter.ui.screens.profile.SubscriptionManagementScreen
import com.nestorian87.eter.ui.screens.search.SearchScreen
import com.nestorian87.eter.ui.screens.subscriptions.SubscriptionsScreen

private const val PAYMENT_RETURN_URL_PREFIX = "https://eter.pp.ua/payments/return"

@Composable
fun EterNavigation(
    navigationState: EterNavigationState,
    modifier: Modifier = Modifier,
) {
    NavDisplay(
        backStack = navigationState.currentBackStack,
        onBack = { navigationState.pop() },
        entryDecorators = listOf(
            rememberSaveableStateHolderNavEntryDecorator(),
            rememberViewModelStoreNavEntryDecorator(),
        ),
        entryProvider = entryProvider {
            entry<LoginKey> {
                LoginScreen(
                    modifier = modifier,
                    onLoginSuccess = navigationState::showMain,
                    onNavigateToRegister = { navigationState.navigate(RegisterKey) },
                    onNavigateToForgotPassword = { navigationState.navigate(ForgotPasswordKey) },
                )
            }
            entry<RegisterKey> {
                RegisterScreen(
                    modifier = modifier,
                    onRegisterSuccess = navigationState::showMain,
                    onNavigateToLogin = { navigationState.pop() },
                )
            }
            entry<EmailConfirmationKey> {
                EmailConfirmationScreen(modifier = modifier)
            }
            entry<ForgotPasswordKey> {
                ForgotPasswordScreen(
                    modifier = modifier,
                    onBack = navigationState::pop,
                )
            }
            entry<FeedKey> {
                FeedScreen(
                    modifier = modifier,
                    onOpenPost = { postId ->
                        navigationState.navigate(PostKey(postId = postId))
                    },
                    onOpenComments = { postId ->
                        navigationState.navigate(
                            PostKey(
                                postId = postId,
                                focusComments = true,
                            ),
                        )
                    },
                    onOpenAuthor = { userId ->
                        navigationState.navigate(UserProfileKey(userId = userId))
                    },
                    onCategoryClick = { categoryId ->
                        navigationState.openSearchWithCategory(categoryId)
                    },
                    onOpenSearch = {
                        navigationState.openSearch()
                    },
                    onOpenNotifications = {
                        navigationState.navigate(NotificationsKey)
                    },
                )
            }
            entry<SearchKey> {
                SearchScreen(
                    modifier = modifier,
                    onBack = navigationState::pop,
                    onOpenPost = { postId ->
                        navigationState.navigate(PostKey(postId = postId))
                    },
                    onOpenComments = { postId ->
                        navigationState.navigate(
                            PostKey(
                                postId = postId,
                                focusComments = true,
                            ),
                        )
                    },
                    onOpenAuthor = { userId ->
                        navigationState.navigate(UserProfileKey(userId = userId))
                    },
                    onCategoryClick = { categoryId ->
                        navigationState.openSearchWithCategory(categoryId)
                    },
                    pendingCategoryId = navigationState.pendingSearchCategoryId,
                    onPendingCategoryConsumed = navigationState::clearPendingSearchCategory,
                )
            }
            entry<SubscriptionsKey> {
                SubscriptionsScreen(
                    modifier = modifier,
                    onOpenPost = { postId ->
                        navigationState.navigate(PostKey(postId = postId))
                    },
                    onOpenComments = { postId ->
                        navigationState.navigate(
                            PostKey(
                                postId = postId,
                                focusComments = true,
                            ),
                        )
                    },
                    onOpenAuthor = { userId ->
                        navigationState.navigate(UserProfileKey(userId = userId))
                    },
                    onCategoryClick = { categoryId ->
                        navigationState.openSearchWithCategory(categoryId)
                    },
                )
            }
            entry<CreateKey> {
                RecordAudioScreen(
                    modifier = modifier,
                    onNavigateToEditPost = { postId ->
                        navigationState.navigate(EditPostKey(postId = postId))
                    },
                )
            }
            entry<FavoritesKey> {
                FavoritesScreen(
                    modifier = modifier,
                    onOpenPost = { postId ->
                        navigationState.navigate(PostKey(postId = postId))
                    },
                    onOpenComments = { postId ->
                        navigationState.navigate(
                            PostKey(
                                postId = postId,
                                focusComments = true,
                            ),
                        )
                    },
                    onOpenAuthor = { userId ->
                        navigationState.navigate(UserProfileKey(userId = userId))
                    },
                    onCategoryClick = { categoryId ->
                        navigationState.openSearchWithCategory(categoryId)
                    },
                )
            }
            entry<ProfileKey> {
                ProfileScreen(
                    modifier = modifier,
                    profileUserId = null,
                    profileUsername = null,
                    onOpenPost = { postId ->
                        navigationState.navigate(PostKey(postId = postId))
                    },
                    onOpenComments = { postId ->
                        navigationState.navigate(PostKey(postId = postId, focusComments = true))
                    },
                    onOpenDraft = { postId ->
                        navigationState.navigate(EditPostKey(postId = postId))
                    },
                    onOpenAuthor = { userId, username ->
                        navigationState.navigate(
                            if (!username.isNullOrBlank()) {
                                UserProfileKey(username = username)
                            } else {
                                UserProfileKey(userId = userId)
                            },
                        )
                    },
                    onBack = {
                        if (!navigationState.pop()) {
                            navigationState.selectTab(TopLevelDestination.FEED)
                        }
                    },
                    onOpenSettings = {
                        navigationState.navigate(SettingsKey)
                    },
                    onOpenFollowers = { userId ->
                        navigationState.navigate(
                            FollowersKey(
                                userId = userId,
                                initialTab = "followers",
                            ),
                        )
                    },
                    onOpenFollowing = { userId ->
                        navigationState.navigate(
                            FollowersKey(
                                userId = userId,
                                initialTab = "following",
                            ),
                        )
                    },
                    onLoginRequested = navigationState::showAuth,
                    onOpenOwnProfile = {
                        navigationState.selectTab(TopLevelDestination.PROFILE)
                    },
                )
            }
            entry<RecordAudioKey> {
                RecordAudioScreen(
                    modifier = modifier,
                    onNavigateToEditPost = { postId ->
                        navigationState.navigate(EditPostKey(postId = postId))
                    },
                )
            }
            entry<EditPostKey> { key ->
                EditPostScreen(
                    postId = key.postId,
                    modifier = modifier,
                    onBack = navigationState::pop,
                    onPostDeleted = {
                        navigationState.pop()
                        val previousKey = navigationState.currentBackStack.lastOrNull()
                        if (previousKey is PostKey && previousKey.postId == key.postId) {
                            navigationState.pop()
                        }
                    },
                )
            }
            entry<PostSynchronizationKey> { key ->
                PostSynchronizationScreen(
                    postId = key.postId,
                    modifier = modifier,
                    onBack = navigationState::pop,
                )
            }
            entry<PostKey> { key ->
                PostScreen(
                    postId = key.postId,
                    focusComments = key.focusComments,
                    modifier = modifier,
                    onBack = navigationState::pop,
                    onEditPost = { postId ->
                        navigationState.navigate(EditPostKey(postId = postId))
                    },
                    onManageSynchronization = { postId ->
                        navigationState.navigate(PostSynchronizationKey(postId = postId))
                    },
                    onPostDeleted = navigationState::pop,
                    onOpenAuthor = { userId, username ->
                        navigationState.navigate(
                            if (!username.isNullOrBlank()) {
                                UserProfileKey(username = username)
                            } else {
                                UserProfileKey(userId = userId)
                            },
                        )
                    },
                    onCategoryClick = { categoryId ->
                        navigationState.openSearchWithCategory(categoryId)
                    },
                )
            }
            entry<UserProfileKey> { key ->
                ProfileScreen(
                    modifier = modifier,
                    profileUserId = key.userId,
                    profileUsername = key.username,
                    onOpenPost = { postId ->
                        navigationState.navigate(PostKey(postId = postId))
                    },
                    onOpenComments = { postId ->
                        navigationState.navigate(PostKey(postId = postId, focusComments = true))
                    },
                    onOpenDraft = { postId ->
                        navigationState.navigate(EditPostKey(postId = postId))
                    },
                    onOpenAuthor = { userId, username ->
                        navigationState.navigate(
                            if (!username.isNullOrBlank()) {
                                UserProfileKey(username = username)
                            } else {
                                UserProfileKey(userId = userId)
                            },
                        )
                    },
                    onBack = navigationState::pop,
                    onOpenSettings = {
                        navigationState.navigate(SettingsKey)
                    },
                    onOpenFollowers = { userId ->
                        navigationState.navigate(
                            FollowersKey(
                                userId = userId,
                                initialTab = "followers",
                            ),
                        )
                    },
                    onOpenFollowing = { userId ->
                        navigationState.navigate(
                            FollowersKey(
                                userId = userId,
                                initialTab = "following",
                            ),
                        )
                    },
                    onLoginRequested = navigationState::showAuth,
                    onOpenOwnProfile = {
                        navigationState.selectTab(TopLevelDestination.PROFILE)
                    },
                )
            }
            entry<FollowersKey> { key ->
                FollowersScreen(
                    modifier = modifier,
                    profileUserId = key.userId,
                    initialTab = key.initialTab,
                    onBack = navigationState::pop,
                    onLoginRequested = navigationState::showAuth,
                    onOpenProfile = { userId ->
                        navigationState.navigate(UserProfileKey(userId = userId))
                    },
                )
            }
            entry<NotificationsKey> {
                NotificationsScreen(
                    modifier = modifier,
                    onBack = navigationState::pop,
                    onOpenPost = { postId, focusComments ->
                        navigationState.navigate(
                            PostKey(
                                postId = postId,
                                focusComments = focusComments,
                            ),
                        )
                    },
                    onOpenProfile = { username ->
                        navigationState.navigate(UserProfileKey(username = username))
                    },
                )
            }
            entry<EditProfileKey> {
                EditProfileScreen(
                    modifier = modifier,
                    onBack = navigationState::pop,
                    onLoginRequested = navigationState::showAuth,
                    onOpenOwnProfile = {
                        navigationState.selectTab(TopLevelDestination.PROFILE)
                    },
                )
            }
            entry<SettingsKey> {
                SettingsScreen(
                    modifier = modifier,
                    onBack = navigationState::pop,
                    onOpenEditProfile = {
                        navigationState.navigate(EditProfileKey)
                    },
                    onManageSubscription = {
                        navigationState.navigate(ManageSubscriptionKey)
                    },
                    onLoginRequested = navigationState::showAuth,
                    onOpenOwnProfile = {
                        navigationState.selectTab(TopLevelDestination.PROFILE)
                    },
                )
            }
            entry<ManageSubscriptionKey> {
                SubscriptionManagementScreen(
                    modifier = modifier,
                    onBack = navigationState::pop,
                    onOpenPaymentWebView = { url, invoiceId, paymentType ->
                        navigationState.navigate(
                            PaymentWebViewKey(
                                url = url,
                                callbackUrlPrefix = PAYMENT_RETURN_URL_PREFIX,
                                invoiceId = invoiceId,
                                paymentType = paymentType,
                            ),
                        )
                    },
                )
            }
            entry<PaymentWebViewKey> { key ->
                PaymentWebViewScreen(
                    url = key.url,
                    callbackUrlPrefix = key.callbackUrlPrefix,
                    onBack = navigationState::pop,
                    onCallbackUrlIntercepted = {
                        if (key.invoiceId.isNotEmpty()) {
                            val popped = navigationState.pop()
                            if (popped) {
                                navigationState.navigate(
                                    PaymentReturnKey(
                                        invoiceId = key.invoiceId,
                                        paymentType = key.paymentType,
                                    ),
                                )
                            }
                        } else {
                            navigationState.pop()
                        }
                    },
                    modifier = modifier,
                )
            }
            entry<PaymentReturnKey> { key ->
                PaymentReturnScreen(
                    invoiceId = key.invoiceId,
                    paymentType = key.paymentType,
                    onBack = navigationState::pop,
                    modifier = modifier,
                )
            }
        },
    )
}
