package com.nestorian87.eter.ui.screens.postsynchronization

import com.nestorian87.eter.domain.model.Post

data class PostSynchronizationUiState(
    val isLoading: Boolean = true,
    val post: Post? = null,
    val currentUserId: Long? = null,
    val isPremium: Boolean = false,
    val blockingReason: PostSynchronizationBlockingReason? = null,
    val loadError: Throwable? = null,
    val isSaving: Boolean = false,
    val saveError: Throwable? = null,
    val syncableLines: List<SyncableLineUiModel> = emptyList(),
    val localSynchronization: Map<Int, Int> = emptyMap(),
    val focusedLinePosition: Int? = null,
    val hasChanges: Boolean = false,
    val hasAttemptedSave: Boolean = false,
    val validationIssues: Map<Int, PostSynchronizationValidationIssue> = emptyMap(),
    val activePostId: Long? = null,
    val isPlaying: Boolean = false,
    val currentTimeSeconds: Float = 0f,
    val durationSeconds: Float = 0f,
) {
    val focusedLine: SyncableLineUiModel?
        get() = focusedLinePosition?.let(syncableLines::getOrNull)

    val syncedCount: Int
        get() = syncableLines.count { localSynchronization.containsKey(it.lineIndex) }

    val progressPercent: Int
        get() = if (syncableLines.isEmpty()) 0 else ((syncedCount * 100f) / syncableLines.size).toInt()

    val canSave: Boolean
        get() = !isLoading && post != null && blockingReason == null && !isSaving

    val canOpenEditor: Boolean
        get() = post != null && !isLoading && loadError == null && blockingReason == null

    val isCurrentPostActive: Boolean
        get() = activePostId != null && activePostId == post?.postId

    val durationSecondsOrPostFallback: Float
        get() = durationSeconds.takeIf { it > 0f } ?: (post?.audioDurationSeconds?.toFloat() ?: 0f)
}
