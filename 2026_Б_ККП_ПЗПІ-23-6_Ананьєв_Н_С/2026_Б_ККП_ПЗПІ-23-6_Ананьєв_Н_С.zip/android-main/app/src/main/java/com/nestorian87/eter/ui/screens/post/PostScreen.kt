package com.nestorian87.eter.ui.screens.post

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Sort
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PersonAddAlt1
import androidx.compose.material.icons.rounded.PersonRemove
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nestorian87.eter.R
import com.nestorian87.eter.domain.model.Post
import com.nestorian87.eter.domain.model.PostCommentsSort
import com.nestorian87.eter.domain.model.PostException
import com.nestorian87.eter.domain.model.PostTextSynchronization
import com.nestorian87.eter.domain.model.ServerValidationException
import com.nestorian87.eter.ui.components.audio.EterPlayButton
import com.nestorian87.eter.ui.components.buttons.BackIconButton
import com.nestorian87.eter.ui.components.buttons.PrimaryActionButton
import com.nestorian87.eter.ui.components.dialog.EterBottomSheet
import com.nestorian87.eter.ui.components.dialog.EterConfirmationDialog
import com.nestorian87.eter.ui.components.dialog.EterSheetTitle
import com.nestorian87.eter.ui.components.feedback.EterLoadingIndicator
import com.nestorian87.eter.ui.components.feedback.shimmer
import com.nestorian87.eter.ui.components.immersive.PostImmersiveMode
import com.nestorian87.eter.ui.components.layout.AuthorAvatar
import com.nestorian87.eter.ui.components.layout.CategoryChip
import com.nestorian87.eter.ui.components.layout.rememberLazyListScrollRevealProgress
import com.nestorian87.eter.ui.navigation.EterDeepLink
import com.nestorian87.eter.ui.theme.EterPreview
import com.nestorian87.eter.ui.theme.EterScreenPreviews
import com.nestorian87.eter.ui.theme.EterSpacing
import com.nestorian87.eter.ui.theme.PillShape
import com.nestorian87.eter.util.parseServerInstant
import com.nestorian87.eter.util.toCompactCountText
import com.nestorian87.eter.util.toDurationText
import com.nestorian87.eter.util.toRelativeAgeText
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.launch
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun PostScreen(
    modifier: Modifier = Modifier,
    postId: Long,
    focusComments: Boolean = false,
    onBack: () -> Unit = {},
    onEditPost: (Long) -> Unit = {},
    onManageSynchronization: (Long) -> Unit = {},
    onPostDeleted: () -> Unit = {},
    onOpenAuthor: ((Long?, String?) -> Unit)? = null,
    onCategoryClick: ((Long) -> Unit)? = null,
    viewModel: PostViewModel = hiltViewModel<PostViewModel, PostViewModel.Factory> { factory ->
        factory.create(postId)
    },
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(uiState.isPostDeleted) {
        if (uiState.isPostDeleted) {
            onPostDeleted()
        }
    }

    PostScreenContent(
        uiState = uiState,
        focusComments = focusComments,
        modifier = modifier,
        onBack = onBack,
        onEditPost = onEditPost,
        onManageSynchronization = onManageSynchronization,
        onDeletePost = viewModel::onDeletePost,
        onRetryLoadPost = viewModel::retryLoadPost,
        onTogglePostLike = viewModel::onTogglePostLike,
        onToggleAuthorFollow = viewModel::onToggleAuthorFollow,
        onPlayPost = viewModel::onPlayPost,
        onSeekToPercent = viewModel::onSeekToPercent,
        onSeekAndPlay = viewModel::onSeekAndPlay,
        onToggleCommentLike = viewModel::onToggleCommentLike,
        onDeleteComment = viewModel::onDeleteComment,
        onSortChanged = viewModel::onSortChanged,
        onLoadMoreComments = viewModel::loadMoreComments,
        onCommentComposerChanged = viewModel::onCommentComposerChanged,
        onSendComment = viewModel::onSendComment,
        onReplyComposerOpen = viewModel::onReplyComposerOpen,
        onReplyComposerDismiss = viewModel::onReplyComposerDismiss,
        onReplyDraftChanged = viewModel::onReplyDraftChanged,
        onSendReply = viewModel::onSendReply,
        onToggleReplies = viewModel::onToggleReplies,
        onLoadMoreReplies = viewModel::onLoadMoreReplies,
        onOpenAuthor = onOpenAuthor,
        onCategoryClick = onCategoryClick,
        onOpenReport = viewModel::onOpenReport,
        onSelectReportReason = viewModel::onSelectReportReason,
        onSubmitReport = viewModel::onSubmitReport,
        onDismissReport = viewModel::onDismissReport,
        onImmersiveModeVisibilityChanged = viewModel::onImmersiveModeVisibilityChanged,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PostScreenContent(
    uiState: PostUiState,
    focusComments: Boolean,
    modifier: Modifier = Modifier,
    onBack: () -> Unit,
    onEditPost: (Long) -> Unit,
    onManageSynchronization: (Long) -> Unit,
    onDeletePost: () -> Unit,
    onRetryLoadPost: () -> Unit,
    onTogglePostLike: () -> Unit,
    onToggleAuthorFollow: () -> Unit,
    onPlayPost: () -> Unit,
    onSeekToPercent: (Float) -> Unit,
    onSeekAndPlay: (Int) -> Unit,
    onToggleCommentLike: (Long, Long?) -> Unit,
    onDeleteComment: (Long, Long?) -> Unit,
    onSortChanged: (PostCommentsSort) -> Unit,
    onLoadMoreComments: () -> Unit,
    onCommentComposerChanged: (String) -> Unit,
    onSendComment: () -> Unit,
    onReplyComposerOpen: (Long) -> Unit,
    onReplyComposerDismiss: () -> Unit,
    onReplyDraftChanged: (Long, String) -> Unit,
    onSendReply: (Long) -> Unit,
    onToggleReplies: (Long) -> Unit,
    onLoadMoreReplies: (Long) -> Unit,
    onOpenAuthor: ((Long?, String?) -> Unit)? = null,
    onCategoryClick: ((Long) -> Unit)? = null,
    onOpenReport: () -> Unit = {},
    onSelectReportReason: (String) -> Unit = {},
    onSubmitReport: () -> Unit = {},
    onDismissReport: () -> Unit = {},
    onImmersiveModeVisibilityChanged: (Boolean) -> Unit = {},
) {
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val post = uiState.post
    val topBarProgress by rememberLazyListScrollRevealProgress(
        listState = listState,
        revealDistance = 164.dp,
    )
    val titleAlpha = ((topBarProgress - 0.42f) / 0.58f).coerceIn(0f, 1f)
    val signInRequiredMessage = stringResource(R.string.post_sign_in_required)
    var isDeleteDialogVisible by rememberSaveable { mutableStateOf(false) }
    var isActionsSheetVisible by rememberSaveable { mutableStateOf(false) }
    var isSortSheetVisible by rememberSaveable { mutableStateOf(false) }
    var isImmersiveModeVisible by rememberSaveable { mutableStateOf(false) }
    var pendingCommentDelete by rememberSaveable { mutableStateOf<PendingCommentDelete?>(null) }

    LaunchedEffect(isImmersiveModeVisible) {
        onImmersiveModeVisibilityChanged(isImmersiveModeVisible)
    }

    BackHandler(enabled = isImmersiveModeVisible) {
        isImmersiveModeVisible = false
    }

    val commentReplyTarget = remember(
        uiState.openReplyComposerCommentId,
        uiState.comments,
        uiState.repliesByCommentId,
    ) {
        uiState.openReplyComposerCommentId?.let { commentId ->
            findCommentById(
                commentId = commentId,
                comments = uiState.comments,
                repliesByCommentId = uiState.repliesByCommentId,
            )?.author?.name ?: findCommentById(
                commentId = commentId,
                comments = uiState.comments,
                repliesByCommentId = uiState.repliesByCommentId,
            )?.author?.username
        }
    }
    val composerText = uiState.openReplyComposerCommentId?.let { replyCommentId ->
        uiState.replyDraftByCommentId[replyCommentId].orEmpty()
    } ?: uiState.composerText
    val shouldFocusComposer = focusComments || uiState.openReplyComposerCommentId != null

    LaunchedEffect(
        listState,
        uiState.comments.size,
        uiState.isLoadingComments,
        uiState.isLoadingMoreComments,
        uiState.commentsNextCursor,
    ) {
        if (uiState.isLoadingComments) {
            return@LaunchedEffect
        }

        snapshotFlow { listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index }
            .filterNotNull()
            .distinctUntilChanged()
            .collect { lastVisibleIndex ->
                val triggerIndex = listState.layoutInfo.totalItemsCount - 3
                if (
                    uiState.commentsNextCursor != null &&
                    !uiState.isLoadingMoreComments &&
                    lastVisibleIndex >= triggerIndex
                ) {
                    onLoadMoreComments()
                }
            }
    }

    LaunchedEffect(focusComments, post?.postId) {
        if (focusComments && post != null) {
            listState.animateScrollToItem(COMMENTS_HEADER_INDEX)
        }
    }

    val scrollToComments: () -> Unit = {
        coroutineScope.launch {
            listState.animateScrollToItem(COMMENTS_HEADER_INDEX)
        }
    }

    Surface(
        modifier = modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
        ) {
            when {
                uiState.isLoadingPost -> {
                    Box(modifier = Modifier.fillMaxSize()) {
                        PostTopBar(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .fillMaxWidth(),
                            onBack = onBack,
                            onOpenActions = {},
                            actionsEnabled = false,
                            progress = 1f,
                        )
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center,
                        ) {
                            EterLoadingIndicator()
                        }
                    }
                }

                post == null -> {
                    PostLoadErrorState(
                        messageResId = uiState.postError.toPostMessageResId(),
                        onRetry = onRetryLoadPost,
                        onBack = onBack,
                    )
                }

                else -> {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(
                            start = EterSpacing.medium,
                            top = 0.dp,
                            end = EterSpacing.medium,
                            bottom = 92.dp,
                        ),
                        verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
                    ) {
                        item(key = "post_header") {
                            PostHeaderSection(
                                post = post,
                                isPostLiked = uiState.isPostLiked,
                                isPostLikePending = uiState.pendingPostLike,
                                isCurrentPostPlaying = uiState.isCurrentPostPlaying,
                                isCurrentPostActive = uiState.isCurrentPostActive,
                                onTogglePostLike = onTogglePostLike,
                                onPlayPost = onPlayPost,
                                onOpenComments = scrollToComments,
                                onOpenAuthor = onOpenAuthor?.let { callback ->
                                    {
                                        callback(
                                            post.author?.userId ?: post.authorId,
                                            post.author?.username
                                        )
                                    }
                                },
                                onCategoryClick = onCategoryClick,
                            )
                        }

                        if (!post.description.isNullOrBlank()) {
                            item(key = "post_description") {
                                PostDescriptionSection(text = post.description)
                            }
                        }

                        if (!post.text.isNullOrBlank()) {
                            item(key = "post_text") {
                                PostTextSection(
                                    text = post.text,
                                    synchronization = post.textSynchronization,
                                    activePlaybackTimeMs = uiState.currentPlaybackTimeMs,
                                    isPlaybackActive = uiState.isCurrentPostActive,
                                    onLineClick = onSeekAndPlay,
                                    onOpenImmersiveMode = { isImmersiveModeVisible = true },
                                )
                            }
                        }

                        item(key = "comments_divider") {
                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = EterSpacing.small),
                                thickness = 1.dp,
                                color = MaterialTheme.colorScheme.outlineVariant,
                            )
                        }

                        item(key = "comments_header") {
                            CommentsSectionHeader(
                                count = post.commentsCount,
                                commentsSort = uiState.commentsSort,
                                onOpenSort = { isSortSheetVisible = true },
                            )
                        }

                        if (uiState.commentsError != null) {
                            item(key = "comments_error") {
                                Text(
                                    text = stringResource(uiState.commentsError.toCommentsMessageResId()),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.error,
                                )
                            }
                        }

                        when {
                            uiState.isLoadingComments && uiState.comments.isEmpty() -> {
                                items(count = 3, key = { "comment_skeleton_$it" }) {
                                    CommentSkeletonItem()
                                }
                            }

                            uiState.comments.isEmpty() -> {
                                item(key = "comments_empty") {
                                    Text(
                                        text = stringResource(R.string.post_comments_empty),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }

                            else -> {
                                items(
                                    items = uiState.comments,
                                    key = { item -> item.comment.commentId },
                                ) { item ->
                                    CommentItem(
                                        item = item,
                                        currentUserId = uiState.currentUserId,
                                        parentCommentId = null,
                                        pendingLikeCommentIds = uiState.pendingCommentLikeIds,
                                        pendingDeleteCommentIds = uiState.pendingDeleteCommentIds,
                                        replies = uiState.repliesByCommentId[item.comment.commentId].orEmpty(),
                                        areRepliesExpanded = uiState.expandedRepliesCommentIds.contains(
                                            item.comment.commentId
                                        ),
                                        isLoadingReplies = uiState.loadingRepliesCommentIds.contains(
                                            item.comment.commentId
                                        ),
                                        isLoadingMoreReplies = uiState.loadingMoreRepliesCommentIds.contains(
                                            item.comment.commentId
                                        ),
                                        hasMoreReplies = uiState.repliesNextCursorByCommentId[item.comment.commentId] != null,
                                        onToggleLike = {
                                            onToggleCommentLike(
                                                item.comment.commentId,
                                                null
                                            )
                                        },
                                        onDelete = {
                                            pendingCommentDelete = PendingCommentDelete(
                                                commentId = item.comment.commentId,
                                                parentCommentId = null,
                                            )
                                        },
                                        onReplyClick = { onReplyComposerOpen(item.comment.commentId) },
                                        onToggleReplies = { onToggleReplies(item.comment.commentId) },
                                        onLoadMoreReplies = { onLoadMoreReplies(item.comment.commentId) },
                                        onToggleReplyLike = onToggleCommentLike,
                                        onDeleteReply = { commentId, parentCommentId ->
                                            pendingCommentDelete = PendingCommentDelete(
                                                commentId = commentId,
                                                parentCommentId = parentCommentId,
                                            )
                                        },
                                        onOpenAuthor = onOpenAuthor,
                                    )
                                }
                            }
                        }

                        if (uiState.isLoadingMoreComments) {
                            item(key = "loading_more_comments") {
                                LoadingRow()
                            }
                        }

                        item(key = "bottom_spacer") {
                            Spacer(modifier = Modifier.navigationBarsPadding())
                        }
                    }
                }
            }

            PostTopBar(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth(),
                onBack = onBack,
                onOpenActions = { isActionsSheetVisible = true },
                actionsEnabled = post != null,
                title = post?.title?.ifBlank { stringResource(R.string.post_untitled) },
                progress = if (post == null) 1f else topBarProgress,
                titleAlpha = titleAlpha,
            )

            if (post != null) {
                PostBottomComposer(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth(),
                    value = composerText,
                    replyTargetName = commentReplyTarget,
                    requestComposerFocus = shouldFocusComposer,
                    isSubmitting = uiState.isSubmittingComment,
                    onValueChange = { value ->
                        uiState.openReplyComposerCommentId?.let { commentId ->
                            onReplyDraftChanged(commentId, value)
                        } ?: onCommentComposerChanged(value)
                    },
                    onDismissReply = onReplyComposerDismiss,
                    onSend = {
                        uiState.openReplyComposerCommentId?.let(onSendReply) ?: onSendComment()
                    },
                )
            }

            SnackbarHost(
                hostState = snackbarHostState,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 88.dp, start = EterSpacing.medium, end = EterSpacing.medium),
            )
        }
    }

    if (post != null && isActionsSheetVisible) {
        PostActionsSheet(
            isOwner = uiState.currentUserId == post.authorId,
            isAuthenticated = uiState.isAuthenticated,
            isFollowingAuthor = uiState.isFollowingAuthor,
            isAuthorFollowActionLoading = uiState.isAuthorFollowActionLoading,
            onDismiss = { isActionsSheetVisible = false },
            onToggleFollow = {
                isActionsSheetVisible = false
                if (!uiState.isAuthenticated) {
                    coroutineScope.launch {
                        snackbarHostState.showSnackbar(signInRequiredMessage)
                    }
                } else {
                    onToggleAuthorFollow()
                }
            },
            onReport = {
                isActionsSheetVisible = false
                onOpenReport()
            },
            onShareLink = {
                isActionsSheetVisible = false
                val shareIntent = Intent(Intent.ACTION_SEND)
                    .setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, post.toCanonicalUrl())
                context.startActivity(
                    Intent.createChooser(
                        shareIntent,
                        context.getString(R.string.post_share),
                    ),
                )
            },
            onEditPost = {
                isActionsSheetVisible = false
                onEditPost(post.postId)
            },
            onManageSynchronization = {
                isActionsSheetVisible = false
                onManageSynchronization(post.postId)
            },
            onDeletePost = {
                isActionsSheetVisible = false
                isDeleteDialogVisible = true
            },
        )
    }

    PostImmersiveMode(
        visible = isImmersiveModeVisible,
        post = post,
        isPlaying = uiState.isCurrentPostPlaying,
        onTogglePlayback = onPlayPost,
        onSeek = onSeekToPercent,
        onClose = { isImmersiveModeVisible = false },
        currentTimeMs = uiState.currentPlaybackTimeMs.takeIf { uiState.isCurrentPostActive },
    )

    if (isSortSheetVisible) {
        PostCommentsSortSheet(
            selectedSort = uiState.commentsSort,
            onDismiss = { isSortSheetVisible = false },
            onSortSelected = { sort ->
                isSortSheetVisible = false
                onSortChanged(sort)
            },
        )
    }

    if (isDeleteDialogVisible) {
        EterConfirmationDialog(
            title = stringResource(R.string.post_delete_title),
            message = stringResource(R.string.post_delete_message),
            confirmText = stringResource(R.string.post_delete_confirm),
            confirmIcon = Icons.Rounded.DeleteOutline,
            isConfirmLoading = uiState.isDeletingPost,
            errorMessage = uiState.postActionError?.let { stringResource(it.toPostMessageResId()) },
            onConfirm = onDeletePost,
            onDismiss = { isDeleteDialogVisible = false },
        )
    }

    pendingCommentDelete?.let { pendingDelete ->
        EterConfirmationDialog(
            title = stringResource(R.string.post_comment_delete_title),
            message = stringResource(R.string.post_comment_delete_message),
            confirmText = stringResource(R.string.post_comment_delete_confirm),
            confirmIcon = Icons.Rounded.DeleteOutline,
            isConfirmLoading = uiState.pendingDeleteCommentIds.contains(pendingDelete.commentId),
            errorMessage = uiState.commentsError?.let { stringResource(it.toCommentsMessageResId()) },
            onConfirm = {
                onDeleteComment(pendingDelete.commentId, pendingDelete.parentCommentId)
                pendingCommentDelete = null
            },
            onDismiss = { pendingCommentDelete = null },
        )
    }

    if (uiState.report.isVisible) {
        PostReportSheet(
            reportState = uiState.report,
            onDismiss = onDismissReport,
            onSelectReason = onSelectReportReason,
            onSubmit = onSubmitReport,
        )
    }
}

@Composable
private fun PostTopBar(
    modifier: Modifier = Modifier,
    onBack: () -> Unit,
    onOpenActions: () -> Unit,
    actionsEnabled: Boolean,
    title: String? = null,
    progress: Float,
    titleAlpha: Float = progress,
) {
    Box(modifier = modifier) {
        Box(
            modifier = Modifier
                .matchParentSize()
                .graphicsLayer { alpha = progress }
                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)),
        )
        HorizontalDivider(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .graphicsLayer { alpha = progress },
            thickness = 0.5.dp,
            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.14f),
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = EterSpacing.small),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BackIconButton(
                onClick = onBack,
                tint = MaterialTheme.colorScheme.onBackground,
            )
            Text(
                text = title.orEmpty(),
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = EterSpacing.small)
                    .graphicsLayer {
                        alpha = titleAlpha
                        translationY = (1f - titleAlpha) * 14f
                    },
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface,
            )
            IconButton(
                onClick = onOpenActions,
                enabled = actionsEnabled,
            ) {
                Icon(
                    imageVector = Icons.Rounded.MoreVert,
                    contentDescription = stringResource(R.string.post_more_actions),
                    tint = MaterialTheme.colorScheme.onBackground,
                )
            }
        }
    }
}

@Composable
private fun PostHeaderSection(
    post: Post,
    isPostLiked: Boolean,
    isPostLikePending: Boolean,
    isCurrentPostPlaying: Boolean,
    isCurrentPostActive: Boolean,
    onTogglePostLike: () -> Unit,
    onPlayPost: () -> Unit,
    onOpenComments: () -> Unit,
    onOpenAuthor: (() -> Unit)? = null,
    onCategoryClick: ((Long) -> Unit)? = null,
) {
    val displayAuthorName = post.author?.name ?: stringResource(R.string.post_unknown_author)

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
    ) {
        Box(
            modifier = Modifier
                .statusBarsPadding()
                .fillMaxWidth()
        ) {
            Spacer(modifier = Modifier.height(48.dp))
        }

        Row(
            modifier = if (onOpenAuthor != null) {
                Modifier
                    .clip(MaterialTheme.shapes.small)
                    .clickable(onClick = onOpenAuthor)
            } else {
                Modifier
            },
            horizontalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AuthorAvatar(
                name = displayAuthorName,
                photoUrl = post.author?.photo,
                size = 32.dp,
            )
            Text(
                text = buildAnnotatedString {
                    val username = post.author?.username?.takeIf { it.isNotBlank() }
                    if (username != null) {
                        pushStyle(SpanStyle(fontWeight = FontWeight.Medium))
                        append("@$username")
                        pop()
                    } else {
                        pushStyle(SpanStyle(fontWeight = FontWeight.Medium))
                        append(displayAuthorName)
                        pop()
                    }
                    append(" · ")
                    append(post.createdAt.toRelativeAgeText())
                    append(" · ")
                    append(post.audioDurationSeconds.toDurationText())
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }

        Text(
            text = post.title.orEmpty().ifBlank { stringResource(R.string.post_untitled) },
            style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface,
        )

        post.originAuthorName?.takeIf { it.isNotBlank() }?.let { originAuthor ->
            Text(
                text = originAuthor,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Medium),
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.84f),
            )
        }

        if (post.categories.isNotEmpty()) {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
            ) {
                post.categories.forEach { category ->
                    CategoryChip(
                        name = category.categoryName,
                        onClick = onCategoryClick?.let { { it(category.categoryId) } },
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                EngagementStat(
                    icon = if (isPostLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    text = post.likesCount.toCompactCountText(),
                    contentDescription = stringResource(R.string.feed_like_post),
                    tint = if (isPostLiked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    textColor = if (isPostLiked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    enabled = !isPostLikePending,
                    onClick = onTogglePostLike,
                )
                EngagementStat(
                    icon = Icons.Rounded.ChatBubbleOutline,
                    text = post.commentsCount.toCompactCountText(),
                    contentDescription = stringResource(R.string.feed_open_comments),
                    onClick = onOpenComments,
                )
                EngagementStat(
                    icon = Icons.Rounded.PlayArrow,
                    text = post.listens.toCompactCountText(),
                    contentDescription = null,
                    iconSize = 16.dp,
                )
            }

            EterPlayButton(
                isPlaying = isCurrentPostPlaying,
                isActive = isCurrentPostActive,
                size = 48.dp,
                onClick = onPlayPost,
            )
        }

    }
}

@Composable
private fun PostDescriptionSection(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyLarge.copy(fontStyle = FontStyle.Italic),
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun PostTextSection(
    text: String,
    synchronization: List<PostTextSynchronization>,
    activePlaybackTimeMs: Long,
    isPlaybackActive: Boolean,
    onLineClick: (Int) -> Unit,
    onOpenImmersiveMode: () -> Unit,
) {
    val lines = remember(text) { text.lines() }
    val normalizedSynchronization = remember(lines, synchronization) {
        normalizePostTextSynchronization(lines.size, synchronization)
    }
    val synchronizationByLine = remember(normalizedSynchronization) {
        normalizedSynchronization.associateBy { it.lineIndex }
    }
    val activeLineIndex =
        remember(isPlaybackActive, activePlaybackTimeMs, normalizedSynchronization) {
        if (!isPlaybackActive) {
            null
        } else {
            normalizedSynchronization
                .filter { it.audioStartMomentMs.toLong() <= activePlaybackTimeMs }
                .maxByOrNull { it.audioStartMomentMs }
                ?.lineIndex
        }
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
    ) {
        if (normalizedSynchronization.isNotEmpty()) {
            ActionPill(
                text = stringResource(R.string.post_immersive_mode),
                onClick = onOpenImmersiveMode,
            )
        }

        Column(
            verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
        ) {
            HorizontalDivider(
                thickness = 0.5.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.18f),
            )
            lines.forEachIndexed { index, line ->
                val sync = synchronizationByLine[index]
                val isHighlighted = index == activeLineIndex
                Text(
                    text = line.ifBlank { " " },
                    modifier = if (sync != null) {
                        Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onLineClick(sync.audioStartMomentMs) }
                            .background(
                                if (isHighlighted) {
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)
                                } else {
                                    Color.Transparent
                                },
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    } else {
                        Modifier
                    },
                    style = MaterialTheme.typography.bodyLarge.copy(
                        lineHeight = MaterialTheme.typography.bodyLarge.lineHeight * 1.08,
                    ),
                    color = if (isHighlighted) {
                        MaterialTheme.colorScheme.onSurface
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                )
            }
        }
    }
}

private fun normalizePostTextSynchronization(
    textLineCount: Int,
    synchronization: List<PostTextSynchronization>,
): List<PostTextSynchronization> {
    if (synchronization.isEmpty() || textLineCount <= 0) return synchronization
    val hasZeroIndex = synchronization.any { it.lineIndex == 0 }
    val minIndex = synchronization.minOf { it.lineIndex }
    val maxIndex = synchronization.maxOf { it.lineIndex }
    val shouldShiftToZeroBased = !hasZeroIndex && minIndex >= 1 && maxIndex <= textLineCount
    return if (!shouldShiftToZeroBased) {
        synchronization
    } else {
        synchronization.map { item -> item.copy(lineIndex = item.lineIndex - 1) }
    }
}

@Composable
private fun CommentsSectionHeader(
    count: Int,
    commentsSort: PostCommentsSort,
    onOpenSort: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
            verticalAlignment = Alignment.Bottom,
        ) {
            Text(
                text = stringResource(R.string.post_comments_title),
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface,
            )
            Text(
                text = count.toCompactCountText(),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        Row(
            modifier = Modifier
                .clip(PillShape)
                .clickable(onClick = onOpenSort)
                .padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Outlined.Sort,
                contentDescription = stringResource(R.string.post_comments_sort_title),
                modifier = Modifier.size(18.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text = when (commentsSort) {
                    PostCommentsSort.NEWEST -> stringResource(R.string.post_comments_sort_newest)
                    PostCommentsSort.OLDEST -> stringResource(R.string.feed_sort_oldest)
                    PostCommentsSort.POPULAR -> stringResource(R.string.post_comments_sort_popular)
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PostActionsSheet(
    isOwner: Boolean,
    isAuthenticated: Boolean,
    isFollowingAuthor: Boolean,
    isAuthorFollowActionLoading: Boolean,
    onDismiss: () -> Unit,
    onToggleFollow: () -> Unit,
    onReport: () -> Unit,
    onShareLink: () -> Unit,
    onEditPost: () -> Unit,
    onManageSynchronization: () -> Unit,
    onDeletePost: () -> Unit,
) {
    EterBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = EterSpacing.medium, vertical = EterSpacing.small),
            verticalArrangement = Arrangement.spacedBy(0.dp),
        ) {
            if (isOwner) {
                SheetActionItem(
                    icon = Icons.Rounded.Edit,
                    title = stringResource(R.string.post_edit),
                    onClick = onEditPost,
                )
                SheetActionListDivider()
                SheetActionItem(
                    icon = Icons.Rounded.Schedule,
                    title = stringResource(R.string.post_manage_synchronization),
                    onClick = onManageSynchronization,
                )
                SheetActionListDivider()
                SheetActionItem(
                    icon = Icons.Rounded.DeleteOutline,
                    title = stringResource(R.string.post_delete),
                    onClick = onDeletePost,
                )
                SheetActionListDivider()
            }
            if (!isOwner) {
                SheetActionItem(
                    icon = if (isFollowingAuthor) Icons.Rounded.PersonRemove else Icons.Rounded.PersonAddAlt1,
                    title = when {
                        !isAuthenticated -> stringResource(R.string.post_follow_author)
                        isAuthorFollowActionLoading -> stringResource(R.string.profile_following_cta)
                        isFollowingAuthor -> stringResource(R.string.post_unfollow_author)
                        else -> stringResource(R.string.post_follow_author)
                    },
                    onClick = onToggleFollow,
                )
                SheetActionListDivider()
            }
            if (!isOwner && isAuthenticated) {
                SheetActionItem(
                    icon = Icons.Rounded.Flag,
                    title = stringResource(R.string.post_report),
                    onClick = onReport,
                )
                SheetActionListDivider()
            }
            SheetActionItem(
                icon = Icons.Rounded.Share,
                title = stringResource(R.string.post_share),
                onClick = onShareLink,
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PostCommentsSortSheet(
    selectedSort: PostCommentsSort,
    onDismiss: () -> Unit,
    onSortSelected: (PostCommentsSort) -> Unit,
) {
    EterBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = EterSpacing.medium, vertical = EterSpacing.small),
            verticalArrangement = Arrangement.spacedBy(0.dp),
        ) {
            EterSheetTitle(
                text = stringResource(R.string.post_comments_sort_sheet_title),
                modifier = Modifier.padding(
                    horizontal = EterSpacing.medium,
                    vertical = EterSpacing.small
                ),
            )
            SortSheetItem(
                icon = Icons.Rounded.Schedule,
                title = stringResource(R.string.post_comments_sort_newest),
                selected = selectedSort == PostCommentsSort.NEWEST,
                onClick = { onSortSelected(PostCommentsSort.NEWEST) },
            )
            SheetActionListDivider()
            SortSheetItem(
                icon = Icons.Rounded.History,
                title = stringResource(R.string.feed_sort_oldest),
                selected = selectedSort == PostCommentsSort.OLDEST,
                onClick = { onSortSelected(PostCommentsSort.OLDEST) },
            )
            SheetActionListDivider()
            SortSheetItem(
                icon = Icons.Rounded.Favorite,
                title = stringResource(R.string.post_comments_sort_popular),
                selected = selectedSort == PostCommentsSort.POPULAR,
                onClick = { onSortSelected(PostCommentsSort.POPULAR) },
            )
        }
    }
}

@Composable
private fun SheetActionItem(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = EterSpacing.medium, vertical = EterSpacing.medium),
        horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            text = title,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface,
        )
    }
}

@Composable
private fun SortSheetItem(
    icon: ImageVector,
    title: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = if (selected) {
            MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
        } else {
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
        },
        shape = MaterialTheme.shapes.large,
        onClick = onClick,
    ) {
        Row(
            modifier = Modifier.padding(
                horizontal = EterSpacing.medium,
                vertical = EterSpacing.medium
            ),
            horizontalArrangement = Arrangement.spacedBy(EterSpacing.small),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                ),
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}

@Composable
private fun SheetActionListDivider() {
    HorizontalDivider(
        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.10f),
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PostReportSheet(
    reportState: PostReportUiState,
    onDismiss: () -> Unit,
    onSelectReason: (String) -> Unit,
    onSubmit: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    EterBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = EterSpacing.medium)
                .padding(bottom = EterSpacing.large)
                .navigationBarsPadding(),
        ) {
            EterSheetTitle(
                text = stringResource(R.string.report_title),
                modifier = Modifier.padding(vertical = EterSpacing.small),
            )

            Spacer(modifier = Modifier.height(EterSpacing.small))

            when {
                reportState.isSuccess -> {
                    Text(
                        text = stringResource(R.string.report_success),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = EterSpacing.small),
                    )
                    Spacer(modifier = Modifier.height(EterSpacing.medium))
                    PrimaryActionButton(
                        text = stringResource(R.string.report_close),
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }

                reportState.isLoadingReasons -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = EterSpacing.large),
                        contentAlignment = Alignment.Center,
                    ) {
                        EterLoadingIndicator()
                    }
                }

                reportState.reasonsError -> {
                    Text(
                        text = stringResource(R.string.report_reasons_error),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(MaterialTheme.shapes.medium)
                            .clickable(onClick = onDismiss)
                            .padding(vertical = EterSpacing.small),
                    )
                }

                else -> {
                    reportState.reasons.forEach { reason ->
                        val isSelected = reportState.selectedReasonKey == reason.key
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = if (isSelected) {
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                            } else {
                                Color.Transparent
                            },
                            shape = MaterialTheme.shapes.large,
                            onClick = { onSelectReason(reason.key) },
                        ) {
                            Row(
                                modifier = Modifier.padding(
                                    horizontal = EterSpacing.medium,
                                    vertical = EterSpacing.small,
                                ),
                                horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { onSelectReason(reason.key) },
                                    modifier = Modifier.size(20.dp),
                                )
                                Text(
                                    text = reason.label,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                            }
                        }
                        SheetActionListDivider()
                    }

                    Spacer(modifier = Modifier.height(EterSpacing.medium))

                    reportState.submitError?.let { error ->
                        Text(
                            text = when (error) {
                                ComplaintSubmitError.ALREADY_REPORTED -> stringResource(R.string.report_error_already_reported)
                                ComplaintSubmitError.GENERIC -> stringResource(R.string.report_error_generic)
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(bottom = EterSpacing.small),
                        )
                    }

                    PrimaryActionButton(
                        text = if (reportState.isSubmitting) {
                            stringResource(R.string.report_submitting)
                        } else {
                            stringResource(R.string.report_submit)
                        },
                        onClick = onSubmit,
                        enabled = reportState.selectedReasonKey != null && !reportState.isSubmitting,
                        isLoading = reportState.isSubmitting,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
    }
}

@Composable
private fun CommentItem(
    item: PostCommentUiModel,
    currentUserId: Long?,
    parentCommentId: Long?,
    pendingLikeCommentIds: Set<Long>,
    pendingDeleteCommentIds: Set<Long>,
    replies: List<PostCommentUiModel>,
    areRepliesExpanded: Boolean,
    isLoadingReplies: Boolean,
    isLoadingMoreReplies: Boolean,
    hasMoreReplies: Boolean,
    onToggleLike: () -> Unit,
    onDelete: () -> Unit,
    onReplyClick: () -> Unit,
    onToggleReplies: () -> Unit,
    onLoadMoreReplies: () -> Unit,
    onToggleReplyLike: (Long, Long?) -> Unit,
    onDeleteReply: (Long, Long?) -> Unit,
    onOpenAuthor: ((Long?, String?) -> Unit)? = null,
) {
    val isReply = parentCommentId != null
    val canReply = !isReply
    val isLikePending = pendingLikeCommentIds.contains(item.comment.commentId)
    val isDeletePending = pendingDeleteCommentIds.contains(item.comment.commentId)
    val resolvedAuthorId = item.comment.author?.userId ?: item.comment.authorId
    val resolvedAuthorUsername = item.comment.author?.username
    val isOwnedByCurrentUser = currentUserId != null && resolvedAuthorId == currentUserId

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = if (isReply) EterSpacing.medium else 0.dp),
        verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
            ) {
                AuthorAvatar(
                    name = item.comment.author?.name
                        ?: item.comment.author?.username
                        ?: stringResource(R.string.post_unknown_author),
                    photoUrl = item.comment.author?.photo,
                    size = if (isReply) 24.dp else 28.dp,
                    modifier = if (resolvedAuthorId != null || !resolvedAuthorUsername.isNullOrBlank()) {
                        Modifier.clickable {
                            onOpenAuthor?.invoke(
                                resolvedAuthorId,
                                resolvedAuthorUsername
                            )
                        }
                    } else {
                        Modifier
                    },
                )
                val authorLabel = item.comment.author?.username?.let { "@$it" }
                    ?: item.comment.author?.name
                    ?: stringResource(R.string.post_unknown_author)
                Text(
                    modifier = if (resolvedAuthorId != null || !resolvedAuthorUsername.isNullOrBlank()) {
                        Modifier
                            .weight(1f)
                            .clip(MaterialTheme.shapes.small)
                            .clickable {
                                onOpenAuthor?.invoke(
                                    resolvedAuthorId,
                                    resolvedAuthorUsername
                                )
                            }
                            .padding(vertical = 2.dp)
                    } else {
                        Modifier.weight(1f)
                    },
                    text = buildAnnotatedString {
                        pushStyle(SpanStyle(fontWeight = FontWeight.Medium))
                        append(authorLabel)
                        pop()
                        item.comment.createdAt?.takeIf { it.isNotBlank() }?.let {
                            append(" · ")
                            append(it.toCommentDateTimeText())
                        }
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (isOwnedByCurrentUser) {
                    Text(
                        text = stringResource(R.string.post_comment_delete),
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = if (isDeletePending) {
                            MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.52f)
                        } else {
                            MaterialTheme.colorScheme.primary
                        },
                        modifier = Modifier
                            .clip(MaterialTheme.shapes.small)
                            .clickable(
                                enabled = !isDeletePending,
                                onClick = onDelete,
                            )
                            .padding(horizontal = 4.dp, vertical = 2.dp),
                    )
                }
            }
            if (item.comment.isLikedByAuthor) {
                AuthorLikedBadge()
            }

            Text(
                text = item.comment.text.orEmpty(),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                EngagementStat(
                    icon = if (item.isLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    text = item.comment.likesCount.toCompactCountText(),
                    contentDescription = stringResource(R.string.post_comment_like),
                    tint = if (item.isLiked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    enabled = !isLikePending,
                    onClick = onToggleLike,
                    textStyle = MaterialTheme.typography.bodyMedium,
                )
                if (canReply) {
                    Text(
                        text = stringResource(R.string.post_comment_reply),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .clip(MaterialTheme.shapes.small)
                            .clickable(onClick = onReplyClick)
                            .padding(horizontal = 4.dp, vertical = 2.dp),
                    )
                }
            }
        }

        if (!isReply && (item.comment.repliesCount > 0 || replies.isNotEmpty())) {
            ReplyToggle(
                expanded = areRepliesExpanded,
                count = item.comment.repliesCount.coerceAtLeast(replies.size),
                onClick = onToggleReplies,
            )
        }

        if (areRepliesExpanded) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = EterSpacing.medium),
                verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
            ) {
                if (isLoadingReplies) {
                    LoadingRow()
                }
                replies.forEach { reply ->
                    CommentItem(
                        item = reply,
                        currentUserId = currentUserId,
                        parentCommentId = item.comment.commentId,
                        pendingLikeCommentIds = pendingLikeCommentIds,
                        pendingDeleteCommentIds = pendingDeleteCommentIds,
                        replies = emptyList(),
                        areRepliesExpanded = false,
                        isLoadingReplies = false,
                        isLoadingMoreReplies = false,
                        hasMoreReplies = false,
                        onToggleLike = {
                            onToggleReplyLike(reply.comment.commentId, item.comment.commentId)
                        },
                        onDelete = {
                            onDeleteReply(reply.comment.commentId, item.comment.commentId)
                        },
                        onReplyClick = {},
                        onToggleReplies = {},
                        onLoadMoreReplies = {},
                        onToggleReplyLike = onToggleReplyLike,
                        onDeleteReply = onDeleteReply,
                        onOpenAuthor = onOpenAuthor,
                    )
                }
                if (isLoadingMoreReplies) {
                    LoadingRow()
                } else if (hasMoreReplies) {
                    TextButton(onClick = onLoadMoreReplies) {
                        Text(text = stringResource(R.string.post_comments_load_more_replies))
                    }
                }
            }
        }
    }
}

@Composable
private fun AuthorLikedBadge() {
    Surface(
        shape = PillShape,
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f),
        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Icon(
                imageVector = Icons.Rounded.Favorite,
                contentDescription = stringResource(R.string.post_comment_liked_by_author),
                modifier = Modifier.size(12.dp),
                tint = MaterialTheme.colorScheme.primary,
            )
            Text(
                text = stringResource(R.string.post_comment_liked_by_author),
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

@Composable
private fun ReplyToggle(
    expanded: Boolean,
    count: Int,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .clip(PillShape)
            .clickable(onClick = onClick)
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Icon(
            imageVector = if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
            tint = MaterialTheme.colorScheme.primary,
        )
        Text(
            text = if (expanded) {
                stringResource(R.string.post_comment_hide_replies)
            } else {
                stringResource(R.string.post_comment_show_replies, count)
            },
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.primary,
        )
    }
}

@Composable
private fun PostBottomComposer(
    value: String,
    replyTargetName: String?,
    requestComposerFocus: Boolean,
    isSubmitting: Boolean,
    onValueChange: (String) -> Unit,
    onDismissReply: () -> Unit,
    onSend: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        color = MaterialTheme.colorScheme.background.copy(alpha = 0.98f),
        shadowElevation = 8.dp,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(bottom = EterSpacing.xSmall),
        ) {
            HorizontalDivider(
                thickness = 0.5.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.16f),
            )
            if (replyTargetName != null) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = EterSpacing.medium, vertical = EterSpacing.small),
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f),
                    border = BorderStroke(
                        0.5.dp,
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.28f)
                    ),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = EterSpacing.small, vertical = EterSpacing.xSmall),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = "@$replyTargetName",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = onDismissReply) {
                            Text(
                                text = stringResource(R.string.post_comment_cancel_reply),
                                style = MaterialTheme.typography.labelMedium,
                            )
                        }
                    }
                }
            }
            CompactCommentComposer(
                value = value,
                requestComposerFocus = requestComposerFocus,
                isSubmitting = isSubmitting,
                onValueChange = onValueChange,
                onSend = onSend,
            )
        }
    }
}

@Composable
private fun CompactCommentComposer(
    value: String,
    requestComposerFocus: Boolean,
    isSubmitting: Boolean,
    onValueChange: (String) -> Unit,
    onSend: () -> Unit,
) {
    val focusRequester = remember { FocusRequester() }
    val bringIntoViewRequester = remember { BringIntoViewRequester() }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(requestComposerFocus) {
        if (requestComposerFocus) {
            focusRequester.requestFocus()
            coroutineScope.launch {
                delay(220L)
                bringIntoViewRequester.bringIntoView()
            }
        }
    }

    OutlinedTextField(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = EterSpacing.medium, vertical = EterSpacing.xSmall)
            .bringIntoViewRequester(bringIntoViewRequester)
            .onFocusChanged { state ->
                if (state.isFocused) {
                    coroutineScope.launch {
                        delay(220L)
                        bringIntoViewRequester.bringIntoView()
                    }
                }
            }
            .focusRequester(focusRequester),
        value = value,
        onValueChange = onValueChange,
        placeholder = {
            Text(text = stringResource(R.string.post_comment_placeholder))
        },
        enabled = !isSubmitting,
        minLines = 1,
        maxLines = 3,
        shape = RoundedCornerShape(22.dp),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.24f),
            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.18f),
            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.12f),
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            disabledIndicatorColor = Color.Transparent,
        ),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
        keyboardActions = KeyboardActions(onSend = { onSend() }),
        trailingIcon = {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary,
            ) {
                IconButton(
                    enabled = !isSubmitting,
                    onClick = onSend,
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.Send,
                        contentDescription = stringResource(R.string.post_comment_send),
                        tint = MaterialTheme.colorScheme.onPrimary,
                    )
                }
            }
        },
    )
}

@Composable
private fun EngagementStat(
    icon: ImageVector,
    text: String,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    textColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    enabled: Boolean = true,
    textStyle: TextStyle = MaterialTheme.typography.bodyLarge,
    iconSize: androidx.compose.ui.unit.Dp = 18.dp,
    onClick: (() -> Unit)? = null,
) {
    Row(
        modifier = modifier.then(
            if (onClick != null) {
                Modifier
                    .clickable(enabled = enabled, onClick = onClick)
                    .padding(horizontal = 4.dp, vertical = 4.dp)
            } else {
                Modifier.padding(horizontal = 2.dp, vertical = 4.dp)
            }
        ),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            modifier = Modifier.size(iconSize),
            tint = tint,
        )
        Text(
            text = text,
            style = textStyle,
            color = textColor,
        )
    }
}

@Composable
private fun ActionPill(
    text: String,
    onClick: () -> Unit,
) {
    Surface(
        shape = PillShape,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.9f)),
        onClick = onClick,
    ) {
        Text(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
        )
    }
}

@Composable
private fun LoadingRow() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
    ) {
        EterLoadingIndicator()
    }
}

@Composable
private fun CommentSkeletonItem() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(EterSpacing.small),
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .shimmer(),
        )
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.35f)
                    .size(width = 0.dp, height = 13.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .shimmer(),
            )
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.88f)
                    .size(width = 0.dp, height = 12.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .shimmer(),
            )
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.65f)
                    .size(width = 0.dp, height = 12.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .shimmer(),
            )
        }
    }
}

@Composable
private fun PostLoadErrorState(
    messageResId: Int,
    onRetry: () -> Unit,
    onBack: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(EterSpacing.section),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = stringResource(messageResId),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Spacer(modifier = Modifier.padding(top = EterSpacing.medium))
        Row(horizontalArrangement = Arrangement.spacedBy(EterSpacing.small)) {
            TextButton(onClick = onBack) {
                Text(text = stringResource(R.string.post_back))
            }
            Button(onClick = onRetry) {
                Text(text = stringResource(R.string.post_retry))
            }
        }
    }
}

private fun Throwable?.toPostMessageResId(): Int = when ((this as? PostException)?.primaryReason) {
    PostException.Reason.NETWORK -> R.string.post_error_network
    PostException.Reason.NOT_FOUND -> R.string.post_error_not_found
    PostException.Reason.FORBIDDEN -> R.string.post_error_forbidden
    else -> R.string.post_error_generic
}

private fun Throwable.toCommentsMessageResId(): Int = when ((this as? PostException)?.primaryReason) {
    PostException.Reason.NETWORK -> R.string.post_comments_error_network
    PostException.Reason.FORBIDDEN -> R.string.post_comments_error_forbidden
    PostException.Reason.NOT_FOUND -> R.string.post_comments_error_not_found
    else -> when ((this as? ServerValidationException)?.reason) {
        ServerValidationException.Reason.INVALID_DATA -> R.string.post_comments_error_invalid_data
        ServerValidationException.Reason.CONFLICT -> R.string.post_comments_error_generic
        null -> R.string.post_comments_error_generic
    }
}

private fun String.toCommentDateTimeText(): String {
    val formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm", Locale.getDefault())
    return parseServerInstant(this)?.atZone(ZoneId.systemDefault())?.format(formatter) ?: this
}

private fun Post.toCanonicalUrl(): String {
    return EterDeepLink.postWebUri(
        postId = postId,
        slug = slug ?: postId.toString(),
    ).toString()
}

private fun findCommentById(
    commentId: Long,
    comments: List<PostCommentUiModel>,
    repliesByCommentId: Map<Long, List<PostCommentUiModel>>,
): com.nestorian87.eter.domain.model.PostComment? {
    comments.firstOrNull { it.comment.commentId == commentId }?.let { return it.comment }
    repliesByCommentId.values
        .flatten()
        .firstOrNull { it.comment.commentId == commentId }
        ?.let { return it.comment }
    return null
}

private const val COMMENTS_HEADER_INDEX = 3

@EterScreenPreviews
@Composable
private fun PostScreenPreview() {
    EterPreview {
        PostLoadErrorState(
            messageResId = R.string.post_error_generic,
            onRetry = {},
            onBack = {},
        )
    }
}
