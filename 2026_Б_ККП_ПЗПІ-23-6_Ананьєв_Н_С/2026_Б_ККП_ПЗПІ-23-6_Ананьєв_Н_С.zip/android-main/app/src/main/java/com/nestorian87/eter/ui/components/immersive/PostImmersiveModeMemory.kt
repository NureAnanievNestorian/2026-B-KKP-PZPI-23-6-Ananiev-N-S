package com.nestorian87.eter.ui.components.immersive

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nestorian87.eter.domain.model.PostTextSynchronization
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.sin

internal fun DrawScope.drawMemoryLines(
    lines: List<MemoryLine>,
    currentTimeMs: Long,
    colors: ImmersiveColors,
) {
    if (lines.isEmpty()) return

    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
        letterSpacing = -0.01f
    }

    val centerX = size.width / 2f
    val centerY = size.height / 2f
    val compactLineMaxChars = 26
    val regularLineMaxChars = 34
    val dpClampX = 180f
    val dpClampY = 300f
    val minAlpha = 0.006f
    val maxAlpha = 0.22f
    val minTextScale = 0.42f
    val maxTextScale = 0.82f
    val minTextSize = 10.5.sp.toPx()
    val maxTextSize = 14.2.sp.toPx()
    val baseTextSize = 13.5.sp.toPx()
    val lineHeightMultiplier = 1.13f

    drawContext.canvas.nativeCanvas.save()
    lines.forEach { line ->
        val visibleAgeMs = (currentTimeMs - line.appearMs).toFloat()
        if (visibleAgeMs <= 0f) return@forEach

        val lifeProgress = (visibleAgeMs / MemoryLineLifetimeMs).coerceIn(0f, 1f)
        val fadeIn = smootherStep((visibleAgeMs / MemoryLineFadeInMs).coerceIn(0f, 1f))
        val fadeOut = smootherStep(
            ((MemoryLineLifetimeMs - visibleAgeMs) / MemoryLineFadeOutMs).coerceIn(
                0f,
                1f
            )
        )
        val temporalAlpha = fadeIn * fadeOut
        if (temporalAlpha <= minAlpha) return@forEach

        val perspective = smootherStep(lifeProgress)
        val phase =
            (((currentTimeMs + line.driftDelayMs.toLong()) % line.driftDurationMs.toLong()).toFloat() / line.driftDurationMs)
                .let { if (it < 0f) it + 1f else it }

        val baseX = line.xDp * (1f + perspective * 0.26f)
        val baseY = line.yDp * (1f + perspective * 0.20f)
        val driftX = sin(phase * TwoPi) * line.driftXDp * (1f - perspective * 0.35f)
        val driftY = cos(phase * TwoPi * 0.63f + 0.5f) * line.driftYDp * (1f - perspective * 0.35f)

        val xDpClamped = (baseX + driftX).coerceIn(-dpClampX, dpClampX)
        val yDpClamped = (baseY + driftY).coerceIn(-dpClampY, dpClampY)
        val x = xDpClamped.dp.toPx()
        val y = yDpClamped.dp.toPx()

        val vanish = 1f - perspective * 0.58f
        val alpha = (line.opacity * line.brightness * temporalAlpha * vanish).coerceIn(0f, maxAlpha)
        if (alpha <= minAlpha) return@forEach

        val textScale =
            (line.scale * (1f - perspective * 0.32f)).coerceIn(minTextScale, maxTextScale)
        val textSize = (baseTextSize * textScale).coerceIn(minTextSize, maxTextSize)
        val lineHeight = textSize * lineHeightMultiplier
        val wrapped = line.text.toMemoryCanvasLines(
            maxChars = if (size.width < MobileCompactWidthBreakpoint.toPx()) compactLineMaxChars else regularLineMaxChars,
        )

        paint.color = colors.memoryText.copy(alpha = alpha).toArgb()
        paint.textSize = textSize

        drawContext.canvas.nativeCanvas.save()
        drawContext.canvas.nativeCanvas.translate(centerX + x, centerY + y)
        drawContext.canvas.nativeCanvas.rotate(line.rotate * (1f - perspective * 0.35f))
        val firstBaseline = -((wrapped.size - 1) * lineHeight) / 2f
        wrapped.forEachIndexed { index, part ->
            drawContext.canvas.nativeCanvas.drawText(
                part,
                0f,
                firstBaseline + index * lineHeight,
                paint
            )
        }
        drawContext.canvas.nativeCanvas.restore()
    }
    drawContext.canvas.nativeCanvas.restore()
}

private fun String.toMemoryCanvasLines(maxChars: Int): List<String> {
    val normalized = trim().replace(Regex("\\s+"), " ")
    if (normalized.length <= maxChars) return listOf(normalized)

    val words = normalized.split(" ")
    val lines = mutableListOf<String>()
    var current = ""
    for (word in words) {
        val candidate = if (current.isBlank()) word else "$current $word"
        if (candidate.length <= maxChars) {
            current = candidate
        } else {
            if (current.isNotBlank()) lines += current
            current = word
            if (lines.size == 1) break
        }
    }
    if (current.isNotBlank() && lines.size < 2) lines += current
    return lines.take(2)
}

private fun smootherStep(value: Float): Float {
    val x = value.coerceIn(0f, 1f)
    return x * x * x * (x * (x * 6f - 15f) + 10f)
}

internal fun computeMemoryLines(
    textLines: List<String>,
    synchronization: List<PostTextSynchronization>,
    activeLineIndex: Int,
    currentTimeMs: Long,
    openedAudioMs: Long,
    isAfterLastLine: Boolean,
): List<MemoryLine> {
    if (synchronization.isEmpty() || textLines.isEmpty()) return emptyList()

    val oldestAllowedMs =
        currentTimeMs - MemoryLineLifetimeMs.toLong() - InitialMemoryBackfillWindowMs
    val visibleItems = synchronization
        .asSequence()
        .filter { item ->
            item.audioStartMomentMs <= currentTimeMs &&
                    item.audioStartMomentMs >= oldestAllowedMs &&
                    (item.lineIndex != activeLineIndex || isAfterLastLine)
        }
        .filter { item -> !textLines.getOrNull(item.lineIndex).isNullOrBlank() }
        .distinctBy { item -> item.lineIndex }
        .toList()
        .takeLast(MaxMemoryLines)

    return visibleItems.mapNotNull { item ->
        val text = textLines.getOrNull(item.lineIndex)?.trim()
        if (text.isNullOrBlank()) return@mapNotNull null

        val isBackfill = item.audioStartMomentMs < openedAudioMs
        val appearMs = if (isBackfill) {
            openedAudioMs + MemoryBackfillAppearDelayMs +
                    (item.lineIndex % MaxMemoryLines).toLong() * MemoryBackfillStaggerMs
        } else {
            item.audioStartMomentMs + MemoryLineDelayMs
        }

        val visibleAgeMs = (currentTimeMs - appearMs).coerceAtLeast(0L).toFloat()
        val ageProgress = (visibleAgeMs / MemoryLineLifetimeMs).coerceIn(0f, 1f)
        val seed = item.lineIndex + 1
        val lane = seed % 8

        val anchor = when (lane) {
            0 -> -154f to -226f
            1 -> 154f to -216f
            2 -> -164f to 220f
            3 -> 164f to 230f
            4 -> -190f to -92f
            5 -> 190f to 96f
            6 -> -92f to 272f
            else -> 96f to -274f
        }

        val x = anchor.first + stableRange(seed, 7, -18f, 18f)
        val y = anchor.second + stableRange(seed, 8, -16f, 16f)
        val rotate = stableRange(seed, 9, -4.2f, 4.2f)
        val stableScale = stableRange(seed, 10, 0.82f, 1.0f)
        val perspectiveScale = max(0.44f, stableScale * (1f - ageProgress * 0.20f))

        val opacity = (0.34f - ageProgress * 0.10f).coerceAtLeast(0f)
        if (opacity < 0.015f || perspectiveScale < 0.30f) return@mapNotNull null

        val brightness = max(0.68f, 1f - ageProgress * 0.18f)

        MemoryLine(
            key = "${item.lineIndex}-${item.audioStartMomentMs}",
            text = text,
            startMs = item.audioStartMomentMs,
            appearMs = appearMs,
            xDp = x,
            yDp = y,
            zDp = -ageProgress * 820f,
            rotate = rotate,
            scale = perspectiveScale,
            opacity = opacity,
            blurDp = 0f,
            brightness = brightness,
            driftXDp = stableRange(seed, 11, -3.8f, 3.8f),
            driftYDp = stableRange(seed, 12, -3.4f, 3.4f),
            driftDurationMs = stableRange(seed, 13, 34_000f, 52_000f),
            driftDelayMs = seed * -690f,
        )
    }
}

private fun stableNumber(seed: Int, salt: Int): Float {
    val value = kotlin.math.sin(seed * 12.9898f + salt * 78.233f) * 43758.547f
    return value - floor(value)
}

private fun stableRange(seed: Int, salt: Int, min: Float, max: Float): Float =
    min + stableNumber(seed, salt) * (max - min)
