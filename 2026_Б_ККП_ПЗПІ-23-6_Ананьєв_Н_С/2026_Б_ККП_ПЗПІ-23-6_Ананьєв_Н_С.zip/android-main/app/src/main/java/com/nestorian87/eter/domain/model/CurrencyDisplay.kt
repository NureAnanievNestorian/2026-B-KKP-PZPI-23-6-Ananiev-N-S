package com.nestorian87.eter.domain.model

fun String.toCurrencySymbol(): String = when (uppercase()) {
    "USD" -> "$"
    "EUR" -> "€"
    "UAH" -> "₴"
    else -> " $this"
}
