package com.nestorian87.eter.ui.screens.postsynchronization

import androidx.compose.runtime.Composable
import com.nestorian87.eter.domain.model.Post
import com.nestorian87.eter.domain.model.PostStatus
import com.nestorian87.eter.ui.theme.EterPreview
import com.nestorian87.eter.ui.theme.EterScreenPreviews

@EterScreenPreviews
@Composable
private fun PostSynchronizationScreenPreview() {
    val previewText = """
        First line

        Second line
        Third line
        Fourth line
        Fifth line
    """.trimIndent()

    EterPreview {
        PostSynchronizationScreenContent(
            uiState = PostSynchronizationUiState(
                isLoading = false,
                post = previewPost(text = previewText),
                isPremium = true,
                currentUserId = 1,
                syncableLines = buildSyncableLines(previewText),
                localSynchronization = mapOf(
                    0 to 0,
                    2 to 12_400,
                    3 to 18_100,
                ),
                focusedLinePosition = 2,
                currentTimeSeconds = 14f,
                durationSeconds = 62f,
                hasAttemptedSave = true,
                validationIssues = mapOf(
                    4 to PostSynchronizationValidationIssue(
                        kind = PostSynchronizationValidationKind.MISSING,
                    ),
                ),
            ),
            onBack = {},
            onRetryLoad = {},
            onSave = {},
            onTogglePlayback = {},
            onSeekToPercent = {},
            onSeekBackward = {},
            onSeekForward = {},
            onPreviousLine = {},
            onStampLine = {},
            onNextLine = {},
            onClearAll = {},
            onFocusLine = {},
            onJumpToLine = {},
            onClearLine = {},
        )
    }
}

private fun previewPost(text: String): Post = Post(
    postId = 1,
    title = "Evening Poem",
    text = text,
    audioFileUrl = "https://example.com/audio.mp3",
    audioDurationSeconds = 62,
    status = PostStatus.PUBLISHED,
    listens = 0,
    authorId = 1,
    createdAt = "",
    updatedAt = "",
)
