package com.nestorian87.eter.ui.screens.profile

import com.nestorian87.eter.domain.model.Subscription
import com.nestorian87.eter.domain.model.SubscriptionTransaction

data class SubscriptionManagementUiState(
    val isLoading: Boolean = true,
    val subscription: Subscription? = null,
    val priceUsd: Int? = null,
    val freeDurationMinutes: Int? = null,
    val premiumDurationMinutes: Int? = null,
    val transactions: List<SubscriptionTransaction> = emptyList(),
    val isTransactionsLoading: Boolean = false,
    val isLoadingMoreTransactions: Boolean = false,
    val canLoadMoreTransactions: Boolean = false,
    val showCancelDialog: Boolean = false,
    val isCancelLoading: Boolean = false,
    val isCheckoutLoading: Boolean = false,
    val isCardUpdateLoading: Boolean = false,
    val isCardLinking: Boolean = false,
    val cancelError: String? = null,
    val loadError: String? = null,
)
