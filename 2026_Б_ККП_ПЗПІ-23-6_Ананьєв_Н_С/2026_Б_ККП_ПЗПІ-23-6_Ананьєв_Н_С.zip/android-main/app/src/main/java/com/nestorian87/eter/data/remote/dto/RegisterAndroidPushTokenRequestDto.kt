package com.nestorian87.eter.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class RegisterAndroidPushTokenRequestDto(
    val token: String,
    val deviceId: String? = null,
    val appVersion: String? = null,
)
