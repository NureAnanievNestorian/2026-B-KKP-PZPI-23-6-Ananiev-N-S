package com.nestorian87.eter.service

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.nestorian87.eter.MainActivity
import com.nestorian87.eter.R
import com.nestorian87.eter.data.repository.AndroidPushTokenSyncer
import com.nestorian87.eter.ui.navigation.EterDeepLink
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class EterFirebaseMessagingService : FirebaseMessagingService() {
    @Inject
    lateinit var androidPushTokenSyncer: AndroidPushTokenSyncer

    @Inject
    lateinit var applicationScope: CoroutineScope

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)

        val targetUri = PushNotificationNavigation.targetUri(remoteMessage.data)
        val payload = PushNotificationPayload.from(remoteMessage) ?: return
        ensureNotificationChannel()
        val notificationTag = PushNotificationPayload.notificationTag(remoteMessage.data)
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        NotificationManagerCompat.from(this).notify(
            notificationTag,
            nextNotificationId(notificationTag),
            NotificationCompat.Builder(this, PUSH_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification_small)
                .setContentTitle(payload.title)
                .setContentText(payload.description)
                .setStyle(NotificationCompat.BigTextStyle().bigText(payload.description))
                .setContentIntent(createContentIntent(targetUri))
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build(),
        )
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        applicationScope.launch {
            androidPushTokenSyncer.syncTokenIfAuthenticated(token)
        }
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return
        }
        val notificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            PUSH_CHANNEL_ID,
            getString(R.string.push_notification_channel_name),
            NotificationManager.IMPORTANCE_HIGH,
        ).apply {
            description = getString(R.string.push_notification_channel_description)
        }
        notificationManager.createNotificationChannel(channel)
    }

    private fun createContentIntent(targetUri: android.net.Uri?): PendingIntent {
        val intent = Intent(this, MainActivity::class.java).apply {
            action = Intent.ACTION_VIEW
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            if (targetUri != null) {
                EterDeepLink.putUri(this, targetUri)
            }
        }
        return PendingIntent.getActivity(
            this,
            targetUri?.hashCode() ?: 0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun nextNotificationId(notificationTag: String?): Int =
        notificationTag?.hashCode() ?: System.currentTimeMillis().toInt()

    companion object {
        private const val PUSH_CHANNEL_ID = "eter_push_notifications"
    }
}
