package com.nestorian87.eter.ui.screens.postsynchronization

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Forward5
import androidx.compose.material.icons.rounded.Replay5
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nestorian87.eter.R
import com.nestorian87.eter.ui.components.audio.AudioWaveformSeekBar
import com.nestorian87.eter.ui.components.audio.CompactWaveformPlayerBar
import com.nestorian87.eter.ui.components.audio.EterPlayButton
import com.nestorian87.eter.ui.components.audio.toAudioTimeText
import com.nestorian87.eter.ui.components.layout.rememberLazyListScrollRevealProgress
import com.nestorian87.eter.ui.theme.EterSpacing

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun PostSynchronizationEditorContent(
    uiState: PostSynchronizationUiState,
    contentPadding: PaddingValues,
    onTogglePlayback: () -> Unit,
    onSeekToPercent: (Float) -> Unit,
    onSeekBackward: () -> Unit,
    onSeekForward: () -> Unit,
    onFocusLine: (Int) -> Unit,
    onJumpToLine: (Int) -> Unit,
    onClearLine: (Int) -> Unit,
) {
    val listState = rememberLazyListState()
    val leadingItemCount = (if (uiState.saveError != null) 1 else 0) + 2
    val compactPlayerProgress by rememberLazyListScrollRevealProgress(
        listState = listState,
        revealDistance = 132.dp,
        headerItemIndex = if (uiState.saveError != null) 1 else 0,
    )
    val compactPlayerRevealAlpha = compactPlayerRevealAlpha(compactPlayerProgress)

    LaunchedEffect(uiState.focusedLinePosition, leadingItemCount) {
        uiState.focusedLinePosition?.let { focusedPosition ->
            val targetIndex =
                (leadingItemCount + focusedPosition - PREVIOUS_LINE_VISIBLE_COUNT).coerceAtLeast(0)
            listState.animateScrollToItem(
                index = targetIndex,
                scrollOffset = -FOCUSED_LINE_CONTEXT_OFFSET_PX
            )
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding),
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            state = listState,
            contentPadding = PaddingValues(
                start = EterSpacing.medium,
                top = EterSpacing.small,
                end = EterSpacing.medium,
                bottom = 112.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
        ) {
            if (uiState.saveError != null) {
                item(key = "save_error") {
                    ErrorCard(message = stringResource(uiState.saveError.toPostSyncErrorMessageResId()))
                }
            }

            item(key = "player") {
                PlayerCard(
                    modifier = Modifier.playerCollapse(compactPlayerProgress),
                    uiState = uiState,
                    onTogglePlayback = onTogglePlayback,
                    onSeekToPercent = onSeekToPercent,
                    onSeekBackward = onSeekBackward,
                    onSeekForward = onSeekForward,
                )
            }

            item(key = "summary") {
                EditorSummary(
                    syncedCount = uiState.syncedCount,
                    totalSyncable = uiState.syncableLines.size,
                    progressPercent = uiState.progressPercent,
                    focusedLinePosition = uiState.focusedLinePosition,
                )
            }

            items(
                items = uiState.syncableLines,
                key = { it.lineIndex },
            ) { line ->
                PoemLineRow(
                    line = line,
                    isFocused = uiState.focusedLine?.lineIndex == line.lineIndex,
                    timestampMs = uiState.localSynchronization[line.lineIndex],
                    validationIssue = uiState.validationIssues[line.lineIndex],
                    onClick = { onFocusLine(line.position) },
                    onJump = { onJumpToLine(line.lineIndex) },
                    onClear = { onClearLine(line.lineIndex) },
                )
            }
        }

        CompactPlayerOverlay(
            modifier = Modifier.align(Alignment.TopCenter),
            alpha = compactPlayerRevealAlpha,
            uiState = uiState,
            onTogglePlayback = onTogglePlayback,
            onSeekToPercent = onSeekToPercent,
            onSeekBackward = onSeekBackward,
            onSeekForward = onSeekForward,
        )
    }
}

@Composable
private fun CompactPlayerOverlay(
    modifier: Modifier = Modifier,
    alpha: Float,
    uiState: PostSynchronizationUiState,
    onTogglePlayback: () -> Unit,
    onSeekToPercent: (Float) -> Unit,
    onSeekBackward: () -> Unit,
    onSeekForward: () -> Unit,
) {
    if (alpha > 0f) {
        CompactPlayerBar(
            modifier = modifier.compactPlayerReveal(alpha),
            uiState = uiState,
            onTogglePlayback = onTogglePlayback,
            onSeekToPercent = onSeekToPercent,
            onSeekBackward = onSeekBackward,
            onSeekForward = onSeekForward,
        )
    }
}

@Composable
private fun PlayerCard(
    modifier: Modifier = Modifier,
    uiState: PostSynchronizationUiState,
    onTogglePlayback: () -> Unit,
    onSeekToPercent: (Float) -> Unit,
    onSeekBackward: () -> Unit,
    onSeekForward: () -> Unit,
) {
    val post = uiState.post ?: return

    Surface(
        modifier = modifier,
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(20.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(EterSpacing.medium),
            verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
        ) {
            Text(
                text = post.title.orEmpty().ifBlank { stringResource(R.string.post_untitled) },
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            AudioWaveformSeekBar(
                waveform = post.audioAnalysis?.waveform,
                progressFraction = if (uiState.durationSecondsOrPostFallback > 0f) {
                    (uiState.currentTimeSeconds / uiState.durationSecondsOrPostFallback).coerceIn(
                        0f,
                        1f
                    )
                } else {
                    0f
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                onSeek = onSeekToPercent,
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = uiState.currentTimeSeconds.toAudioTimeText(),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    text = uiState.durationSecondsOrPostFallback.toAudioTimeText(),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(
                    EterSpacing.medium,
                    Alignment.CenterHorizontally
                ),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onSeekBackward) {
                    Icon(
                        imageVector = Icons.Rounded.Replay5,
                        contentDescription = stringResource(R.string.player_seek_back),
                    )
                }
                EterPlayButton(
                    isPlaying = uiState.isPlaying,
                    isActive = uiState.isCurrentPostActive,
                    size = 56.dp,
                    onClick = onTogglePlayback,
                )
                IconButton(onClick = onSeekForward) {
                    Icon(
                        imageVector = Icons.Rounded.Forward5,
                        contentDescription = stringResource(R.string.player_seek_forward),
                    )
                }
            }
        }
    }
}

@Composable
private fun EditorSummary(
    syncedCount: Int,
    totalSyncable: Int,
    progressPercent: Int,
    focusedLinePosition: Int?,
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
    ) {
        Text(
            text = stringResource(
                R.string.post_sync_progress_value,
                syncedCount,
                totalSyncable,
                progressPercent,
            ),
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = stringResource(R.string.post_sync_all_lines_title),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            focusedLinePosition?.let { position ->
                Text(
                    text = stringResource(
                        R.string.post_sync_focus_count,
                        position + 1,
                        totalSyncable,
                    ),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        HorizontalDivider()
    }
}

@Composable
private fun CompactPlayerBar(
    modifier: Modifier = Modifier,
    uiState: PostSynchronizationUiState,
    onTogglePlayback: () -> Unit,
    onSeekToPercent: (Float) -> Unit,
    onSeekBackward: () -> Unit,
    onSeekForward: () -> Unit,
) {
    val progressFraction = if (uiState.durationSecondsOrPostFallback > 0f) {
        (uiState.currentTimeSeconds / uiState.durationSecondsOrPostFallback).coerceIn(0f, 1f)
    } else {
        0f
    }
    CompactWaveformPlayerBar(
        currentTimeLabel = uiState.currentTimeSeconds.toAudioTimeText(),
        waveform = uiState.post?.audioAnalysis?.waveform,
        progressFraction = progressFraction,
        isPlaying = uiState.isPlaying,
        modifier = modifier,
        onTogglePlayback = onTogglePlayback,
        onSeek = onSeekToPercent,
        onSeekBackward = onSeekBackward,
        onSeekForward = onSeekForward,
    )
}

private fun Modifier.playerCollapse(progress: Float): Modifier = graphicsLayer {
    val fadeOutProgress = (progress / PLAYER_COLLAPSE_CUTOFF).coerceIn(0f, 1f)
    alpha = 1f - fadeOutProgress
    translationY = -fadeOutProgress * 24f
}

private fun Modifier.compactPlayerReveal(progress: Float): Modifier = graphicsLayer {
    alpha = progress
}

private fun compactPlayerRevealAlpha(progress: Float): Float {
    val collapseProgress = (progress / PLAYER_COLLAPSE_CUTOFF).coerceIn(0f, 1f)
    return ((collapseProgress - PLAYER_COMPACT_REVEAL_START) /
            (1f - PLAYER_COMPACT_REVEAL_START)).coerceIn(0f, 1f)
}

private const val FOCUSED_LINE_CONTEXT_OFFSET_PX = 220
private const val PREVIOUS_LINE_VISIBLE_COUNT = 2
private const val PLAYER_COLLAPSE_CUTOFF = 0.82f
private const val PLAYER_COMPACT_REVEAL_START = 0.5f

@Composable
private fun PoemLineRow(
    line: SyncableLineUiModel,
    isFocused: Boolean,
    timestampMs: Int?,
    validationIssue: PostSynchronizationValidationIssue?,
    onClick: () -> Unit,
    onJump: () -> Unit,
    onClear: () -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = when {
            validationIssue != null -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.42f)
            isFocused -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.78f)
            else -> MaterialTheme.colorScheme.surface
        },
        shape = RoundedCornerShape(20.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .combinedClickable(
                    onClick = onClick,
                    onLongClick = {
                        if (timestampMs != null && !line.isLocked) {
                            onClear()
                        }
                    },
                )
                .padding(EterSpacing.medium),
            horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium),
            verticalAlignment = Alignment.Top,
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(
                        if (isFocused) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.surfaceVariant,
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = "${line.lineIndex + 1}",
                    style = MaterialTheme.typography.labelLarge,
                    color = if (isFocused) MaterialTheme.colorScheme.onPrimary
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(EterSpacing.small),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (isFocused) {
                        StatusBadge(
                            label = stringResource(R.string.post_sync_current_line_badge),
                            isHighlighted = true,
                        )
                    }
                    StatusBadge(
                        label = when {
                            validationIssue != null -> stringResource(R.string.post_sync_status_error)
                            line.isLocked -> stringResource(R.string.post_sync_status_locked)
                            timestampMs != null -> stringResource(R.string.post_sync_status_synced)
                            else -> stringResource(R.string.post_sync_status_pending)
                        },
                        isError = validationIssue != null,
                    )
                }
                Text(
                    text = line.text,
                    style = if (isFocused) {
                        MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                    } else {
                        MaterialTheme.typography.bodyLarge
                    },
                )
                validationIssue?.let { issue ->
                    Text(
                        text = stringResource(issue.kind.toMessageResId()),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }
            TimestampBadge(
                label = timestampMs?.let(::formatTimestampMs)
                    ?: stringResource(R.string.post_sync_status_pending),
                isPending = timestampMs == null,
                isError = validationIssue != null,
                onClick = if (timestampMs != null) onJump else null,
            )
        }
    }
}

@Composable
private fun TimestampBadge(
    label: String,
    isPending: Boolean,
    isError: Boolean,
    onClick: (() -> Unit)?,
) {
    Surface(
        color = when {
            isError -> MaterialTheme.colorScheme.errorContainer
            isPending -> MaterialTheme.colorScheme.surfaceVariant
            else -> MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
        },
        shape = RoundedCornerShape(999.dp),
    ) {
        Text(
            text = label,
            modifier = Modifier
                .then(
                    if (onClick != null) {
                        Modifier.combinedClickable(
                            onClick = onClick,
                            onLongClick = {},
                        )
                    } else {
                        Modifier
                    },
                )
                .padding(horizontal = 12.dp, vertical = 8.dp),
            style = MaterialTheme.typography.labelLarge,
            color = when {
                isError -> MaterialTheme.colorScheme.onErrorContainer
                isPending -> MaterialTheme.colorScheme.onSurfaceVariant
                else -> MaterialTheme.colorScheme.primary
            },
        )
    }
}

@Composable
private fun StatusBadge(
    label: String,
    isError: Boolean = false,
    isHighlighted: Boolean = false,
) {
    Surface(
        color = if (isError) {
            MaterialTheme.colorScheme.errorContainer
        } else if (isHighlighted) {
            MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
        } else {
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.86f)
        },
        shape = RoundedCornerShape(999.dp),
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelLarge,
            color = if (isError) {
                MaterialTheme.colorScheme.onErrorContainer
            } else if (isHighlighted) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.onSurface
            },
        )
    }
}
