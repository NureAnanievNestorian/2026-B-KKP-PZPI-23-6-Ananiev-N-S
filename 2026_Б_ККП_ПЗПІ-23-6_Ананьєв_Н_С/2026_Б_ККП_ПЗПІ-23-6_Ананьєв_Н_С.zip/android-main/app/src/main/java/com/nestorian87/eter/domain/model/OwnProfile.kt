package com.nestorian87.eter.domain.model

data class OwnProfile(
    val userId: Long,
    val name: String,
    val username: String,
    val email: String,
    val photo: String? = null,
    val bio: String? = null,
    val link: String? = null,
    val isEmailVerified: Boolean,
    val isPremium: Boolean,
    val createdAt: String,
    val followersCount: Int,
    val followingCount: Int,
    val postsCount: Int,
    val currentViolationsCount: Int,
    val maxViolationsBeforeBlock: Int,
)
