package com.nestorian87.eter.ui.components.audio

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nestorian87.eter.R

@Composable
fun EterPlayButton(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    isActive: Boolean = false,
    size: Dp = 48.dp,
    onClick: () -> Unit,
) {
    val background by animateColorAsState(
        targetValue = when {
            isPlaying -> MaterialTheme.colorScheme.primary
            isActive -> MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
            else -> MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
        },
        animationSpec = tween(220),
        label = "eter_play_background",
    )
    val borderColor by animateColorAsState(
        targetValue = if (isActive) {
            MaterialTheme.colorScheme.primary.copy(alpha = 0.46f)
        } else {
            MaterialTheme.colorScheme.outline.copy(alpha = 0.24f)
        },
        animationSpec = tween(220),
        label = "eter_play_border",
    )

    Surface(
        modifier = modifier
            .size(size)
            .scale(if (isPlaying) 0.96f else 1f),
        shape = CircleShape,
        color = background,
        border = BorderStroke(1.dp, borderColor),
        onClick = onClick,
    ) {
        Box(contentAlignment = Alignment.Center) {
            AnimatedContent(
                targetState = isPlaying,
                transitionSpec = { fadeIn(tween(140)) togetherWith fadeOut(tween(140)) },
                label = "eter_play_icon",
            ) { playing ->
                Icon(
                    imageVector = if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = if (playing) {
                        stringResource(R.string.player_pause)
                    } else {
                        stringResource(R.string.player_resume)
                    },
                    tint = if (playing) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(size * 0.46f),
                )
            }
        }
    }
}

fun Float.toAudioTimeText(): String {
    val totalSeconds = toInt().coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%02d:%02d".format(minutes, seconds)
}
