package com.nestorian87.eter.ui.components.audio

import android.util.Base64
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@Composable
fun AudioWaveformSeekBar(
    waveform: String?,
    progressFraction: Float,
    modifier: Modifier = Modifier,
    onSeek: (Float) -> Unit,
    playedColor: Color = MaterialTheme.colorScheme.primary.copy(alpha = 0.78f),
    unplayedColor: Color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.26f),
) {
    if (!waveform.isNullOrBlank()) {
        DecodedWaveformSeekBar(
            waveform = waveform,
            progressFraction = progressFraction,
            modifier = modifier,
            onSeek = onSeek,
            playedColor = playedColor,
            unplayedColor = unplayedColor,
        )
    } else {
        GeneratedWaveformSeekBar(
            progressFraction = progressFraction,
            modifier = modifier,
            onSeek = onSeek,
            playedColor = playedColor,
            unplayedColor = unplayedColor,
        )
    }
}

@Composable
private fun GeneratedWaveformSeekBar(
    progressFraction: Float,
    modifier: Modifier = Modifier,
    onSeek: (Float) -> Unit,
    playedColor: Color,
    unplayedColor: Color,
) {
    val amplitudes = remember {
        listOf(
            0.12f, 0.18f, 0.25f, 0.32f, 0.2f, 0.42f, 0.36f, 0.54f, 0.48f, 0.66f,
            0.4f, 0.7f, 0.58f, 0.34f, 0.62f, 0.46f, 0.74f, 0.52f, 0.3f, 0.68f,
            0.56f, 0.44f, 0.76f, 0.38f, 0.6f, 0.5f, 0.28f, 0.64f, 0.72f, 0.48f,
            0.2f, 0.26f, 0.35f, 0.5f, 0.42f, 0.62f, 0.58f, 0.31f, 0.67f, 0.46f,
            0.75f, 0.52f, 0.24f, 0.6f, 0.48f, 0.7f, 0.56f, 0.37f, 0.64f, 0.41f,
            0.72f, 0.54f, 0.28f, 0.63f, 0.46f, 0.68f, 0.5f, 0.34f, 0.58f, 0.44f,
        )
    }
    WaveformBars(
        amplitudes = amplitudes,
        progressFraction = progressFraction,
        modifier = modifier,
        onSeek = onSeek,
        playedColor = playedColor,
        unplayedColor = unplayedColor,
    )
}

@Composable
private fun DecodedWaveformSeekBar(
    waveform: String,
    progressFraction: Float,
    modifier: Modifier = Modifier,
    onSeek: (Float) -> Unit,
    playedColor: Color,
    unplayedColor: Color,
) {
    BoxWithConstraints(modifier = modifier) {
        val density = LocalDensity.current
        val targetBarCount = remember(maxWidth, density) {
            val widthPx = with(density) { maxWidth.toPx() }
            (widthPx / 5.2f).roundToInt().coerceIn(32, 88)
        }
        val amplitudes = remember(waveform, targetBarCount) {
            decodeWaveformBars(waveform, targetBarCount)
        }
        WaveformBars(
            amplitudes = amplitudes,
            progressFraction = progressFraction,
            modifier = Modifier.fillMaxSize(),
            onSeek = onSeek,
            playedColor = playedColor,
            unplayedColor = unplayedColor,
        )
    }
}

@Composable
private fun WaveformBars(
    amplitudes: List<Float>,
    progressFraction: Float,
    modifier: Modifier = Modifier,
    onSeek: (Float) -> Unit,
    playedColor: Color,
    unplayedColor: Color,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .fillMaxHeight()
            .pointerInput(amplitudes.size) {
                detectTapGestures { offset ->
                    if (size.width > 0) {
                        onSeek((offset.x / size.width.toFloat()).coerceIn(0f, 1f) * 100f)
                    }
                }
            },
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        amplitudes.forEachIndexed { index, amplitude ->
            val barProgress =
                if (amplitudes.lastIndex <= 0) 1f else index.toFloat() / amplitudes.lastIndex.toFloat()
            val isPlayed = barProgress <= progressFraction
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight((0.18f + (amplitude * 0.82f)).coerceIn(0.18f, 1f))
                    .background(
                        color = if (isPlayed) playedColor else unplayedColor,
                        shape = CircleShape,
                    ),
            )
        }
    }
}

private fun decodeWaveformBars(
    waveform: String,
    targetBarCount: Int,
): List<Float> {
    val decoded = runCatching { Base64.decode(waveform, Base64.DEFAULT) }.getOrNull()
        ?: return List(targetBarCount) { 0.18f }
    if (decoded.isEmpty()) {
        return List(targetBarCount) { 0.18f }
    }

    return List(targetBarCount) { index ->
        val start = (index * decoded.size) / targetBarCount
        val endExclusive = ((index + 1) * decoded.size) / targetBarCount
        if (start >= decoded.size) {
            0.18f
        } else {
            val safeEnd = endExclusive.coerceAtLeast(start + 1).coerceAtMost(decoded.size)
            var total = 0f
            for (sampleIndex in start until safeEnd) {
                total += (decoded[sampleIndex].toInt() and 0xFF) / 255f
            }
            (total / (safeEnd - start)).coerceIn(0.12f, 1f)
        }
    }
}
