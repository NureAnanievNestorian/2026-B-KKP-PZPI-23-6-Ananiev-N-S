package com.nestorian87.eter.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class CheckoutResultDto(
    val invoiceId: String,
    val checkoutUrl: String? = null,
)
