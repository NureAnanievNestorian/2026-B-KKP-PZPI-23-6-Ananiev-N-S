package com.nestorian87.eter.util

import java.time.Duration
import java.time.Instant
import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.ZoneId
import java.util.Locale

internal fun parseServerInstant(value: String): Instant? = sequenceOf<() -> Instant?>(
    { runCatching { Instant.parse(value) }.getOrNull() },
    { runCatching { OffsetDateTime.parse(value).toInstant() }.getOrNull() },
    {
        runCatching {
            LocalDateTime.parse(value).atZone(ZoneId.systemDefault()).toInstant()
        }.getOrNull()
    },
).firstNotNullOfOrNull { parser -> parser() }

internal fun String.toRelativeAgeText(now: Instant = Instant.now()): String {
    val instant = parseServerInstant(this) ?: return take(10)
    val duration = Duration.between(instant, now).coerceAtLeast(Duration.ZERO)
    val minutes = duration.toMinutes()
    val hours = duration.toHours()
    val days = duration.toDays()
    val months = days / 30
    val years = days / 365
    val isUkrainian = Locale.getDefault().language == "uk"

    return when {
        minutes < 1 -> if (isUkrainian) "щойно" else "just now"
        minutes == 1L -> if (isUkrainian) "1 хв тому" else "1 min ago"
        minutes < 60 -> if (isUkrainian) "$minutes хв тому" else "$minutes min ago"
        hours == 1L -> if (isUkrainian) "1 год тому" else "1 hr ago"
        hours < 24 -> if (isUkrainian) "$hours год тому" else "$hours hr ago"
        days == 1L -> if (isUkrainian) "1 дн. тому" else "1 day ago"
        days < 30 -> if (isUkrainian) "$days дн. тому" else "$days days ago"
        months == 1L -> if (isUkrainian) "1 міс. тому" else "1 mo. ago"
        months < 12 -> if (isUkrainian) "$months міс. тому" else "$months mo. ago"
        years == 1L -> if (isUkrainian) "1 р. тому" else "1 yr. ago"
        else -> if (isUkrainian) "$years р. тому" else "$years yr. ago"
    }
}
