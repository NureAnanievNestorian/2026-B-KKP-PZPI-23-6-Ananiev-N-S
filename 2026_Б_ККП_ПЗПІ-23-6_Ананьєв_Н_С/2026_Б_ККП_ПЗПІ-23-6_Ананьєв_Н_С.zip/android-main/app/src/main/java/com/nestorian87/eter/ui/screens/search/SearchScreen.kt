package com.nestorian87.eter.ui.screens.search

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FilterList
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nestorian87.eter.R
import com.nestorian87.eter.domain.model.Post
import com.nestorian87.eter.domain.model.PostCategory
import com.nestorian87.eter.ui.app.PostPlayerViewModel
import com.nestorian87.eter.ui.components.buttons.TextAction
import com.nestorian87.eter.ui.components.dialog.EterBottomSheet
import com.nestorian87.eter.ui.components.dialog.EterSheetTitle
import com.nestorian87.eter.ui.components.forms.SearchInputField
import com.nestorian87.eter.ui.components.layout.ScreenIntroCard
import com.nestorian87.eter.ui.screens.feed.PostListScreenContent
import com.nestorian87.eter.ui.screens.feed.PostListUiState
import com.nestorian87.eter.ui.screens.feed.PostListVisualStyle
import com.nestorian87.eter.ui.theme.EditorialPanelShape
import com.nestorian87.eter.ui.theme.EterPreview
import com.nestorian87.eter.ui.theme.EterScreenPreviews
import com.nestorian87.eter.ui.theme.EterSpacing

@Composable
fun SearchScreen(
    modifier: Modifier = Modifier,
    onBack: () -> Unit = {},
    onOpenPost: (Long) -> Unit = {},
    onOpenComments: (Long) -> Unit = {},
    onOpenAuthor: (Long) -> Unit = {},
    onCategoryClick: ((Long) -> Unit)? = null,
    pendingCategoryId: Long? = null,
    onPendingCategoryConsumed: () -> Unit = {},
    viewModel: SearchViewModel = hiltViewModel(),
    playerViewModel: PostPlayerViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val playerUiState by playerViewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(pendingCategoryId) {
        if (pendingCategoryId != null) {
            viewModel.onCategorySelected(pendingCategoryId)
            onPendingCategoryConsumed()
        }
    }

    SearchScreenContent(
        uiState = uiState,
        activePlaybackPostId = playerUiState.activePost?.postId,
        isActivePostPlaying = playerUiState.isPlaying,
        modifier = modifier,
        onBack = onBack,
        onRetry = viewModel::loadInitial,
        onLoadMore = viewModel::onLoadMore,
        onToggleLike = viewModel::onToggleLike,
        onTogglePlayback = { post -> playerViewModel.togglePlayback(post) },
        onOpenPost = onOpenPost,
        onOpenComments = onOpenComments,
        onOpenAuthor = onOpenAuthor,
        onSearchQueryChanged = viewModel::onSearchQueryChanged,
        onSortSelected = viewModel::onSortSelected,
        onCategorySelected = viewModel::onCategorySelected,
        onResetSearchParameters = viewModel::onResetSearchParameters,
        onCategoryClick = onCategoryClick,
    )
}

@Composable
private fun SearchScreenContent(
    modifier: Modifier = Modifier,
    uiState: SearchUiState,
    activePlaybackPostId: Long?,
    isActivePostPlaying: Boolean,
    onBack: () -> Unit = {},
    onRetry: () -> Unit,
    onLoadMore: () -> Unit,
    onToggleLike: (Long) -> Unit,
    onTogglePlayback: (Post) -> Unit,
    onOpenPost: (Long) -> Unit,
    onOpenComments: (Long) -> Unit,
    onOpenAuthor: ((Long) -> Unit)? = null,
    onSearchQueryChanged: (String) -> Unit,
    onSortSelected: (SearchSortOption) -> Unit,
    onCategorySelected: (Long?) -> Unit,
    onResetSearchParameters: () -> Unit,
    onCategoryClick: ((Long) -> Unit)? = null,
) {
    val hasSearchCriteria = uiState.searchQuery.isNotBlank() || uiState.selectedCategoryId != null
    val selectedCategory =
        uiState.categories.firstOrNull { it.categoryId == uiState.selectedCategoryId }

    PostListScreenContent(
        title = stringResource(R.string.feed_search_title),
        listState = uiState.posts,
        activePlaybackPostId = activePlaybackPostId,
        isActivePostPlaying = isActivePostPlaying,
        emptyTitle = stringResource(R.string.feed_search_empty_title),
        emptySubtitle = stringResource(R.string.feed_search_empty_subtitle),
        subtitle = stringResource(R.string.feed_search_subtitle),
        modifier = modifier,
        visualStyle = PostListVisualStyle.Editorial,
        onBack = onBack,
        hideEmptyState = !hasSearchCriteria,
        showEmptyRetryButton = false,
        controls = {
            SearchControls(
                uiState = uiState,
                selectedCategory = selectedCategory,
                onSearchQueryChanged = onSearchQueryChanged,
                onSortSelected = onSortSelected,
                onCategorySelected = onCategorySelected,
                onResetSearchParameters = onResetSearchParameters,
            )
            if (!hasSearchCriteria) {
                ScreenIntroCard(
                    icon = Icons.Outlined.Search,
                    title = stringResource(R.string.search_prompt_title),
                    subtitle = stringResource(R.string.search_prompt_body),
                )
            }
        },
        onRetry = onRetry,
        onLoadMore = onLoadMore,
        onToggleLike = onToggleLike,
        onTogglePlayback = onTogglePlayback,
        onOpenPost = onOpenPost,
        onOpenComments = onOpenComments,
        onOpenAuthor = onOpenAuthor,
        onCategoryClick = onCategoryClick,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SearchControls(
    uiState: SearchUiState,
    selectedCategory: PostCategory?,
    onSearchQueryChanged: (String) -> Unit,
    onSortSelected: (SearchSortOption) -> Unit,
    onCategorySelected: (Long?) -> Unit,
    onResetSearchParameters: () -> Unit,
) {
    var showSearchParameters by rememberSaveable { mutableStateOf(false) }
    val hasActiveFilters =
        selectedCategory != null || uiState.selectedSort != SearchSortOption.POPULAR

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
    ) {
        SearchInputField(
            value = uiState.searchQuery,
            onValueChange = onSearchQueryChanged,
            placeholder = stringResource(R.string.feed_search_placeholder),
            trailingContent = {
                SearchParametersTrigger(
                    selectedCategory = selectedCategory,
                    selectedSort = uiState.selectedSort,
                    onClick = { showSearchParameters = true },
                )
            },
        )
        if (hasActiveFilters) {
            SearchActiveFiltersRow(
                selectedCategory = selectedCategory,
                selectedSort = uiState.selectedSort,
                onOpenFilters = { showSearchParameters = true },
                onResetSearchParameters = onResetSearchParameters,
            )
        }
    }

    if (showSearchParameters) {
        SearchParametersSheet(
            categories = uiState.categories,
            selectedCategoryId = uiState.selectedCategoryId,
            selectedSort = uiState.selectedSort,
            isLoading = uiState.isLoadingCategories,
            onDismiss = { },
            onCategorySelected = { categoryId ->
                onCategorySelected(categoryId)
            },
            onSortSelected = { sort ->
                onSortSelected(sort)
            },
            onResetSearchParameters = {
                onResetSearchParameters()
            },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SearchParametersTrigger(
    selectedCategory: PostCategory?,
    selectedSort: SearchSortOption,
    onClick: () -> Unit,
) {
    val isSelected = selectedCategory != null || selectedSort != SearchSortOption.POPULAR
    Surface(
        onClick = onClick,
        shape = MaterialTheme.shapes.medium,
        color = if (isSelected) {
            MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)
        } else {
            MaterialTheme.colorScheme.surface.copy(alpha = 0.42f)
        },
        border = BorderStroke(
            width = 0.5.dp,
            color = if (isSelected) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.72f)
            } else {
                MaterialTheme.colorScheme.outline.copy(alpha = 0.9f)
            },
        ),
    ) {
        Box(
            modifier = Modifier.padding(
                horizontal = EterSpacing.medium,
                vertical = EterSpacing.small
            ),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Outlined.FilterList,
                contentDescription = stringResource(R.string.search_parameters),
                modifier = Modifier.size(16.dp),
                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun SearchActiveFiltersRow(
    selectedCategory: PostCategory?,
    selectedSort: SearchSortOption,
    onOpenFilters: () -> Unit,
    onResetSearchParameters: () -> Unit,
) {
    FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(EterSpacing.small),
        verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
    ) {
        selectedCategory?.let { category ->
            SearchSummaryChip(
                text = stringResource(
                    R.string.search_filter_summary_category,
                    category.categoryName
                ),
                onClick = onOpenFilters,
            )
        }
        if (selectedSort != SearchSortOption.POPULAR) {
            SearchSummaryChip(
                text = stringResource(
                    R.string.search_filter_summary_sort,
                    stringResource(selectedSort.labelRes),
                ),
                onClick = onOpenFilters,
            )
        }
        TextAction(
            text = stringResource(R.string.search_reset_parameters),
            onClick = onResetSearchParameters,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SearchParametersSheet(
    categories: List<PostCategory>,
    selectedCategoryId: Long?,
    selectedSort: SearchSortOption,
    isLoading: Boolean,
    onDismiss: () -> Unit,
    onCategorySelected: (Long?) -> Unit,
    onSortSelected: (SearchSortOption) -> Unit,
    onResetSearchParameters: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var searchQuery by rememberSaveable { mutableStateOf("") }
    val filteredCategories = if (searchQuery.isBlank()) categories
    else categories.filter { it.categoryName.contains(searchQuery, ignoreCase = true) }

    EterBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.82f)
                .imePadding()
                .padding(horizontal = EterSpacing.medium)
                .padding(bottom = EterSpacing.large),
            verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                EterSheetTitle(text = stringResource(R.string.search_parameters))
                TextAction(
                    text = stringResource(R.string.search_reset_parameters),
                    onClick = onResetSearchParameters,
                )
            }
            Surface(
                shape = EditorialPanelShape,
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.18f),
                border = BorderStroke(
                    width = 1.dp,
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f),
                ),
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(EterSpacing.medium),
                    verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
                ) {
                    Text(
                        text = stringResource(R.string.feed_sort_popular),
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    SearchSortRow(
                        selectedSort = selectedSort,
                        onSortSelected = onSortSelected,
                    )
                }
            }
            Surface(
                modifier = Modifier.weight(1f),
                shape = EditorialPanelShape,
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.18f),
                border = BorderStroke(
                    width = 1.dp,
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f),
                ),
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(EterSpacing.medium),
                    verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
                ) {
                    Text(
                        text = stringResource(R.string.feed_category_filter),
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    SearchInputField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = stringResource(R.string.search),
                        placeholder = stringResource(R.string.publish_categories_search_placeholder),
                    )
                    when {
                        isLoading && categories.isEmpty() -> {
                            Text(
                                text = stringResource(R.string.feed_categories_loading),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontStyle = FontStyle.Italic,
                            )
                        }

                        else -> {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                            ) {
                                item(key = "all_categories") {
                                    SearchCategoryPickerRow(
                                        name = stringResource(R.string.feed_category_all),
                                        isSelected = selectedCategoryId == null,
                                        onClick = { onCategorySelected(null) },
                                    )
                                    HorizontalDivider(
                                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.10f),
                                    )
                                }
                                itemsIndexed(
                                    items = filteredCategories,
                                    key = { _, category -> category.categoryId },
                                ) { index, category ->
                                    SearchCategoryPickerRow(
                                        name = category.categoryName,
                                        isSelected = category.categoryId == selectedCategoryId,
                                        onClick = { onCategorySelected(category.categoryId) },
                                    )
                                    if (index != filteredCategories.lastIndex) {
                                        HorizontalDivider(
                                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.10f),
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchSummaryChip(
    text: String,
    onClick: () -> Unit,
) {
    FilterChip(
        selected = true,
        onClick = onClick,
        label = { Text(text = text) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f),
            selectedLabelColor = MaterialTheme.colorScheme.primary,
        ),
        border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = true,
            borderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.72f),
            selectedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.72f),
            disabledBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.72f),
            disabledSelectedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.72f),
            borderWidth = 0.5.dp,
            selectedBorderWidth = 0.5.dp,
        ),
    )
}

@Composable
private fun SearchCategoryPickerRow(
    name: String,
    isSelected: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = EterSpacing.medium, vertical = EterSpacing.medium),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = name,
            style = MaterialTheme.typography.titleMedium,
            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f),
        )
        if (isSelected) {
            Icon(
                imageVector = Icons.Rounded.Check,
                contentDescription = null,
                modifier = Modifier.size(20.dp),
                tint = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

@Composable
private fun SearchSortRow(
    selectedSort: SearchSortOption,
    onSortSelected: (SearchSortOption) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(EterSpacing.small),
    ) {
        SearchSortOption.entries.forEach { option ->
            SearchSelectableChip(
                text = stringResource(option.labelRes),
                selected = selectedSort == option,
                onClick = { onSortSelected(option) },
            )
        }
    }
}

@Composable
private fun SearchSelectableChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Surface(
        color = if (selected) {
            MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)
        } else {
            MaterialTheme.colorScheme.background
        },
        contentColor = if (selected) {
            MaterialTheme.colorScheme.primary
        } else {
            MaterialTheme.colorScheme.onSurface
        },
        border = BorderStroke(
            width = 1.dp,
            color = if (selected) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.72f)
            } else {
                MaterialTheme.colorScheme.outline.copy(alpha = 0.26f)
            },
        ),
        shape = MaterialTheme.shapes.small,
        onClick = onClick,
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(horizontal = EterSpacing.medium, vertical = 10.dp),
        )
    }
}

@EterScreenPreviews
@Composable
private fun SearchScreenPreview() {
    EterPreview {
        SearchScreenContent(
            uiState = SearchUiState(
                posts = PostListUiState(isInitialLoading = false),
            ),
            activePlaybackPostId = null,
            isActivePostPlaying = false,
            onRetry = {},
            onLoadMore = {},
            onToggleLike = {},
            onTogglePlayback = {},
            onOpenPost = {},
            onOpenComments = {},
            onSearchQueryChanged = {},
            onSortSelected = {},
            onCategorySelected = {},
            onResetSearchParameters = {},
        )
    }
}
