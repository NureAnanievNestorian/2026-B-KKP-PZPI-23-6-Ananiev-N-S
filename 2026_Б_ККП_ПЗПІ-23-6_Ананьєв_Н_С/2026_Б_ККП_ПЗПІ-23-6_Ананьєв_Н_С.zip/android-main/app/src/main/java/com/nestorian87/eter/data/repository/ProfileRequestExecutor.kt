package com.nestorian87.eter.data.repository

import com.nestorian87.eter.domain.model.ProfileException
import retrofit2.HttpException
import java.io.IOException

suspend inline fun <T> executeProfileRequest(
    crossinline httpErrorMapper: (error: HttpException) -> Throwable = {
        ProfileException(
            reasons = setOf(ProfileException.Reason.UNKNOWN),
            cause = it,
        )
    },
    crossinline block: suspend () -> T,
): T {
    try {
        return block()
    } catch (error: IOException) {
        throw ProfileException(
            reasons = setOf(ProfileException.Reason.NETWORK),
            cause = error,
        )
    } catch (error: HttpException) {
        throw httpErrorMapper(error)
    }
}
