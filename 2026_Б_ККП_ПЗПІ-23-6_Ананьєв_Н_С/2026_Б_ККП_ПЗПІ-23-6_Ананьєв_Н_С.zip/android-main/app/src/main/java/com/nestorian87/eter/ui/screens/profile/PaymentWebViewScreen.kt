package com.nestorian87.eter.ui.screens.profile

import android.content.ActivityNotFoundException
import android.content.Intent
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.net.toUri
import com.nestorian87.eter.R
import com.nestorian87.eter.ui.components.buttons.BackIconButton
import com.nestorian87.eter.ui.theme.EterPreview
import com.nestorian87.eter.ui.theme.EterScreenPreviews
import java.net.URI

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentWebViewScreen(
    modifier: Modifier = Modifier,
    url: String,
    callbackUrlPrefix: String = "",
    onBack: () -> Unit = {},
    onCallbackUrlIntercepted: (url: String) -> Unit = {},
) {
    val allowedHosts = remember(url, callbackUrlPrefix) {
        buildSet {
            parseAllowedHost(url)?.let(::add)
            parseAllowedHost(callbackUrlPrefix)?.let(::add)
        }
    }
    PaymentWebViewScaffold(
        modifier = modifier,
        onBack = onBack,
    ) { innerPadding ->
        AndroidView(
            factory = { context ->
                WebView(context).apply {
                    if (allowedHosts.isNotEmpty()) {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                    }
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(
                            view: WebView,
                            request: WebResourceRequest,
                        ): Boolean {
                            val requestUri = request.url
                            val requestUrl = requestUri.toString()
                            if (callbackUrlPrefix.isNotEmpty() && requestUrl.startsWith(
                                    callbackUrlPrefix
                                )
                            ) {
                                onCallbackUrlIntercepted(requestUrl)
                                onBack()
                                return true
                            }
                            val scheme = requestUri.scheme
                            if (scheme != "http" && scheme != "https") {
                                try {
                                    view.context.startActivity(
                                        Intent(Intent.ACTION_VIEW, requestUrl.toUri()),
                                    )
                                } catch (_: ActivityNotFoundException) {
                                }
                                return true
                            }
                            return !isAllowedPaymentHost(requestUrl, allowedHosts)
                        }
                    }
                    if (isAllowedPaymentHost(url, allowedHosts)) {
                        loadUrl(url)
                    }
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            update = { webView ->
                if (webView.url != url && isAllowedPaymentHost(url, allowedHosts)) {
                    webView.loadUrl(url)
                }
            },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PaymentWebViewScaffold(
    modifier: Modifier = Modifier,
    onBack: () -> Unit,
    content: @Composable (PaddingValues) -> Unit,
) {
    Scaffold(
        modifier = modifier,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(text = stringResource(R.string.payment_webview_title))
                },
                navigationIcon = {
                    BackIconButton(onClick = onBack)
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground,
                ),
            )
        },
    ) { innerPadding ->
        content(innerPadding)
    }
}

private fun parseAllowedHost(url: String): String? = runCatching {
    URI(url).host?.lowercase()
}.getOrNull()

private fun isAllowedPaymentHost(
    url: String,
    allowedHosts: Set<String>,
): Boolean {
    val host = parseAllowedHost(url) ?: return false
    return host in allowedHosts
}

@EterScreenPreviews
@Composable
private fun PaymentWebViewScreenPreview() {
    EterPreview {
        PaymentWebViewScaffold(
            onBack = {},
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(Color(0xFFEDE7DA)),
            )
        }
    }
}
