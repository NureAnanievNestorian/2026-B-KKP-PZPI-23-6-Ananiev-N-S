package com.nestorian87.eter.ui.screens.profile

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.net.toUri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nestorian87.eter.R
import com.nestorian87.eter.domain.model.ActiveViolation
import com.nestorian87.eter.domain.model.AuthUser
import com.nestorian87.eter.domain.model.FieldViolation
import com.nestorian87.eter.domain.model.FollowProfilesQuery
import com.nestorian87.eter.domain.model.MyPostsQuery
import com.nestorian87.eter.domain.model.MyPostsSortBy
import com.nestorian87.eter.domain.model.OwnProfile
import com.nestorian87.eter.domain.model.Post
import com.nestorian87.eter.domain.model.PostStatus
import com.nestorian87.eter.domain.model.ProfileException
import com.nestorian87.eter.domain.model.ProfileFollowListItem
import com.nestorian87.eter.domain.model.ProfilePostsAuthorType
import com.nestorian87.eter.domain.model.ProfilePostsQuery
import com.nestorian87.eter.domain.model.ProfilePostsSortBy
import com.nestorian87.eter.domain.model.PublicProfile
import com.nestorian87.eter.domain.model.ServerValidationException
import com.nestorian87.eter.domain.model.SortOrder
import com.nestorian87.eter.domain.model.UpdateProfilePayload
import com.nestorian87.eter.domain.model.ViolationStatus
import com.nestorian87.eter.domain.repository.AuthRepository
import com.nestorian87.eter.domain.repository.PostInteractionStore
import com.nestorian87.eter.domain.repository.PostLikeController
import com.nestorian87.eter.domain.repository.PostRepository
import com.nestorian87.eter.domain.repository.ProfileRepository
import com.nestorian87.eter.domain.util.ProfileAvatarUpload
import com.nestorian87.eter.ui.components.layout.PostCardUiModel
import com.nestorian87.eter.ui.navigation.EterDeepLink
import com.nestorian87.eter.ui.screens.feed.PostListUiState
import dagger.assisted.Assisted
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.net.InetAddress
import java.net.URI
import java.time.Instant
import java.time.temporal.ChronoUnit
import kotlin.math.ceil

@HiltViewModel(assistedFactory = ProfileViewModel.Factory::class)
class ProfileViewModel @AssistedInject constructor(
    @Assisted private val profileUserId: Long?,
    @Assisted private val profileUsername: String?,
    private val authRepository: AuthRepository,
    private val profileRepository: ProfileRepository,
    private val postRepository: PostRepository,
    private val postInteractionStore: PostInteractionStore,
    private val postLikeController: PostLikeController,
    @param:ApplicationContext private val context: Context,
) : ViewModel() {
    private val _uiState = MutableStateFlow(ProfileUiState())
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

    private val effectChannel = Channel<ProfileEffect>(capacity = Channel.BUFFERED)
    val effects = effectChannel.receiveAsFlow()

    private var publishedLoadJob: Job? = null
    private var draftsLoadJob: Job? = null
    private var followLoadJob: Job? = null
    private var followSearchJob: Job? = null
    private var processingPollingJob: Job? = null
    private var sourcePublished: List<Post> = emptyList()
    private var sourceDrafts: List<Post> = emptyList()
    private var publishedOffset = 0
    private var draftsOffset = 0
    private var hasLoadedDrafts = false
    private var isScreenVisible = true
    private var cachedComplaintReasonLabels: Map<String, String> = emptyMap()

    init {
        observeSession()
        observePostInteractions()
        loadProfile()
    }

    fun onRetryProfile() {
        loadProfile()
    }

    fun onScreenVisibilityChanged(isVisible: Boolean) {
        isScreenVisible = isVisible
        updateDraftsPolling()
    }

    fun onTabSelected(tab: ProfileTab) {
        if (_uiState.value.selectedTab == tab) {
            return
        }
        if (tab == ProfileTab.DRAFTS && !_uiState.value.isOwner) {
            return
        }

        _uiState.update { it.copy(selectedTab = tab) }

        if (tab == ProfileTab.DRAFTS) {
            if (!hasLoadedDrafts) {
                loadDraftsInitial()
            } else {
                updateDraftsPolling()
            }
        } else {
            stopDraftsPolling()
        }
    }

    fun applyPublishedFilters(
        authorType: ProfilePostsAuthorType,
        sortBy: ProfilePostsSortBy,
        sortOrder: SortOrder,
    ) {
        val currentState = _uiState.value
        if (
            currentState.publishedAuthorType == authorType &&
            currentState.publishedSortBy == sortBy &&
            currentState.publishedSortOrder == sortOrder
        ) {
            return
        }

        _uiState.update {
            it.copy(
                publishedAuthorType = authorType,
                publishedSortBy = sortBy,
                publishedSortOrder = sortOrder,
            )
        }
        loadPublishedInitial()
    }

    fun onShareProfileClick() {
        val username = _uiState.value.username.takeIf { it.isNotBlank() } ?: return
        viewModelScope.launch {
            effectChannel.send(
                ProfileEffect.ShareProfile(
                    url = EterDeepLink.profileWebUri(username).toString(),
                ),
            )
        }
    }

    fun loadPublishedInitial() {
        publishedLoadJob?.cancel()
        sourcePublished = emptyList()
        publishedOffset = 0
        _uiState.update {
            it.copy(
                published = PostListUiState(
                    isInitialLoading = true,
                ),
            )
        }
        loadPublishedPage(reset = true)
    }

    fun onLoadMorePublished() {
        val state = _uiState.value.published
        if (state.isInitialLoading || state.isLoadingMore || !state.canLoadMore) {
            return
        }
        _uiState.update {
            it.copy(
                published = it.published.copy(
                    isLoadingMore = true,
                    error = null,
                ),
            )
        }
        loadPublishedPage(reset = false)
    }

    fun loadDraftsInitial() {
        if (!_uiState.value.isOwner) {
            return
        }
        draftsLoadJob?.cancel()
        stopDraftsPolling()
        sourceDrafts = emptyList()
        draftsOffset = 0
        hasLoadedDrafts = true
        _uiState.update {
            it.copy(
                drafts = PostListUiState(
                    isInitialLoading = true,
                ),
            )
        }
        loadDraftsPage(reset = true)
    }

    fun onLoadMoreDrafts() {
        val state = _uiState.value.drafts
        if (state.isInitialLoading || state.isLoadingMore || !state.canLoadMore) {
            return
        }

        _uiState.update {
            it.copy(
                drafts = it.drafts.copy(
                    isLoadingMore = true,
                    error = null,
                ),
            )
        }
        loadDraftsPage(reset = false)
    }

    fun onToggleLike(postId: Long) {
        val post = (_uiState.value.published.items + _uiState.value.drafts.items)
            .firstOrNull { it.post.postId == postId }
            ?.post
            ?: return
        postLikeController.toggleLike(post)
    }

    fun onToggleHeroFollow() {
        val state = _uiState.value
        val userId = state.profileUserId ?: return
        if (state.isOwner) {
            return
        }
        if (!state.isAuthenticated) {
            viewModelScope.launch {
                effectChannel.send(ProfileEffect.NavigateToLogin)
            }
            return
        }
        if (state.isFollowActionLoading) {
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isFollowActionLoading = true) }
            runCatching {
                if (state.isFollowing) {
                    profileRepository.unfollowProfile(userId)
                } else {
                    profileRepository.followProfile(userId)
                }
            }.onSuccess { profile ->
                applyPublicProfile(profile)
                _uiState.update { it.copy(isFollowActionLoading = false) }
            }.onFailure {
                _uiState.update { it.copy(isFollowActionLoading = false) }
            }
        }
    }

    fun onOpenFollowDialog(type: ProfileFollowListType) {
        _uiState.update {
            it.copy(
                isFollowDialogVisible = true,
                followDialog = ProfileFollowDialogUiState(
                    type = type,
                    isInitialLoading = true,
                ),
            )
        }
        loadFollowPage(reset = true)
    }

    fun onFollowDialogSearchChanged(value: String) {
        _uiState.update {
            it.copy(
                followDialog = it.followDialog.copy(
                    searchQuery = value,
                ),
            )
        }
        followSearchJob?.cancel()
        followSearchJob = viewModelScope.launch {
            delay(FOLLOW_SEARCH_DEBOUNCE_MS)
            _uiState.update {
                it.copy(
                    followDialog = it.followDialog.copy(
                        isInitialLoading = true,
                        error = null,
                    ),
                )
            }
            loadFollowPage(reset = true)
        }
    }

    fun onLoadMoreFollowItems() {
        val state = _uiState.value.followDialog
        if (state.isInitialLoading || state.isLoadingMore || !state.hasMore) {
            return
        }
        _uiState.update {
            it.copy(
                followDialog = it.followDialog.copy(
                    isLoadingMore = true,
                    error = null,
                ),
            )
        }
        loadFollowPage(reset = false)
    }

    fun onToggleFollowDialogItem(userId: Long) {
        val state = _uiState.value
        val item = state.followDialog.items.firstOrNull { it.userId == userId } ?: return
        if (!state.isAuthenticated) {
            viewModelScope.launch {
                effectChannel.send(ProfileEffect.NavigateToLogin)
            }
            return
        }
        if (state.followDialog.pendingUserIds.contains(userId)) {
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    followDialog = it.followDialog.copy(
                        pendingUserIds = it.followDialog.pendingUserIds + userId,
                    ),
                )
            }
            runCatching {
                if (item.isSubscribed) {
                    profileRepository.unfollowProfile(userId)
                } else {
                    profileRepository.followProfile(userId)
                }
            }.onSuccess { updatedProfile ->
                _uiState.update { current ->
                    current.copy(
                        followDialog = current.followDialog.copy(
                            items = current.followDialog.items.map { existing ->
                                if (existing.userId == userId) {
                                    existing.copy(isSubscribed = updatedProfile.isSubscribed)
                                } else {
                                    existing
                                }
                            },
                            pendingUserIds = current.followDialog.pendingUserIds - userId,
                        ),
                    )
                }
                if (_uiState.value.profileUserId == userId) {
                    applyPublicProfile(updatedProfile)
                }
            }.onFailure {
                _uiState.update { current ->
                    current.copy(
                        followDialog = current.followDialog.copy(
                            pendingUserIds = current.followDialog.pendingUserIds - userId,
                        ),
                    )
                }
            }
        }
    }

    fun onEditProfileClick() {
        val state = _uiState.value
        if (!state.isOwner) {
            return
        }
        _uiState.update {
            it.copy(
                isEditDialogVisible = true,
                editDialog = EditProfileDialogUiState(
                    name = state.name,
                    username = state.username,
                    bio = state.bio.orEmpty(),
                    link = state.link.orEmpty(),
                    currentAvatarUrl = state.photo,
                ),
            )
        }
    }

    fun onEditNameChanged(value: String) {
        updateEditDialog { it.copy(name = value, nameErrorResId = null, formErrorResId = null) }
    }

    fun onEditUsernameChanged(value: String) {
        updateEditDialog {
            it.copy(
                username = value,
                usernameErrorResId = null,
                formErrorResId = null
            )
        }
    }

    fun onEditBioChanged(value: String) {
        updateEditDialog { it.copy(bio = value, formErrorResId = null) }
    }

    fun onEditLinkChanged(value: String) {
        updateEditDialog { it.copy(link = value, linkErrorResId = null, formErrorResId = null) }
    }

    fun onRemoveAvatarClick() {
        updateEditDialog {
            it.copy(
                selectedAvatarUri = null,
                removeAvatar = true,
                avatarErrorResId = null,
                formErrorResId = null,
            )
        }
    }

    fun onAvatarSelected(uri: Uri?) {
        if (uri == null) {
            return
        }
        val size = context.contentResolver.openFileDescriptor(uri, "r")?.use { descriptor ->
            descriptor.statSize
        } ?: -1L

        if (size > MAX_AVATAR_SIZE_BYTES) {
            updateEditDialog {
                it.copy(
                    avatarErrorResId = R.string.profile_edit_avatar_too_large_error,
                    formErrorResId = null,
                )
            }
            return
        }

        updateEditDialog {
            it.copy(
                selectedAvatarUri = uri.toString(),
                removeAvatar = false,
                avatarErrorResId = null,
                formErrorResId = null,
            )
        }
    }

    fun onSaveProfileChanges() {
        val dialog = _uiState.value.editDialog
        val trimmedName = dialog.name.trim()
        val trimmedUsername = dialog.username.trim()
        val trimmedLink = dialog.link.trim().takeIf { it.isNotEmpty() }

        val nameError = if (trimmedName.isBlank()) R.string.profile_edit_name_required else null
        val usernameError =
            if (trimmedUsername.isBlank()) R.string.profile_edit_username_required else null
        val linkError = if (trimmedLink != null && !isSafeProfileLink(trimmedLink)) {
            R.string.profile_edit_link_invalid
        } else {
            null
        }

        if (nameError != null || usernameError != null || linkError != null) {
            updateEditDialog {
                it.copy(
                    nameErrorResId = nameError,
                    usernameErrorResId = usernameError,
                    linkErrorResId = linkError,
                )
            }
            return
        }

        viewModelScope.launch {
            updateEditDialog {
                it.copy(
                    isSaving = true,
                    formErrorResId = null,
                    avatarErrorResId = null,
                )
            }
            runCatching {
                var updatedProfile = profileRepository.updateMyProfile(
                    payload = UpdateProfilePayload(
                        name = trimmedName,
                        username = trimmedUsername,
                        bio = dialog.bio.trim().takeIf { it.isNotEmpty() },
                        link = trimmedLink,
                    ),
                )

                dialog.selectedAvatarUri?.let { avatarUri ->
                    val tempFile = createTempFileFromUri(avatarUri.toUri())
                    try {
                        updatedProfile = profileRepository.updateMyAvatar(tempFile)
                    } finally {
                        tempFile.delete()
                    }
                }

                if (dialog.removeAvatar && dialog.currentAvatarUrl != null) {
                    updatedProfile = profileRepository.removeMyAvatar()
                }

                authRepository.refreshCurrentUser()
                updatedProfile
            }.onSuccess { updatedProfile ->
                applyOwnProfile(updatedProfile)
                _uiState.update { it.copy(isEditDialogVisible = false) }
                effectChannel.send(ProfileEffect.ProfileSaved)
            }.onFailure { error ->
                applyEditProfileError(error)
            }
        }
    }

    fun onOpenViolationsDialog() {
        if (!_uiState.value.isOwner) {
            return
        }
        _uiState.update {
            it.copy(
                isViolationsDialogVisible = true,
                violationsDialog = ProfileViolationsDialogUiState(isLoading = true),
            )
        }
        viewModelScope.launch {
            runCatching {
                if (cachedComplaintReasonLabels.isEmpty()) {
                    cachedComplaintReasonLabels = postRepository.getComplaintReasons()
                        .associate { it.key to it.label }
                }
                profileRepository.getMyViolations()
            }.onSuccess { violations ->
                _uiState.update {
                    it.copy(
                        violationsDialog = ProfileViolationsDialogUiState(
                            isLoading = false,
                            items = violations.map(::toViolationUiState),
                        ),
                    )
                }
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        violationsDialog = ProfileViolationsDialogUiState(
                            isLoading = false,
                            error = error,
                        ),
                    )
                }
            }
        }
    }

    fun onDismissViolationsDialog() {
        _uiState.update { it.copy(isViolationsDialogVisible = false) }
    }

    fun onLogoutClick() {
        if (_uiState.value.isLoggingOut) {
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoggingOut = true) }
            authRepository.logout()
            _uiState.update { it.copy(isLoggingOut = false) }
        }
    }

    fun stopDraftsPolling() {
        processingPollingJob?.cancel()
        processingPollingJob = null
    }

    private fun observeSession() {
        viewModelScope.launch {
            authRepository.session.collectLatest { session ->
                _uiState.update { current ->
                    val authenticatedState = current.copy(
                        isAuthenticated = session != null,
                    )
                    if (session != null && authenticatedState.isOwner) {
                        authenticatedState.withOwnerSessionUser(session.user)
                    } else {
                        authenticatedState
                    }
                }
            }
        }
    }

    private fun observePostInteractions() {
        viewModelScope.launch {
            postInteractionStore.overrides.collect { overrides ->
                _uiState.update { current ->
                    current.copy(
                        published = current.published.copy(
                            items = mapPostUiItems(sourcePublished),
                            pendingLikePostIds = overrides
                                .filterValues { it.isLikePending }
                                .keys,
                        ),
                        drafts = current.drafts.copy(
                            items = mapDraftUiItems(sourceDrafts),
                            pendingLikePostIds = overrides
                                .filterValues { it.isLikePending }
                                .keys,
                        ),
                    )
                }
            }
        }
    }

    private fun loadProfile() {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isLoadingProfile = true,
                    profileLoadError = null,
                )
            }

            if (isOwnerRoute() && authRepository.session.value == null) {
                effectChannel.send(ProfileEffect.NavigateToLogin)
                _uiState.update {
                    it.copy(
                        isLoadingProfile = false,
                    )
                }
                return@launch
            }

            runCatching {
                if (isOwnerRoute()) {
                    profileRepository.getMyProfile()
                } else if (profileUserId != null) {
                    profileRepository.getPublicProfile(profileUserId)
                } else {
                    profileRepository.getPublicProfile(requireNotNull(sanitizedProfileUsername()))
                }
            }.onSuccess { profile ->
                when (profile) {
                    is OwnProfile -> applyOwnProfile(profile)
                    is PublicProfile -> applyPublicProfile(profile)
                }
                loadPublishedInitial()
                if (_uiState.value.isOwner && _uiState.value.selectedTab == ProfileTab.DRAFTS) {
                    loadDraftsInitial()
                }
            }.onFailure { error ->
                if (error is CancellationException) {
                    throw error
                }
                _uiState.update {
                    it.copy(
                        isLoadingProfile = false,
                        profileLoadError = error,
                    )
                }
            }
        }
    }

    private fun loadPublishedPage(reset: Boolean) {
        val state = _uiState.value
        val userId = state.profileUserId
        val username = state.username.takeIf { !state.isOwner && it.isNotBlank() }
        if (userId == null && username == null) {
            return
        }

        publishedLoadJob = viewModelScope.launch {
            runCatching {
                val query = ProfilePostsQuery(
                    sortBy = state.publishedSortBy,
                    sortOrder = state.publishedSortOrder,
                    authorType = state.publishedAuthorType,
                    offset = if (reset) 0 else publishedOffset,
                    limit = PAGE_SIZE,
                )
                when {
                    !username.isNullOrBlank() && profileUserId == null ->
                        postRepository.getProfilePostsByUsername(username = username, query = query)

                    else -> postRepository.getProfilePosts(
                        userId = requireNotNull(userId),
                        query = query
                    )
                }
            }.onSuccess { page ->
                val mergedItems = if (reset) page.items else sourcePublished + page.items
                sourcePublished = mergedItems.distinctBy(Post::postId)
                publishedOffset = page.offset + page.items.size
                _uiState.update {
                    it.copy(
                        published = it.published.copy(
                            items = mapPostUiItems(sourcePublished),
                            isInitialLoading = false,
                            isLoadingMore = false,
                            canLoadMore = sourcePublished.size < page.total,
                            error = null,
                        ),
                    )
                }
            }.onFailure { error ->
                if (error is CancellationException) {
                    throw error
                }
                _uiState.update {
                    it.copy(
                        published = it.published.copy(
                            isInitialLoading = false,
                            isLoadingMore = false,
                            error = error,
                        ),
                    )
                }
            }
        }
    }

    private fun loadDraftsPage(reset: Boolean) {
        draftsLoadJob = viewModelScope.launch {
            runCatching {
                postRepository.getMyPosts(
                    query = MyPostsQuery(
                        statuses = DRAFT_STATUSES,
                        sortBy = MyPostsSortBy.UPDATED_AT,
                        sortOrder = SortOrder.DESC,
                        offset = if (reset) 0 else draftsOffset,
                        limit = PAGE_SIZE,
                    ),
                )
            }.onSuccess { page ->
                val mergedItems = if (reset) {
                    page.items
                } else {
                    sourceDrafts + page.items
                }
                sourceDrafts = mergedItems.distinctBy(Post::postId)
                draftsOffset = page.offset + page.items.size

                _uiState.update {
                    it.copy(
                        drafts = it.drafts.copy(
                            items = mapDraftUiItems(sourceDrafts),
                            isInitialLoading = false,
                            isLoadingMore = false,
                            canLoadMore = sourceDrafts.size < page.total,
                            error = null,
                        ),
                    )
                }

                updateDraftsPolling()
            }.onFailure { error ->
                if (error is CancellationException) {
                    throw error
                }
                _uiState.update {
                    it.copy(
                        drafts = it.drafts.copy(
                            isInitialLoading = false,
                            isLoadingMore = false,
                            error = error,
                        ),
                    )
                }
                updateDraftsPolling()
            }
        }
    }

    private fun loadFollowPage(reset: Boolean) {
        val profileId = _uiState.value.profileUserId ?: profileUserId
        val isOwnFollowList = _uiState.value.isOwner || isCurrentUserProfile(profileId)
        followLoadJob?.cancel()
        followLoadJob = viewModelScope.launch {
            val dialogState = _uiState.value.followDialog
            runCatching {
                val query = FollowProfilesQuery(
                    search = dialogState.searchQuery.trim().takeIf { it.isNotEmpty() },
                    cursor = if (reset) null else dialogState.nextCursor,
                    limit = FOLLOW_PAGE_SIZE,
                )
                when {
                    isOwnFollowList && dialogState.type == ProfileFollowListType.FOLLOWERS ->
                        profileRepository.getMyFollowers(query)

                    isOwnFollowList && dialogState.type == ProfileFollowListType.FOLLOWING ->
                        profileRepository.getMyFollowing(query)

                    dialogState.type == ProfileFollowListType.FOLLOWERS ->
                        profileRepository.getFollowers(requireNotNull(profileId), query)

                    else -> profileRepository.getFollowing(requireNotNull(profileId), query)
                }
            }.onSuccess { page ->
                val items = if (reset) {
                    page.items
                } else {
                    (_uiState.value.followDialog.items + page.items).distinctBy(
                        ProfileFollowListItem::userId
                    )
                }
                _uiState.update {
                    it.copy(
                        followDialog = it.followDialog.copy(
                            items = items,
                            total = page.total,
                            nextCursor = page.nextCursor,
                            hasMore = page.hasMore,
                            isInitialLoading = false,
                            isLoadingMore = false,
                            error = null,
                        ),
                    )
                }
            }.onFailure { error ->
                if (error is CancellationException) {
                    throw error
                }
                _uiState.update {
                    it.copy(
                        followDialog = it.followDialog.copy(
                            isInitialLoading = false,
                            isLoadingMore = false,
                            error = error,
                        ),
                    )
                }
            }
        }
    }

    private fun updateDraftsPolling() {
        if (!shouldPollDrafts()) {
            stopDraftsPolling()
            return
        }
        if (processingPollingJob?.isActive == true) {
            return
        }

        processingPollingJob = viewModelScope.launch {
            while (isActive) {
                delay(if (isScreenVisible) VISIBLE_DRAFT_POLL_MS else HIDDEN_DRAFT_POLL_MS)

                if (!shouldPollDrafts()) {
                    stopDraftsPolling()
                    return@launch
                }

                val refreshedPage = runCatching {
                    postRepository.getMyPosts(
                        query = MyPostsQuery(
                            statuses = DRAFT_STATUSES,
                            sortBy = MyPostsSortBy.UPDATED_AT,
                            sortOrder = SortOrder.DESC,
                            offset = 0,
                            limit = sourceDrafts.size.coerceAtLeast(PAGE_SIZE),
                        ),
                    )
                }.getOrNull()

                if (refreshedPage != null) {
                    sourceDrafts = refreshedPage.items.distinctBy(Post::postId)
                    draftsOffset = refreshedPage.offset + refreshedPage.items.size
                    _uiState.update {
                        it.copy(
                            drafts = it.drafts.copy(
                                items = mapDraftUiItems(sourceDrafts),
                                canLoadMore = sourceDrafts.size < refreshedPage.total,
                            ),
                        )
                    }

                    if (sourceDrafts.none { it.status == PostStatus.PROCESSING }) {
                        stopDraftsPolling()
                        return@launch
                    }
                }
            }
        }
    }

    private fun shouldPollDrafts(): Boolean = _uiState.value.isOwner &&
            _uiState.value.selectedTab == ProfileTab.DRAFTS &&
            sourceDrafts.any { it.status == PostStatus.PROCESSING }

    private fun applyOwnProfile(profile: OwnProfile) {
        _uiState.update {
            it.copy(
                isLoadingProfile = false,
                profileLoadError = null,
                profileUserId = profile.userId,
                name = profile.name,
                username = profile.username,
                email = profile.email,
                photo = profile.photo,
                bio = profile.bio,
                link = profile.link,
                isPremium = profile.isPremium,
                isOwner = true,
                isFollowing = false,
                postsCount = profile.postsCount,
                followersCount = profile.followersCount,
                followingCount = profile.followingCount,
                currentViolationsCount = profile.currentViolationsCount,
                maxViolationsBeforeBlock = profile.maxViolationsBeforeBlock,
            )
        }
    }

    private fun ProfileUiState.withOwnerSessionUser(user: AuthUser): ProfileUiState = copy(
        profileUserId = user.userId,
        name = user.name,
        username = user.username,
        email = user.email,
        photo = user.photo,
    )

    private fun applyPublicProfile(profile: PublicProfile) {
        _uiState.update {
            it.copy(
                isLoadingProfile = false,
                profileLoadError = null,
                profileUserId = profile.userId,
                name = profile.name,
                username = profile.username,
                email = "",
                photo = profile.photo,
                bio = profile.bio,
                link = profile.link,
                isPremium = profile.isPremium,
                isOwner = false,
                isFollowing = profile.isSubscribed,
                postsCount = profile.postsCount,
                followersCount = profile.followersCount,
                followingCount = profile.followingCount,
                currentViolationsCount = 0,
                maxViolationsBeforeBlock = 0,
                selectedTab = ProfileTab.PUBLISHED,
            )
        }
    }

    private fun mapPostUiItems(posts: List<Post>): List<PostCardUiModel> = posts.map { post ->
        postInteractionStore.ensureLikeBase(post)
        val merged = postInteractionStore.apply(post)
        PostCardUiModel(
            post = merged,
            isLiked = merged.isLiked,
        )
    }

    private fun mapDraftUiItems(posts: List<Post>): List<PostCardUiModel> = posts.map { post ->
        postInteractionStore.ensureLikeBase(post)
        val merged = postInteractionStore.apply(post)
        PostCardUiModel(
            post = merged,
            isLiked = merged.isLiked,
            statusLabelResId = if (merged.status == PostStatus.PROCESSING) {
                R.string.profile_drafts_processing_badge
            } else {
                null
            },
        )
    }

    private fun updateEditDialog(transform: (EditProfileDialogUiState) -> EditProfileDialogUiState) {
        _uiState.update {
            it.copy(editDialog = transform(it.editDialog))
        }
    }

    private fun applyEditProfileError(error: Throwable) {
        val validationError = error as? ServerValidationException
        val fieldViolations = validationError?.fieldViolations.orEmpty()
        updateEditDialog {
            it.copy(
                isSaving = false,
                usernameErrorResId = fieldViolations.toFieldErrorMessage(
                    field = USERNAME_FIELD,
                    code = USERNAME_NOT_UNIQUE_CODE,
                    resId = R.string.profile_edit_username_conflict,
                ),
                formErrorResId = if (
                    fieldViolations.any { violation ->
                        violation.field == USERNAME_FIELD && violation.code == USERNAME_NOT_UNIQUE_CODE
                    }
                ) {
                    null
                } else {
                    error.toProfileMessageResId()
                },
            )
        }
    }

    private fun Set<FieldViolation>.toFieldErrorMessage(
        field: String,
        code: String,
        resId: Int,
    ): Int? {
        val hasViolation = any { violation ->
            violation.field == field && violation.code == code
        }
        return if (hasViolation) resId else null
    }

    private fun toViolationUiState(violation: ActiveViolation): ProfileViolationUiState {
        val reasonLabel =
            cachedComplaintReasonLabels[violation.complaintReason] ?: violation.complaintReason
        val postTitle = violation.targetPost.title
            ?.takeIf { it.isNotBlank() }
            ?: context.getString(R.string.post_untitled)
        return ProfileViolationUiState(
            complaintId = violation.complaintId,
            reasonLabel = reasonLabel,
            statusLabel = violation.status.toUiLabel(),
            postTitle = postTitle,
            expiresAt = violation.expiresAt,
            daysRemaining = violation.expiresAt?.toDaysRemaining(),
        )
    }

    private fun createTempFileFromUri(uri: Uri): File {
        val inputStream = requireNotNull(context.contentResolver.openInputStream(uri))
        val fileSuffix = ProfileAvatarUpload.resolveFileSuffix(
            contentType = context.contentResolver.getType(uri),
            displayName = context.queryDisplayName(uri),
        )
        val fileName = "profile-avatar-${System.currentTimeMillis()}$fileSuffix"
        val tempFile = File(context.cacheDir, fileName)
        inputStream.use { input ->
            tempFile.outputStream().use { output ->
                input.copyTo(output)
            }
        }
        return tempFile
    }

    private fun Context.queryDisplayName(uri: Uri): String? = contentResolver.query(
        uri,
        arrayOf(OpenableColumns.DISPLAY_NAME),
        null,
        null,
        null,
    )?.use { cursor ->
        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (nameIndex == -1 || !cursor.moveToFirst()) {
            null
        } else {
            cursor.getString(nameIndex)
        }
    }

    private fun sanitizedProfileUsername(): String? = profileUsername
        ?.trim()
        ?.removePrefix("@")
        ?.takeIf { it.isNotBlank() }

    private fun isCurrentUserProfile(userId: Long?): Boolean = userId != null &&
            authRepository.session.value?.user?.userId == userId

    private fun isOwnerRoute(): Boolean =
        profileUserId == null && sanitizedProfileUsername() == null

    private fun String.toDaysRemaining(): Long? = runCatching {
        val expiresAtInstant = Instant.parse(this)
        val now = Instant.now()
        if (expiresAtInstant.isBefore(now)) {
            0L
        } else {
            ceil(
                now.until(
                    expiresAtInstant,
                    ChronoUnit.MINUTES
                ) / MINUTES_PER_DAY.toDouble()
            ).toLong()
        }
    }.getOrNull()

    private fun ViolationStatus.toUiLabel(): String = when (this) {
        ViolationStatus.PENDING -> context.getString(R.string.profile_violations_status_pending)
        ViolationStatus.RESOLVED -> context.getString(R.string.profile_violations_status_resolved)
        ViolationStatus.DISMISSED -> context.getString(R.string.profile_violations_status_dismissed)
        ViolationStatus.UNKNOWN -> context.getString(R.string.profile_violations_status_unknown)
    }

    private fun Throwable.toProfileMessageResId(): Int = when (this) {
        is ProfileException -> when (primaryReason) {
            ProfileException.Reason.NETWORK -> R.string.profile_error_network
            ProfileException.Reason.UNAUTHORIZED -> R.string.profile_error_unauthorized
            ProfileException.Reason.USER_NOT_FOUND -> R.string.profile_error_not_found
            else -> R.string.profile_error_generic
        }

        is ServerValidationException -> R.string.profile_error_invalid_data
        else -> R.string.profile_error_generic
    }

    private fun isSafeProfileLink(link: String): Boolean = runCatching {
        val uri = URI(link)
        if (!uri.scheme.equals("https", ignoreCase = true)) {
            return false
        }
        val host = uri.host?.lowercase() ?: return false
        if (host == "localhost" || host.endsWith(".local")) {
            return false
        }
        val address = InetAddress.getByName(host)
        !address.isAnyLocalAddress &&
                !address.isLoopbackAddress &&
                !address.isLinkLocalAddress &&
                !address.isSiteLocalAddress
    }.getOrDefault(false)

    @AssistedFactory
    interface Factory {
        fun create(
            profileUserId: Long?,
            profileUsername: String?,
        ): ProfileViewModel
    }

    private companion object {
        val DRAFT_STATUSES = linkedSetOf(
            PostStatus.DRAFT,
            PostStatus.PROCESSING,
        )

        const val PAGE_SIZE = 12
        const val FOLLOW_PAGE_SIZE = 20
        const val FOLLOW_SEARCH_DEBOUNCE_MS = 300L
        const val VISIBLE_DRAFT_POLL_MS = 5_000L
        const val HIDDEN_DRAFT_POLL_MS = 30_000L
        const val MAX_AVATAR_SIZE_BYTES = 5L * 1024L * 1024L
        const val USERNAME_FIELD = "username"
        const val USERNAME_NOT_UNIQUE_CODE = "USERNAME_NOT_UNIQUE"
        const val MINUTES_PER_DAY = 1_440
    }
}
