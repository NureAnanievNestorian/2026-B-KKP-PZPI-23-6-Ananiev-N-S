package com.nestorian87.eter.data.mapper

import com.nestorian87.eter.data.remote.dto.ListenEndResponseDto
import com.nestorian87.eter.data.remote.dto.ListenProgressResponseDto
import com.nestorian87.eter.data.remote.dto.ListenStartResponseDto
import com.nestorian87.eter.data.remote.dto.MyPostsResponseDto
import com.nestorian87.eter.data.remote.dto.PopularPostsResponseDto
import com.nestorian87.eter.data.remote.dto.PostAudioAnalysisDto
import com.nestorian87.eter.data.remote.dto.PostAuthorDto
import com.nestorian87.eter.data.remote.dto.PostCategoryDto
import com.nestorian87.eter.data.remote.dto.PostCommentDto
import com.nestorian87.eter.data.remote.dto.PostCommentsResponseDto
import com.nestorian87.eter.data.remote.dto.PostDto
import com.nestorian87.eter.data.remote.dto.PostFeedResponseDto
import com.nestorian87.eter.data.remote.dto.PostListResponseDto
import com.nestorian87.eter.data.remote.dto.PostStatusDto
import com.nestorian87.eter.data.remote.dto.PostTextSynchronizationDto
import com.nestorian87.eter.data.remote.dto.PublicConfigDto
import com.nestorian87.eter.domain.model.ListenEndResult
import com.nestorian87.eter.domain.model.ListenProgressResult
import com.nestorian87.eter.domain.model.ListenStartResult
import com.nestorian87.eter.domain.model.MyPostsPage
import com.nestorian87.eter.domain.model.MyPostsSortBy
import com.nestorian87.eter.domain.model.PopularPostsPage
import com.nestorian87.eter.domain.model.Post
import com.nestorian87.eter.domain.model.PostAudioAccent
import com.nestorian87.eter.domain.model.PostAudioAnalysis
import com.nestorian87.eter.domain.model.PostAudioSilence
import com.nestorian87.eter.domain.model.PostAuthor
import com.nestorian87.eter.domain.model.PostCategory
import com.nestorian87.eter.domain.model.PostComment
import com.nestorian87.eter.domain.model.PostCommentsPage
import com.nestorian87.eter.domain.model.PostCommentsSort
import com.nestorian87.eter.domain.model.PostFeedPage
import com.nestorian87.eter.domain.model.PostListPage
import com.nestorian87.eter.domain.model.PostSearchSortBy
import com.nestorian87.eter.domain.model.PostStatus
import com.nestorian87.eter.domain.model.PostTextSynchronization
import com.nestorian87.eter.domain.model.ProfilePostsAuthorType
import com.nestorian87.eter.domain.model.ProfilePostsSortBy
import com.nestorian87.eter.domain.model.PublicConfig
import com.nestorian87.eter.domain.model.RecordingConfig
import com.nestorian87.eter.domain.model.SortOrder
import com.nestorian87.eter.domain.model.SubscriptionConfig

fun PublicConfigDto.toDomain(): PublicConfig = PublicConfig(
    recording = RecordingConfig(
        freeDurationLimitMinutes = recording.freeDurationLimitMinutes,
        premiumDurationLimitMinutes = recording.premiumDurationLimitMinutes,
    ),
    subscription = SubscriptionConfig(
        priceUsd = subscription.priceUsd,
    ),
)

fun PostCategoryDto.toDomain(): PostCategory = PostCategory(
    categoryId = categoryId,
    categoryName = categoryName,
    categoryDescription = categoryDescription,
)

fun PostAudioAnalysisDto.toDomain(): PostAudioAnalysis = PostAudioAnalysis(
    version = version,
    durationMs = durationMs,
    frameMs = frameMs,
    features = features,
    frames = frames,
    waveform = waveform,
    accents = accents.mapNotNull { accent ->
        if (accent.size < 2) {
            null
        } else {
            PostAudioAccent(
                timestampMs = accent[0].toLong(),
                intensity = accent[1].toFloat(),
            )
        }
    },
    silences = silences.mapNotNull { silence ->
        if (silence.size < 2) {
            null
        } else {
            PostAudioSilence(
                startMs = silence[0],
                endMs = silence[1],
            )
        }
    },
)

fun PostDto.toDomain(): Post = Post(
    postId = postId,
    title = title,
    description = description,
    text = text,
    audioFileName = audioFileName,
    audioFileUrl = audioFileUrl,
    audioDurationSeconds = audioDurationSeconds,
    status = status.toDomain(),
    listens = listens,
    likesCount = likesCount,
    isLiked = isLiked,
    commentsCount = commentsCount,
    originAuthorName = originAuthorName,
    audioAnalysis = audioAnalysis?.toDomain(),
    textSynchronization = textSynchronization
        .sortedBy(PostTextSynchronizationDto::lineIndex)
        .map(PostTextSynchronizationDto::toDomain),
    categories = categories.map(PostCategoryDto::toDomain),
    authorId = authorId,
    author = author?.toDomain(),
    slug = slug,
    createdAt = createdAt,
    updatedAt = updatedAt,
)

fun MyPostsResponseDto.toDomain(): MyPostsPage = MyPostsPage(
    items = items.map(PostDto::toDomain),
    total = total,
    offset = offset,
)

fun PopularPostsResponseDto.toDomain(): PopularPostsPage = PopularPostsPage(
    items = items.map(PostDto::toDomain),
    total = total,
    snapshotId = snapshotId,
    snapshotGeneratedAt = snapshotGeneratedAt,
    nextCursor = nextCursor,
    hasMore = hasMore,
)

fun PostListResponseDto.toDomain(): PostListPage = PostListPage(
    items = items.map(PostDto::toDomain),
    total = total,
    offset = offset,
)

fun PostFeedResponseDto.toDomain(): PostFeedPage = PostFeedPage(
    items = items.map(PostDto::toDomain),
    nextCursor = nextCursor,
    hasMore = hasMore,
)

fun ListenStartResponseDto.toDomain(): ListenStartResult = ListenStartResult(
    token = token,
    listenedMs = listenedMs,
    trackDurationMs = trackDurationMs,
    isSuspicious = isSuspicious,
)

fun ListenProgressResponseDto.toDomain(): ListenProgressResult = ListenProgressResult(
    listenedMs = listenedMs,
    isSuspicious = isSuspicious,
    suspiciousReason = suspiciousReason,
)

fun ListenEndResponseDto.toDomain(): ListenEndResult = ListenEndResult(
    listenedMs = listenedMs,
    isSuspicious = isSuspicious,
    suspiciousReason = suspiciousReason,
    counted = counted,
    countedAt = countedAt,
    thresholdReached = thresholdReached,
)

fun PostAuthorDto.toDomain(): PostAuthor = PostAuthor(
    userId = userId,
    name = name,
    username = username,
    photo = photo,
    isPremium = isPremium,
)

fun PostTextSynchronizationDto.toDomain(): PostTextSynchronization = PostTextSynchronization(
    lineIndex = lineIndex,
    audioStartMomentMs = audioStartMomentMs,
)

fun PostCommentDto.toDomain(): PostComment = PostComment(
    commentId = commentId,
    postId = postId,
    parentCommentId = parentCommentId,
    authorId = authorId,
    author = author?.toDomain(),
    text = text,
    likesCount = likesCount,
    repliesCount = repliesCount,
    isLikedByMe = isLikedByMe,
    isLikedByAuthor = isLikedByAuthor,
    createdAt = createdAt,
    updatedAt = updatedAt,
)

fun PostCommentsResponseDto.toDomain(): PostCommentsPage = PostCommentsPage(
    items = items.map(PostCommentDto::toDomain),
    nextCursor = nextCursor,
)

fun MyPostsSortBy.toApiValue(): String = when (this) {
    MyPostsSortBy.CREATED_AT -> "createdAt"
    MyPostsSortBy.UPDATED_AT -> "updatedAt"
    MyPostsSortBy.TITLE -> "title"
    MyPostsSortBy.LISTENS -> "listens"
}

fun PostStatus.toApiValue(): String = when (this) {
    PostStatus.DRAFT -> "draft"
    PostStatus.PROCESSING -> "processing"
    PostStatus.PUBLISHED -> "published"
}

fun SortOrder.toApiValue(): String = when (this) {
    SortOrder.ASC -> "asc"
    SortOrder.DESC -> "desc"
}

fun PostCommentsSort.toApiValue(): String = when (this) {
    PostCommentsSort.NEWEST -> "newest"
    PostCommentsSort.OLDEST -> "oldest"
    PostCommentsSort.POPULAR -> "popular"
}

fun PostSearchSortBy.toApiValue(): String = when (this) {
    PostSearchSortBy.NEWEST -> "newest"
    PostSearchSortBy.OLDEST -> "oldest"
    PostSearchSortBy.POPULAR -> "popular"
}

fun ProfilePostsSortBy.toApiValue(): String = when (this) {
    ProfilePostsSortBy.CREATED_AT -> "createdAt"
    ProfilePostsSortBy.LISTENS -> "listens"
}

fun ProfilePostsAuthorType.toApiValue(): String? = when (this) {
    ProfilePostsAuthorType.ALL -> null
    ProfilePostsAuthorType.AUTHOR -> "author"
    ProfilePostsAuthorType.ORIGINAL -> "original"
}

fun PostStatusDto.toDomain(): PostStatus = when (this) {
    PostStatusDto.draft -> PostStatus.DRAFT
    PostStatusDto.processing -> PostStatus.PROCESSING
    PostStatusDto.published -> PostStatus.PUBLISHED
}
