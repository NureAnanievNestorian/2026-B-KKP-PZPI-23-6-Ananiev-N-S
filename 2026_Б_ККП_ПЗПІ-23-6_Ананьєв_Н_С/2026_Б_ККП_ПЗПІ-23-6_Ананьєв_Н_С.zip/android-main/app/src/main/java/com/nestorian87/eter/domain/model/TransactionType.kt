package com.nestorian87.eter.domain.model

enum class TransactionType {
    CHARGE,
    HOLD,
    REFUND,
    UNKNOWN;

    companion object {
        fun fromString(value: String): TransactionType = when (value.lowercase()) {
            "charge" -> CHARGE
            "hold" -> HOLD
            "refund" -> REFUND
            else -> UNKNOWN
        }
    }
}
