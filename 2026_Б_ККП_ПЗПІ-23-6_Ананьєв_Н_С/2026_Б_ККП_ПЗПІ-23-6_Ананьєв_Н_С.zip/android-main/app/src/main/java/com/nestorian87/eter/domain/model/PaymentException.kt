package com.nestorian87.eter.domain.model

class PaymentException(
    val reasons: Set<Reason>,
    cause: Throwable? = null,
) : Exception(cause) {
    init {
        require(reasons.isNotEmpty()) { "PaymentException requires at least one reason" }
    }

    val primaryReason: Reason
        get() = reasons.first()

    enum class Reason {
        NETWORK,
        SUBSCRIPTION_ALREADY_ACTIVE,
        CANCELLATION_NOT_ALLOWED,
        CARD_UPDATE_NOT_ALLOWED,
        UNKNOWN,
    }
}
