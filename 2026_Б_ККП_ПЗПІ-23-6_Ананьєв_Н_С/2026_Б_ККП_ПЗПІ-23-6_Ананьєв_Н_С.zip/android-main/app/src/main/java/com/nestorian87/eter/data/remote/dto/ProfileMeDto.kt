package com.nestorian87.eter.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class ProfileMeDto(
    val userId: Long,
    val name: String,
    val username: String,
    val email: String,
    val photo: String? = null,
    val bio: String? = null,
    val link: String? = null,
    val isEmailVerified: Boolean = false,
    val isPremium: Boolean = false,
    val createdAt: String,
    val followersCount: Int = 0,
    val followingCount: Int = 0,
    val postsCount: Int = 0,
    val currentViolationsCount: Int = 0,
    val maxViolationsBeforeBlock: Int = 0,
)
