package com.nestorian87.eter.ui.screens.notifications

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nestorian87.eter.R
import com.nestorian87.eter.domain.model.NotificationException
import com.nestorian87.eter.domain.model.NotificationItem
import com.nestorian87.eter.domain.model.NotificationListType
import com.nestorian87.eter.domain.model.NotificationRealtimeEvent
import com.nestorian87.eter.domain.model.NotificationStatus
import com.nestorian87.eter.domain.model.NotificationType
import com.nestorian87.eter.domain.model.NotificationsQuery
import com.nestorian87.eter.domain.repository.NotificationRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class NotificationsViewModel @Inject constructor(
    private val notificationRepository: NotificationRepository,
) : ViewModel() {
    private val _uiState = MutableStateFlow(NotificationsUiState())
    val uiState: StateFlow<NotificationsUiState> = _uiState.asStateFlow()

    private val effectChannel = Channel<NotificationsEffect>(Channel.BUFFERED)
    val effects = effectChannel.receiveAsFlow()

    private var loadJob: Job? = null
    private var nextCursor: String? = null
    private var sourceItems: List<NotificationItem> = emptyList()
    private var didMarkAllSeen = false

    init {
        observeCounts()
        observeRealtimeEvents()
        loadInitial()
        markAllSeenIfNeeded()
    }

    fun loadInitial() {
        loadJob?.cancel()
        nextCursor = null
        sourceItems = emptyList()
        _uiState.update {
            it.copy(
                items = emptyList(),
                isInitialLoading = true,
                isLoadingMore = false,
                canLoadMore = false,
                error = null,
            )
        }
        loadPage(reset = true)
    }

    fun onLoadMore() {
        val state = _uiState.value
        if (state.isInitialLoading || state.isLoadingMore || !state.canLoadMore) {
            return
        }

        _uiState.update { it.copy(isLoadingMore = true, error = null) }
        loadPage(reset = false)
    }

    fun onFilterSelected(filter: NotificationsFilter) {
        if (_uiState.value.selectedFilter == filter) {
            return
        }
        _uiState.update { it.copy(selectedFilter = filter) }
        loadInitial()
        markAllSeenIfNeeded()
    }

    fun onMarkAllRead() {
        if (_uiState.value.isMarkAllReadLoading || _uiState.value.unreadCount == 0) {
            return
        }

        _uiState.update { it.copy(isMarkAllReadLoading = true) }
        viewModelScope.launch {
            runCatching {
                notificationRepository.markAllRead()
            }.onSuccess {
                sourceItems = sourceItems.map { it.copy(isRead = true, isSeen = true) }
                _uiState.update {
                    it.copy(
                        items = filterItems(sourceItems, it.selectedFilter),
                        isMarkAllReadLoading = false,
                    )
                }
            }.onFailure { error ->
                if (error is CancellationException) {
                    throw error
                }
                _uiState.update { it.copy(isMarkAllReadLoading = false) }
                effectChannel.trySend(NotificationsEffect.ShowMessage(error.toMessageResId()))
            }
        }
    }

    fun onNotificationClick(notificationId: Long) {
        val state = _uiState.value
        if (state.pendingNotificationIds.contains(notificationId)) {
            return
        }
        val item = sourceItems.firstOrNull { it.notificationId == notificationId } ?: return

        _uiState.update {
            it.copy(pendingNotificationIds = it.pendingNotificationIds + notificationId)
        }

        viewModelScope.launch {
            runCatching {
                if (!item.isSeen) {
                    notificationRepository.markSeen(notificationId)
                }
                if (!item.isRead) {
                    notificationRepository.markRead(notificationId)
                }
            }.onSuccess {
                sourceItems = sourceItems.map { current ->
                    if (current.notificationId == notificationId) {
                        current.copy(isRead = true, isSeen = true)
                    } else {
                        current
                    }
                }
                _uiState.update {
                    it.copy(
                        items = filterItems(sourceItems, it.selectedFilter),
                        pendingNotificationIds = it.pendingNotificationIds - notificationId,
                    )
                }
                effectChannel.trySend(item.toEffect())
            }.onFailure { error ->
                if (error is CancellationException) {
                    throw error
                }
                _uiState.update {
                    it.copy(
                        pendingNotificationIds = it.pendingNotificationIds - notificationId,
                    )
                }
                effectChannel.trySend(NotificationsEffect.ShowMessage(error.toMessageResId()))
            }
        }
    }

    private fun observeCounts() {
        viewModelScope.launch {
            notificationRepository.counts.collect { counts ->
                _uiState.update {
                    it.copy(
                        unreadCount = counts.unreadCount,
                        unseenCount = counts.unseenCount,
                    )
                }
            }
        }
    }

    private fun observeRealtimeEvents() {
        viewModelScope.launch {
            notificationRepository.events.collect { event ->
                when (event) {
                    is NotificationRealtimeEvent.NotificationReceived -> {
                        if (!event.notification.isVisible()) {
                            return@collect
                        }
                        sourceItems = (listOf(event.notification) + sourceItems)
                            .distinctBy(NotificationItem::notificationId)
                        _uiState.update {
                            it.copy(items = filterItems(sourceItems, it.selectedFilter))
                        }
                    }

                    is NotificationRealtimeEvent.CountsUpdated -> Unit
                }
            }
        }
    }

    private fun loadPage(reset: Boolean) {
        loadJob = viewModelScope.launch {
            runCatching {
                notificationRepository.getNotifications(
                    query = currentQuery(cursor = if (reset) null else nextCursor),
                )
            }.onSuccess { page ->
                nextCursor = page.nextCursor
                sourceItems = (if (reset) {
                    page.items
                } else {
                    sourceItems + page.items
                }).distinctBy(NotificationItem::notificationId)
                    .filter { it.isVisible() }

                _uiState.update {
                    it.copy(
                        items = filterItems(sourceItems, it.selectedFilter),
                        isInitialLoading = false,
                        isLoadingMore = false,
                        canLoadMore = page.hasMore,
                        error = null,
                    )
                }
            }.onFailure { error ->
                if (error is CancellationException) {
                    throw error
                }
                _uiState.update {
                    it.copy(
                        isInitialLoading = false,
                        isLoadingMore = false,
                        error = error,
                    )
                }
            }
        }
    }

    private fun markAllSeenIfNeeded() {
        if (didMarkAllSeen) {
            return
        }
        didMarkAllSeen = true
        viewModelScope.launch {
            runCatching {
                notificationRepository.markAllSeen()
            }
        }
    }

    private fun currentQuery(cursor: String?): NotificationsQuery {
        return _uiState.value.selectedFilter.toQuery(cursor)
    }

    private fun filterItems(
        items: List<NotificationItem>,
        filter: NotificationsFilter,
    ): List<NotificationItem> = items.filter { item -> filter.includes(item) }

    private fun NotificationItem.toEffect(): NotificationsEffect {
        val routePayload = targetRoutePayload
        val username = routePayload?.username
            ?.trim()
            ?.takeIf { it.isNotEmpty() }
            ?: if (notificationType == NotificationType.USER_FOLLOWED) {
                lastActor?.username?.trim()?.takeIf { it.isNotEmpty() }
            } else {
                null
            }
        if (username != null) {
            return NotificationsEffect.OpenProfile(username)
        }

        val targetPostId = routePayload?.postId ?: postId
        if (targetPostId != null) {
            return NotificationsEffect.OpenPost(
                postId = targetPostId,
                focusComments = (routePayload?.commentId ?: commentId) != null,
            )
        }

        return NotificationsEffect.ShowMessage(R.string.notifications_content_unavailable)
    }

    private fun Throwable.toMessageResId(): Int =
        when ((this as? NotificationException)?.primaryReason) {
            NotificationException.Reason.NETWORK -> R.string.notifications_error_network
            NotificationException.Reason.UNAUTHORIZED -> R.string.notifications_error_unauthorized
            else -> R.string.notifications_error_generic
        }

    private fun NotificationItem.isVisible(): Boolean = notificationType != NotificationType.UNKNOWN

    private fun NotificationsFilter.toQuery(cursor: String?): NotificationsQuery = when (this) {
        NotificationsFilter.ALL -> NotificationsQuery(
            cursor = cursor,
            limit = PAGE_SIZE,
            status = NotificationStatus.ALL,
        )

        NotificationsFilter.UNREAD -> NotificationsQuery(
            cursor = cursor,
            limit = PAGE_SIZE,
            status = NotificationStatus.UNREAD,
        )

        NotificationsFilter.COMMENTS -> NotificationsQuery(
            cursor = cursor,
            limit = PAGE_SIZE,
            status = NotificationStatus.ALL,
            type = NotificationListType.COMMENTS,
        )

        NotificationsFilter.FOLLOWS -> NotificationsQuery(
            cursor = cursor,
            limit = PAGE_SIZE,
            status = NotificationStatus.ALL,
            type = NotificationListType.FOLLOWS,
        )
    }

    private fun NotificationsFilter.includes(item: NotificationItem): Boolean = when (this) {
        NotificationsFilter.ALL -> true
        NotificationsFilter.UNREAD -> !item.isRead
        NotificationsFilter.COMMENTS -> item.notificationType in COMMENT_FILTER_TYPES
        NotificationsFilter.FOLLOWS -> item.notificationType == NotificationType.USER_FOLLOWED
    }

    private companion object {
        const val PAGE_SIZE = 20

        val COMMENT_FILTER_TYPES = setOf(
            NotificationType.POST_COMMENTED,
            NotificationType.COMMENT_REPLIED,
            NotificationType.COMMENT_LIKED,
        )
    }
}
