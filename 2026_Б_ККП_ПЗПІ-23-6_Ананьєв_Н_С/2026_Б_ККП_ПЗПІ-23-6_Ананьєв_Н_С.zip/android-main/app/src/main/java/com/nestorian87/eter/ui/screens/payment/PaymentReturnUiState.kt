package com.nestorian87.eter.ui.screens.payment

import com.nestorian87.eter.domain.model.SubscriptionTransaction

enum class PaymentReturnPhase {
    CHECKING,
    SUCCESS_CHECKOUT,
    SUCCESS_CARD,
    FAILURE,
}

val PaymentReturnPhase.isTerminal: Boolean
    get() = this != PaymentReturnPhase.CHECKING

data class PaymentReturnUiState(
    val phase: PaymentReturnPhase = PaymentReturnPhase.CHECKING,
    val failureTransactions: List<SubscriptionTransaction> = emptyList(),
)
