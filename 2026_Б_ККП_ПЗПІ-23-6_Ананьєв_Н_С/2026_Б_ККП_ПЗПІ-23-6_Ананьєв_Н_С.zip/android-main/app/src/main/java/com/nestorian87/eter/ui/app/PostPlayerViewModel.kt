package com.nestorian87.eter.ui.app

import androidx.lifecycle.ViewModel
import com.nestorian87.eter.domain.model.Post
import com.nestorian87.eter.service.PostPlayerManager
import com.nestorian87.eter.ui.components.audio.PostPlayerUiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

@HiltViewModel
class PostPlayerViewModel @Inject constructor(
    private val postPlayerManager: PostPlayerManager,
) : ViewModel() {
    val uiState: StateFlow<PostPlayerUiState> = postPlayerManager.uiState

    fun togglePlayback(post: Post) {
        postPlayerManager.togglePostPlayback(post)
    }

    fun pausePlayback() {
        postPlayerManager.pausePlayback()
    }

    fun seekToPercent(percent: Float) {
        postPlayerManager.seekToPercent(percent)
    }

    fun closePlayer() {
        postPlayerManager.closePlayer()
    }

    fun setImmersiveModeOpen(open: Boolean) {
        postPlayerManager.setImmersiveModeOpen(open)
    }

}
