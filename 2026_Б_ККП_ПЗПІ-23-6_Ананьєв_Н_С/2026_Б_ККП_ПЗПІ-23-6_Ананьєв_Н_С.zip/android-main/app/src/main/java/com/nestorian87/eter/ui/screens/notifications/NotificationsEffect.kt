package com.nestorian87.eter.ui.screens.notifications

import androidx.annotation.StringRes

sealed interface NotificationsEffect {
    data class OpenPost(
        val postId: Long,
        val focusComments: Boolean,
    ) : NotificationsEffect

    data class OpenProfile(
        val username: String,
    ) : NotificationsEffect

    data class ShowMessage(
        @param:StringRes val messageResId: Int,
    ) : NotificationsEffect
}
