package com.nestorian87.eter.data.repository

import com.nestorian87.eter.data.remote.dto.ApiErrorResponseDto
import com.nestorian87.eter.data.remote.dto.ApiFieldErrorDto
import com.nestorian87.eter.domain.model.FieldViolation
import com.nestorian87.eter.domain.model.ProfileException
import com.nestorian87.eter.domain.model.ServerValidationException
import kotlinx.serialization.json.Json
import retrofit2.HttpException

internal class ProfileServerErrorMapper(
    private val json: Json,
) {
    fun toCommonException(error: HttpException): Throwable = when (error.code()) {
        400 -> ProfileException(
            reasons = setOf(ProfileException.Reason.INVALID_DATA),
            cause = error
        )

        401 -> ProfileException(
            reasons = setOf(ProfileException.Reason.UNAUTHORIZED),
            cause = error
        )

        404 -> ProfileException(
            reasons = setOf(ProfileException.Reason.USER_NOT_FOUND),
            cause = error
        )

        409 -> ProfileException(reasons = setOf(ProfileException.Reason.UNKNOWN), cause = error)
        else -> ProfileException(reasons = setOf(ProfileException.Reason.UNKNOWN), cause = error)
    }

    fun toUpdateProfileException(error: HttpException): Throwable {
        val fieldViolations = error.parseErrorBody()
            ?.errors
            .orEmpty()
            .mapNotNull(::toFieldViolation)
            .distinct()
            .toSet()

        return when (error.code()) {
            400 -> ServerValidationException(
                reason = ServerValidationException.Reason.INVALID_DATA,
                fieldViolations = fieldViolations,
                cause = error,
            )

            409 -> ServerValidationException(
                reason = ServerValidationException.Reason.CONFLICT,
                fieldViolations = fieldViolations,
                cause = error,
            )

            401 -> ProfileException(
                reasons = setOf(ProfileException.Reason.UNAUTHORIZED),
                cause = error
            )

            else -> ProfileException(
                reasons = setOf(ProfileException.Reason.UNKNOWN),
                cause = error
            )
        }
    }

    private fun HttpException.parseErrorBody(): ApiErrorResponseDto? {
        val rawBody = response()?.errorBody()?.string().orEmpty()
        if (rawBody.isBlank()) {
            return null
        }

        return runCatching {
            json.decodeFromString<ApiErrorResponseDto>(rawBody)
        }.getOrNull()
    }

    private fun toFieldViolation(error: ApiFieldErrorDto): FieldViolation? {
        val field = error.field?.trim().orEmpty()
        val code = error.code?.trim().orEmpty()
        val message = error.message?.trim()?.takeIf { it.isNotEmpty() }

        if (field.isBlank() || code.isBlank()) {
            return null
        }

        return FieldViolation(
            field = field,
            code = code,
            message = message,
        )
    }
}
