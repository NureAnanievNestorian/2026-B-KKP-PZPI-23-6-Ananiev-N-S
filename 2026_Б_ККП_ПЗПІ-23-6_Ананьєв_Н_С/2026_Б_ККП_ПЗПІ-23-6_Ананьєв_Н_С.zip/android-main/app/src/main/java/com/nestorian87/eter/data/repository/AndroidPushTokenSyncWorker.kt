package com.nestorian87.eter.data.repository

import android.annotation.SuppressLint
import android.content.Context
import android.provider.Settings
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.google.firebase.messaging.FirebaseMessaging
import com.nestorian87.eter.BuildConfig
import com.nestorian87.eter.data.local.datastore.AuthSessionStore
import com.nestorian87.eter.data.local.datastore.PushTokenStore
import com.nestorian87.eter.data.remote.api.Api
import com.nestorian87.eter.data.remote.dto.RegisterAndroidPushTokenRequestDto
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.tasks.await
import retrofit2.HttpException
import java.io.IOException

@HiltWorker
class AndroidPushTokenSyncWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted workerParams: WorkerParameters,
    private val api: Api,
    private val authSessionStore: AuthSessionStore,
    private val pushTokenStore: PushTokenStore,
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val token = pushTokenStore.readToken()
            ?: fetchFirebaseToken()?.also { pushTokenStore.saveToken(it) }
            ?: return Result.retry()
        if (authSessionStore.accessToken.isNullOrBlank()) {
            return Result.success()
        }

        return try {
            api.registerAndroidPushToken(
                request = RegisterAndroidPushTokenRequestDto(
                    token = token,
                    deviceId = resolveDeviceId(),
                    appVersion = BuildConfig.VERSION_NAME,
                ),
            )
            Result.success()
        } catch (_: IOException) {
            Result.retry()
        } catch (error: HttpException) {
            if (error.code() in 500..599) {
                Result.retry()
            } else {
                Result.failure()
            }
        }
    }

    private suspend fun fetchFirebaseToken(): String? = runCatching {
        FirebaseMessaging.getInstance().token.await().trim().ifEmpty { null }
    }.getOrNull()

    @SuppressLint("HardwareIds")
    private fun resolveDeviceId(): String? = Settings.Secure.getString(
        applicationContext.contentResolver,
        Settings.Secure.ANDROID_ID,
    )?.trim()?.takeIf { it.isNotEmpty() }
}
