package com.nestorian87.eter.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class ProfileFollowListPageResponseDto(
    val items: List<ProfileFollowListItemDto> = emptyList(),
    val total: Int = 0,
    val limit: Int = 20,
    val nextCursor: String? = null,
    val hasMore: Boolean = false,
)
