package com.nestorian87.eter.domain.model

data class ActiveViolation(
    val complaintId: Long,
    val complaintReason: String,
    val status: ViolationStatus,
    val createdAt: String,
    val expiresAt: String? = null,
    val targetPost: ViolationTargetPost,
)

data class ViolationTargetPost(
    val postId: Long,
    val title: String? = null,
    val description: String? = null,
    val text: String? = null,
    val audioFileName: String? = null,
    val createdAt: String,
)

enum class ViolationStatus {
    PENDING,
    RESOLVED,
    DISMISSED,
    UNKNOWN,
}
