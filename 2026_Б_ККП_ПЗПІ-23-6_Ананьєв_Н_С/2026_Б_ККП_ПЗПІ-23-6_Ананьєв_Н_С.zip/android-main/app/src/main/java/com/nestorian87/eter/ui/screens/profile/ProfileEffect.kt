package com.nestorian87.eter.ui.screens.profile

sealed interface ProfileEffect {
    data object NavigateToOwnProfile : ProfileEffect

    data object NavigateToLogin : ProfileEffect

    data object ProfileSaved : ProfileEffect

    data class ShareProfile(
        val url: String,
    ) : ProfileEffect
}
