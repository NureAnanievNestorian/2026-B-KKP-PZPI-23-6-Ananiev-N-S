package com.nestorian87.eter.ui.theme

import androidx.compose.ui.unit.dp

object EterSpacing {
    val xxSmall = 4.dp
    val xSmall = 8.dp
    val small = 12.dp
    val medium = 16.dp
    val large = 20.dp
    val xLarge = 24.dp
    val xxLarge = 28.dp
    val xxxLarge = 32.dp
    val section = 40.dp
    val screen = 48.dp
    val hero = 72.dp
}
