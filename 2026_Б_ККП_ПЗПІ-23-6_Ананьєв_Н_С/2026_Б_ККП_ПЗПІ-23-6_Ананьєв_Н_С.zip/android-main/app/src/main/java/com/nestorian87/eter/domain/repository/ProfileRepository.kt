package com.nestorian87.eter.domain.repository

import com.nestorian87.eter.domain.model.ActiveViolation
import com.nestorian87.eter.domain.model.FollowProfilesPage
import com.nestorian87.eter.domain.model.FollowProfilesQuery
import com.nestorian87.eter.domain.model.OwnProfile
import com.nestorian87.eter.domain.model.PublicProfile
import com.nestorian87.eter.domain.model.UpdateProfilePayload
import java.io.File

interface ProfileRepository {
    suspend fun getMyProfile(): OwnProfile

    suspend fun getPublicProfile(userId: Long): PublicProfile

    suspend fun getPublicProfile(username: String): PublicProfile

    suspend fun updateMyProfile(payload: UpdateProfilePayload): OwnProfile

    suspend fun updateMyAvatar(avatarFile: File): OwnProfile

    suspend fun removeMyAvatar(): OwnProfile

    suspend fun followProfile(userId: Long): PublicProfile

    suspend fun unfollowProfile(userId: Long): PublicProfile

    suspend fun getMyFollowers(query: FollowProfilesQuery = FollowProfilesQuery()): FollowProfilesPage

    suspend fun getMyFollowing(query: FollowProfilesQuery = FollowProfilesQuery()): FollowProfilesPage

    suspend fun getFollowers(
        userId: Long,
        query: FollowProfilesQuery = FollowProfilesQuery(),
    ): FollowProfilesPage

    suspend fun getFollowing(
        userId: Long,
        query: FollowProfilesQuery = FollowProfilesQuery(),
    ): FollowProfilesPage

    suspend fun getMyViolations(): List<ActiveViolation>

}
