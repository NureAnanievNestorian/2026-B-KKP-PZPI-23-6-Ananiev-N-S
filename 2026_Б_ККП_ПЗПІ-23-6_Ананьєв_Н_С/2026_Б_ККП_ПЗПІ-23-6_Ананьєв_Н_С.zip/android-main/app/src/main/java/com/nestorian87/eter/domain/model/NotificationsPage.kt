package com.nestorian87.eter.domain.model

data class NotificationsPage(
    val items: List<NotificationItem> = emptyList(),
    val limit: Int = 20,
    val nextCursor: String? = null,
    val hasMore: Boolean = false,
    val unreadCount: Int = 0,
    val unseenCount: Int = 0,
)
