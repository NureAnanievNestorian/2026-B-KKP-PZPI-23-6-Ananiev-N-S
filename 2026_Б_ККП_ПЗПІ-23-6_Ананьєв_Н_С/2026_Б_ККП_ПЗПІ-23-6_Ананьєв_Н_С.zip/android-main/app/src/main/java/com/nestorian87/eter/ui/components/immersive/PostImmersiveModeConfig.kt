package com.nestorian87.eter.ui.components.immersive

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

internal data class VoiceFrame(
    val energy: Float = 0f,
    val peak: Float = 0f,
    val low: Float = 0f,
    val mid: Float = 0f,
    val high: Float = 0f,
    val zcr: Float = 0f,
)

internal data class DecodedVoiceAnalysis(
    val durationMs: Long,
    val frameMs: Int,
    val frames: List<VoiceFrame>,
)

internal data class MemoryLine(
    val key: String,
    val text: String,
    val startMs: Int,
    val appearMs: Long,
    val xDp: Float,
    val yDp: Float,
    val zDp: Float,
    val rotate: Float,
    val scale: Float,
    val opacity: Float,
    val blurDp: Float,
    val brightness: Float,
    val driftXDp: Float,
    val driftYDp: Float,
    val driftDurationMs: Float,
    val driftDelayMs: Float,
)

internal data class GlowPreset(
    val x: Float,
    val y: Float,
    val baseSize: Float,
    val tone: VoiceTone,
    val seed: Float,
)

internal enum class VoiceTone { Low, Mid, High }

internal data class StrokePreset(
    val x: Float,
    val y: Float,
    val rotate: Float,
    val lowW: Float,
    val midW: Float,
    val highW: Float,
    val peakW: Float,
    val isAccentCandidate: Boolean,
    val isWhisperCandidate: Boolean,
    val driftX: Float,
    val driftY: Float,
    val driftDelay: Float,
)

internal data class ImmersiveColors(
    val toneLow: Color,
    val toneMid: Color,
    val toneHigh: Color,
    val bgBase: Color,
    val bgMid: Color,
    val bgEnd: Color,
    val accent1: Color,
    val accent1A: Float,
    val accent2: Color,
    val accent2A: Float,
    val grain: Color,
    val textStrong: Color,
    val textNormal: Color,
    val textMuted: Color,
    val memoryText: Color,
    val overlayBg: Color,
    val overlayBorder: Color,
    val controlsBg: Color,
    val controlsBorder: Color,
    val waveformColor: Color,
    val playIconActive: Color,
)

internal class GrainCache {
    var points: List<Offset> = emptyList()
    var cachedSize: Size = Size.Unspecified
}

internal val DarkImmersiveColors = ImmersiveColors(
    toneLow = Color(0xFFB05B43),
    toneMid = Color(0xFFC77E52),
    toneHigh = Color(0xFFECC99A),
    bgBase = Color(0xFF0B090B),
    bgMid = Color(0xFF21161D),
    bgEnd = Color(0xFF070607),
    accent1 = Color(0xFFE6B376),
    accent1A = 0.12f,
    accent2 = Color(0xFFAE5943),
    accent2A = 0.16f,
    grain = Color(0xFFFFF7EC),
    textStrong = Color.White.copy(alpha = 0.88f),
    textNormal = Color.White.copy(alpha = 0.88f),
    textMuted = Color.White.copy(alpha = 0.70f),
    memoryText = Color.White.copy(alpha = 0.30f),
    overlayBg = Color.White.copy(alpha = 0.10f),
    overlayBorder = Color.White.copy(alpha = 0.16f),
    controlsBg = Color.Black.copy(alpha = 0.22f),
    controlsBorder = Color.White.copy(alpha = 0.12f),
    waveformColor = Color.White,
    playIconActive = Color(0xFF21161D),
)

internal val LightImmersiveColors = ImmersiveColors(
    toneLow = Color(0xFF974F30),
    toneMid = Color(0xFFB86B3F),
    toneHigh = Color(0xFFD69E61),
    bgBase = Color(0xFFFFF9F1),
    bgMid = Color(0xFFEFE0CC),
    bgEnd = Color(0xFFFFF7EF),
    accent1 = Color(0xFFBE7040),
    accent1A = 0.11f,
    accent2 = Color(0xFFE0B984),
    accent2A = 0.28f,
    grain = Color(0xFF483022),
    textStrong = Color(0xFF22191A),
    textNormal = Color(0xFF31241E).copy(alpha = 0.94f),
    textMuted = Color(0xFF4C372C).copy(alpha = 0.56f),
    memoryText = Color(0xFF46302A).copy(alpha = 0.34f),
    overlayBg = Color(0xFF523424).copy(alpha = 0.10f),
    overlayBorder = Color(0xFF523424).copy(alpha = 0.18f),
    controlsBg = Color(0xFFFFFCF6).copy(alpha = 0.72f),
    controlsBorder = Color(0xFF523424).copy(alpha = 0.14f),
    waveformColor = Color(0xFF523424).copy(alpha = 0.72f),
    playIconActive = Color(0xFFFFF9F1),
)

internal val GlowPresets = listOf(
    GlowPreset(0.28f, 0.36f, 34f, VoiceTone.Low, 1f),
    GlowPreset(0.64f, 0.38f, 42f, VoiceTone.Mid, 2f),
    GlowPreset(0.42f, 0.58f, 52f, VoiceTone.High, 3f),
    GlowPreset(0.72f, 0.61f, 30f, VoiceTone.Low, 4f),
    GlowPreset(0.52f, 0.43f, 46f, VoiceTone.Mid, 5f),
    GlowPreset(0.35f, 0.67f, 26f, VoiceTone.High, 6f),
    GlowPreset(0.78f, 0.47f, 24f, VoiceTone.Mid, 7f),
)

internal val StrokePresets = List(36) { index ->
    val seed = index + 1f
    val cluster = index % 5
    val baseX = listOf(18f, 30f, 68f, 79f, 50f)[cluster]
    val baseY = listOf(46f, 32f, 38f, 58f, 69f)[cluster]
    val spreadX = listOf(18f, 24f, 21f, 18f, 30f)[cluster]
    val spreadY = listOf(16f, 13f, 17f, 15f, 12f)[cluster]
    StrokePreset(
        x = (baseX + sin(seed * 1.93f) * spreadX) / 100f,
        y = (baseY + cos(seed * 1.41f) * spreadY) / 100f,
        rotate = sin(seed * 0.77f) * 58f + (cluster - 2) * 14f,
        lowW = if (cluster == 0 || cluster == 3) 0.58f else 0.22f,
        midW = if (cluster == 1 || cluster == 4) 0.62f else 0.30f,
        highW = if (cluster == 2) 0.72f else 0.24f,
        peakW = if (index % 7 == 0) 0.52f else 0.20f,
        isAccentCandidate = index % 6 == 0,
        isWhisperCandidate = index % 3 == 0,
        driftX = sin(seed * 2.1f) * 6f,
        driftY = cos(seed * 1.6f) * 5f,
        driftDelay = (seed % 9f) * -600f,
    )
}

internal const val AccentDecayWindowMs = 520f
internal const val AccentStrokeThreshold = 0.36f
internal const val AnticipationMs = 380L
internal const val LeadingSilenceToleranceMs = 120L
internal const val TrailingSilenceToleranceMs = 160L

internal const val MaxMemoryLines = 4
internal const val MemoryLineDelayMs = 1_250L
internal const val MemoryLineLifetimeMs = 22_000f
internal const val MemoryLineFadeInMs = 1_400f
internal const val MemoryLineFadeOutMs = 6_000f
internal const val InitialMemoryBackfillWindowMs = 12_000L
internal const val MemoryBackfillAppearDelayMs = 900L
internal const val MemoryBackfillStaggerMs = 1_250L
internal const val MemoryListRebuildIntervalMs = 400L

internal const val MaxFrameDeltaMs = 48L
internal const val PausedAnimationSpeedMultiplier = 0.18f
internal const val ReactivePulseAttack = 0.55f
internal const val ReactivePulseRelease = 0.085f
internal const val SilenceEnergyThreshold = 0.13f

internal const val ImmersiveEnterDurationMs = 180
internal const val ImmersiveExitDurationMs = 160
internal const val ImmersiveLineEnterDurationMs = 180
internal const val ImmersiveLineExitDurationMs = 90
internal const val ImmersivePlayIconDurationMs = 120
internal const val ImmersiveOverlayZIndex = 20f

internal val ImmersiveDisplayTextMaxWidth = 560.dp
internal val ImmersiveControlsPlayButtonSize = 50.dp
internal val ImmersiveControlsPlayIconSize = 28.dp
internal val ImmersiveWaveformHeight = 36.dp
internal val MobileCompactWidthBreakpoint = 420.dp

internal const val TwoPi = (PI * 2.0).toFloat()
