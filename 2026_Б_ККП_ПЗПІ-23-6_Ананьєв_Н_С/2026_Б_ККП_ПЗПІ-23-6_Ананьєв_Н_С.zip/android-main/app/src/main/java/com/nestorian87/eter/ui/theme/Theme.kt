package com.nestorian87.eter.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = CopperGlow,
    secondary = ClayLight,
    tertiary = Taupe,
    background = Ink,
    surface = Mocha,
    surfaceVariant = Cocoa,
    onPrimary = Espresso,
    onSecondary = Cream,
    onTertiary = Cream,
    onBackground = Linen,
    onSurface = Linen,
    onSurfaceVariant = Taupe,
    outline = AshRose.copy(alpha = 0.22f),
)

private val LightColorScheme = lightColorScheme(
    primary = Terracotta,
    secondary = BurntClay,
    tertiary = BurntClay,
    background = Paper,
    surface = WarmBeige,
    surfaceVariant = QuietRose,
    onPrimary = Paper,
    onSecondary = Paper,
    onTertiary = Paper,
    onBackground = Umber,
    onSurface = Umber,
    onSurfaceVariant = Sepia.copy(alpha = 0.72f),
    outline = Mushroom.copy(alpha = 0.38f),
)

@Composable
fun EterTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = Shapes,
        content = content
    )
}
