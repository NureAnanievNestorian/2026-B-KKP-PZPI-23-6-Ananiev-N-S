package com.nestorian87.eter.ui.components.layout

import androidx.annotation.StringRes
import com.nestorian87.eter.domain.model.Post

data class PostCardUiModel(
    val post: Post,
    val isLiked: Boolean = false,
    @param:StringRes val statusLabelResId: Int? = null,
)