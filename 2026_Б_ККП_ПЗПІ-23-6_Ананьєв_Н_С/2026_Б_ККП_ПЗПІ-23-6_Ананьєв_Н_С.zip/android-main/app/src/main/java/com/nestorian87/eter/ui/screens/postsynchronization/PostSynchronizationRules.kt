package com.nestorian87.eter.ui.screens.postsynchronization

import com.nestorian87.eter.domain.model.Post
import com.nestorian87.eter.domain.model.PostStatus
import com.nestorian87.eter.domain.model.PostTextSynchronization

fun seedSynchronization(
    initialSynchronization: List<PostTextSynchronization>,
    syncableLines: List<SyncableLineUiModel>,
): Map<Int, Int> {
    val local = initialSynchronization
        .associate { it.lineIndex to it.audioStartMomentMs }
        .toMutableMap()
    syncableLines.firstOrNull()?.takeIf(SyncableLineUiModel::isLocked)?.let { lockedLine ->
        local[lockedLine.lineIndex] = 0
    }
    return local.toMap()
}

fun initialFocusedLinePosition(
    syncableLines: List<SyncableLineUiModel>,
    localSynchronization: Map<Int, Int>,
): Int? {
    return syncableLines.firstOrNull { line ->
        !line.isLocked && !localSynchronization.containsKey(line.lineIndex)
    }?.position ?: syncableLines.firstOrNull { !it.isLocked }?.position
}

fun resolveBlockingReason(
    post: Post,
    currentUserId: Long?,
    isPremium: Boolean,
): PostSynchronizationBlockingReason? = when {
    currentUserId == null || currentUserId != post.authorId -> PostSynchronizationBlockingReason.ACCESS_DENIED
    !isPremium -> PostSynchronizationBlockingReason.PREMIUM_REQUIRED
    post.status == PostStatus.PROCESSING -> PostSynchronizationBlockingReason.POST_IS_PROCESSING
    post.text.isNullOrBlank() -> PostSynchronizationBlockingReason.MISSING_TEXT
    post.audioFileUrl.isNullOrBlank() -> PostSynchronizationBlockingReason.MISSING_AUDIO
    else -> null
}

fun validateSynchronization(
    syncableLines: List<SyncableLineUiModel>,
    localSynchronization: Map<Int, Int>,
    durationSeconds: Int?,
    includeMissing: Boolean,
): Map<Int, PostSynchronizationValidationIssue> {
    val issues = linkedMapOf<Int, PostSynchronizationValidationIssue>()
    val durationLimitMs = durationSeconds?.times(1_000)
    var previousTimestampMs: Int? = null

    syncableLines.forEach { line ->
        val currentTimestampMs = localSynchronization[line.lineIndex]
        if (currentTimestampMs == null) {
            if (includeMissing) {
                issues[line.lineIndex] = PostSynchronizationValidationIssue(
                    kind = PostSynchronizationValidationKind.MISSING,
                )
            }
            return@forEach
        }

        if (durationLimitMs != null && currentTimestampMs > durationLimitMs) {
            issues[line.lineIndex] = PostSynchronizationValidationIssue(
                kind = PostSynchronizationValidationKind.EXCEEDS_DURATION,
            )
            previousTimestampMs = currentTimestampMs
            return@forEach
        }

        if (previousTimestampMs != null && currentTimestampMs <= previousTimestampMs) {
            issues[line.lineIndex] = PostSynchronizationValidationIssue(
                kind = PostSynchronizationValidationKind.OUT_OF_ORDER,
            )
        }
        previousTimestampMs = currentTimestampMs
    }

    return issues
}

fun firstInvalidLinePosition(
    syncableLines: List<SyncableLineUiModel>,
    validationIssues: Map<Int, PostSynchronizationValidationIssue>,
): Int? = syncableLines.firstOrNull { line ->
    validationIssues.containsKey(line.lineIndex)
}?.position
