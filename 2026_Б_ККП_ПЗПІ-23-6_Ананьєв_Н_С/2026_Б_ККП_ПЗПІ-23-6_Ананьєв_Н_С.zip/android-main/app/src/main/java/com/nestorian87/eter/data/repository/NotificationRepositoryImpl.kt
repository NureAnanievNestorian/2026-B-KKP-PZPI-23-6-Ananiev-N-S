package com.nestorian87.eter.data.repository

import android.util.Log
import com.nestorian87.eter.BuildConfig
import com.nestorian87.eter.data.local.datastore.AuthSessionStore
import com.nestorian87.eter.data.mapper.toApiValue
import com.nestorian87.eter.data.mapper.toDomain
import com.nestorian87.eter.data.remote.api.Api
import com.nestorian87.eter.data.remote.dto.NotificationRealtimePayloadDto
import com.nestorian87.eter.data.remote.dto.NotificationsCountsResponseDto
import com.nestorian87.eter.data.remote.dto.UpdatePushNotificationSettingsRequestDto
import com.nestorian87.eter.domain.model.NotificationCounts
import com.nestorian87.eter.domain.model.NotificationException
import com.nestorian87.eter.domain.model.NotificationListType
import com.nestorian87.eter.domain.model.NotificationRealtimeEvent
import com.nestorian87.eter.domain.model.NotificationType
import com.nestorian87.eter.domain.model.NotificationsPage
import com.nestorian87.eter.domain.model.NotificationsQuery
import com.nestorian87.eter.domain.model.PushNotificationSettings
import com.nestorian87.eter.domain.repository.AuthRepository
import com.nestorian87.eter.domain.repository.NotificationRepository
import io.socket.client.IO
import io.socket.client.Socket
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import retrofit2.HttpException
import java.net.URI
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationRepositoryImpl @Inject constructor(
    private val api: Api,
    private val authSessionStore: AuthSessionStore,
    private val authRepository: AuthRepository,
    private val json: Json,
    private val applicationScope: CoroutineScope,
) : NotificationRepository {
    private val _counts = MutableStateFlow(NotificationCounts())
    override val counts: StateFlow<NotificationCounts> = _counts.asStateFlow()

    private val _events = MutableSharedFlow<NotificationRealtimeEvent>(extraBufferCapacity = 64)
    override val events: SharedFlow<NotificationRealtimeEvent> = _events.asSharedFlow()

    private var socket: Socket? = null
    private var reconnectAfterRefresh = false

    init {
        applicationScope.launch {
            authSessionStore.session.collectLatest { session ->
                if (session == null) {
                    reconnectAfterRefresh = false
                    disconnectSocket()
                    _counts.value = NotificationCounts()
                    return@collectLatest
                }

                refreshCounts()
                connectSocket()
            }
        }
    }

    override suspend fun getNotifications(query: NotificationsQuery): NotificationsPage =
        executeRequest {
            api.getNotifications(
                limit = query.limit,
                cursor = query.cursor,
                status = query.status.name.lowercase(),
                type = query.type?.toApiValue(),
            ).toDomain().also(::updateCountsFromPage)
        }

    override suspend fun getPushSettings(): PushNotificationSettings = executeRequest {
        api.getPushNotificationSettings().toDomain()
    }

    override suspend fun updatePushSettings(disabledTypes: Set<NotificationType>): PushNotificationSettings =
        executeRequest {
            api.updatePushNotificationSettings(
                request = UpdatePushNotificationSettingsRequestDto(
                    disabledTypes = disabledTypes
                        .filterNot { it == NotificationType.UNKNOWN }
                        .map(NotificationType::toApiValue),
                ),
            ).toDomain()
        }

    override suspend fun markAllSeen(): NotificationCounts = executeRequest {
        val response = api.markAllNotificationsSeen()
        NotificationCounts(
            unreadCount = counts.value.unreadCount,
            unseenCount = response.unseenCount,
        ).also { _counts.value = it }
    }

    override suspend fun markSeen(notificationId: Long): NotificationCounts = executeRequest {
        val response = api.markNotificationSeen(notificationId = notificationId)
        NotificationCounts(
            unreadCount = counts.value.unreadCount,
            unseenCount = response.unseenCount,
        ).also { _counts.value = it }
    }

    override suspend fun markRead(notificationId: Long) {
        executeRequest {
            api.markNotificationRead(notificationId = notificationId)
            _counts.value = counts.value.copy(
                unreadCount = (counts.value.unreadCount - 1).coerceAtLeast(0),
            )
        }
    }

    override suspend fun markAllRead() {
        executeRequest {
            api.markAllNotificationsRead()
            _counts.value = NotificationCounts()
        }
    }

    private suspend fun refreshCounts() {
        runCatching {
            executeRequest {
                api.getNotifications(limit = 1).toDomain()
            }
        }.onSuccess(::updateCountsFromPage)
    }

    private fun connectSocket() {
        val token = authSessionStore.accessToken ?: return
        val currentSocket = socket
        if (currentSocket != null) {
            if (currentSocket.connected()) {
                return
            }
            disconnectSocket()
        }

        val opts = IO.Options().apply {
            auth = mapOf("token" to token)
        }
        val serverUrl = BuildConfig.API_BASE_URL.trimEnd('/')

        socket = IO.socket(URI.create("$serverUrl/notifications"), opts).also { nextSocket ->
            nextSocket.on(Socket.EVENT_CONNECT) {
                reconnectAfterRefresh = false
            }
            nextSocket.on(Socket.EVENT_DISCONNECT) { args ->
                val reason = args.firstOrNull()?.toString().orEmpty()
                if (reason == SERVER_DISCONNECT_REASON && !reconnectAfterRefresh) {
                    reconnectAfterRefresh = true
                    reconnectWithRefreshedSession()
                }
            }
            nextSocket.on(EVENT_NOTIFICATION_RECEIVED) { args ->
                parseAndEmitReceived(args)
            }
            nextSocket.on(EVENT_COUNTS_UPDATED) { args ->
                parseAndEmitCounts(args)
            }
            nextSocket.connect()
        }
    }

    private fun reconnectWithRefreshedSession() {
        socket?.off()
        socket?.disconnect()
        socket = null
        applicationScope.launch {
            val refreshed = runCatching { authRepository.refreshCurrentUser() }.getOrNull()
            if (refreshed != null) {
                connectSocket()
            } else {
                reconnectAfterRefresh = false
            }
        }
    }

    private fun disconnectSocket() {
        socket?.apply {
            off()
            disconnect()
        }
        socket = null
    }

    private fun parseAndEmitReceived(args: Array<Any>) {
        val raw = args.firstOrNull()?.toString() ?: return
        val payload = runCatching {
            json.decodeFromString<NotificationRealtimePayloadDto>(raw)
        }.onFailure { error ->
            Log.w(LOG_TAG, "Failed to parse notification event payload: $raw", error)
        }.getOrNull() ?: return

        _counts.value = NotificationCounts(
            unreadCount = payload.unreadCount,
            unseenCount = payload.unseenCount,
        )
        _events.tryEmit(
            NotificationRealtimeEvent.NotificationReceived(
                notification = payload.notification.toDomain(),
                unreadCount = payload.unreadCount,
                unseenCount = payload.unseenCount,
            ),
        )
    }

    private fun parseAndEmitCounts(args: Array<Any>) {
        val raw = args.firstOrNull()?.toString() ?: return
        val payload = runCatching {
            json.decodeFromString<NotificationsCountsResponseDto>(raw)
        }.onFailure { error ->
            Log.w(LOG_TAG, "Failed to parse notification counts payload: $raw", error)
        }.getOrNull() ?: return

        val nextCounts = payload.toDomain()
        _counts.value = nextCounts
        _events.tryEmit(
            NotificationRealtimeEvent.CountsUpdated(
                unreadCount = nextCounts.unreadCount,
                unseenCount = nextCounts.unseenCount,
            ),
        )
    }

    private fun updateCountsFromPage(page: NotificationsPage) {
        _counts.value = NotificationCounts(
            unreadCount = page.unreadCount,
            unseenCount = page.unseenCount,
        )
    }

    private suspend inline fun <T> executeRequest(
        crossinline block: suspend () -> T,
    ): T = try {
        block()
    } catch (error: java.io.IOException) {
        throw NotificationException(
            reasons = setOf(NotificationException.Reason.NETWORK),
            cause = error,
        )
    } catch (error: HttpException) {
        throw when (error.code()) {
            401 -> NotificationException(
                reasons = setOf(NotificationException.Reason.UNAUTHORIZED),
                cause = error,
            )

            404 -> NotificationException(
                reasons = setOf(NotificationException.Reason.NOT_FOUND),
                cause = error,
            )

            else -> NotificationException(
                reasons = setOf(NotificationException.Reason.UNKNOWN),
                cause = error,
            )
        }
    }

    private fun NotificationListType.toApiValue(): String = when (this) {
        NotificationListType.COMMENTS -> "comments"
        NotificationListType.FOLLOWS -> "follows"
        NotificationListType.LIKES -> "likes"
        NotificationListType.SYSTEM -> "system"
    }

    private companion object {
        const val LOG_TAG = "NotificationRepository"
        const val EVENT_NOTIFICATION_RECEIVED = "notification_received"
        const val EVENT_COUNTS_UPDATED = "counts_updated"
        const val SERVER_DISCONNECT_REASON = "io server disconnect"
    }
}
