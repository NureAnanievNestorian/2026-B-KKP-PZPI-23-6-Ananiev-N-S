package com.nestorian87.eter.ui.screens.payment

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nestorian87.eter.domain.model.PaymentSocketEvent
import com.nestorian87.eter.domain.model.PendingPayment
import com.nestorian87.eter.domain.model.Subscription
import com.nestorian87.eter.domain.model.SubscriptionStatus
import com.nestorian87.eter.domain.model.SubscriptionTransaction
import com.nestorian87.eter.domain.model.TransactionStatus
import com.nestorian87.eter.domain.repository.PaymentRepository
import com.nestorian87.eter.domain.repository.PaymentSocketManager
import com.nestorian87.eter.domain.repository.PendingPaymentStore
import dagger.assisted.Assisted
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

@HiltViewModel(assistedFactory = PaymentReturnViewModel.Factory::class)
class PaymentReturnViewModel @AssistedInject constructor(
    @Assisted("invoiceId") val invoiceId: String,
    @Assisted("paymentType") val paymentType: String,
    private val paymentRepository: PaymentRepository,
    private val paymentSocketManager: PaymentSocketManager,
    private val pendingPaymentStore: PendingPaymentStore,
) : ViewModel() {

    private val _uiState = MutableStateFlow(PaymentReturnUiState())
    val uiState: StateFlow<PaymentReturnUiState> = _uiState.asStateFlow()

    private val _effects = Channel<PaymentReturnEffect>(Channel.BUFFERED)
    val effects = _effects.receiveAsFlow()

    private var pollingJob: Job? = null
    private var cachedSubscription: Subscription? = null
    private var cachedTransactions: List<SubscriptionTransaction> = emptyList()

    init {
        if (invoiceId.isBlank() || paymentType !in PendingPayment.supportedPaymentTypes) {
            viewModelScope.launch { _effects.send(PaymentReturnEffect.NavigateAway) }
        } else {
            viewModelScope.launch { pendingPaymentStore.clear() }
            paymentSocketManager.connect()
            observeSocketEvents()
            startPolling()
        }
    }

    private fun startPolling() {
        pollingJob = viewModelScope.launch {
            while (!_uiState.value.phase.isTerminal) {
                reconcile()
                if (!_uiState.value.phase.isTerminal) {
                    delay(POLL_INTERVAL_MS)
                }
            }
        }
    }

    private suspend fun reconcile() {
        runCatching {
            val subscription = paymentRepository.getSubscription()
            val page = paymentRepository.getTransactions(limit = 20)
            cachedSubscription = subscription
            cachedTransactions = page.items
            val matching = page.items.find { it.invoiceId == invoiceId }
            applyState(subscription, matching)
        }
    }

    private fun applyState(subscription: Subscription?, transaction: SubscriptionTransaction?) {
        val phase = determinePhase(subscription, transaction)
        _uiState.update { current ->
            current.copy(
                phase = phase,
                failureTransactions = if (phase == PaymentReturnPhase.FAILURE) {
                    (listOfNotNull(transaction) + cachedTransactions.filter { it.invoiceId != invoiceId })
                        .distinctBy { it.transactionId }
                        .take(10)
                } else {
                    current.failureTransactions
                },
            )
        }
        if (phase.isTerminal) pollingJob?.cancel()
    }

    private fun determinePhase(
        subscription: Subscription?,
        transaction: SubscriptionTransaction?,
    ): PaymentReturnPhase {
        if (transaction == null) return PaymentReturnPhase.CHECKING
        return when (transaction.status) {
            TransactionStatus.SUCCESS ->
                if (paymentType == PendingPayment.PAYMENT_TYPE_CARD_UPDATE) PaymentReturnPhase.SUCCESS_CARD
                else PaymentReturnPhase.SUCCESS_CHECKOUT

            TransactionStatus.FAILURE, TransactionStatus.EXPIRED, TransactionStatus.REVERSED ->
                PaymentReturnPhase.FAILURE

            else ->
                if (paymentType == PendingPayment.PAYMENT_TYPE_CHECKOUT &&
                    subscription?.status == SubscriptionStatus.ACTIVE
                ) {
                    PaymentReturnPhase.SUCCESS_CHECKOUT
                } else {
                    PaymentReturnPhase.CHECKING
                }
        }
    }

    private fun observeSocketEvents() {
        viewModelScope.launch {
            paymentSocketManager.events.collect { event ->
                when (event) {
                    is PaymentSocketEvent.TransactionUpdated -> {
                        if (event.transaction.invoiceId == invoiceId) {
                            val idx = cachedTransactions.indexOfFirst {
                                it.transactionId == event.transaction.transactionId
                            }
                            cachedTransactions = if (idx >= 0) {
                                cachedTransactions.toMutableList()
                                    .also { it[idx] = event.transaction }
                            } else {
                                listOf(event.transaction) + cachedTransactions
                            }
                            applyState(cachedSubscription, event.transaction)
                        }
                    }

                    is PaymentSocketEvent.CardLinked -> {
                        if (paymentType == PendingPayment.PAYMENT_TYPE_CARD_UPDATE) {
                            cachedSubscription = event.subscription
                            _uiState.update { it.copy(phase = PaymentReturnPhase.SUCCESS_CARD) }
                            pollingJob?.cancel()
                        }
                    }

                    is PaymentSocketEvent.CheckoutCreated -> Unit
                }
            }
        }
    }

    override fun onCleared() {
        paymentSocketManager.disconnect()
    }

    @AssistedFactory
    interface Factory {
        fun create(
            @Assisted("invoiceId") invoiceId: String,
            @Assisted("paymentType") paymentType: String,
        ): PaymentReturnViewModel
    }

    companion object {
        private const val POLL_INTERVAL_MS = 3_000L
    }
}
