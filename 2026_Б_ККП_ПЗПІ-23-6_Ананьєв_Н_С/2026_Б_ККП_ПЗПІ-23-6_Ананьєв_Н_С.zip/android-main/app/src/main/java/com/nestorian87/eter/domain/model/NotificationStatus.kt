package com.nestorian87.eter.domain.model

enum class NotificationStatus {
    ALL,
    UNREAD,
}
