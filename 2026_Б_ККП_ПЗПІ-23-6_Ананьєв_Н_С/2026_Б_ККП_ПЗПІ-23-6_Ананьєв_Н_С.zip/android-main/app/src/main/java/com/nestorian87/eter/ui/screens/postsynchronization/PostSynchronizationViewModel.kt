package com.nestorian87.eter.ui.screens.postsynchronization

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nestorian87.eter.domain.model.Post
import com.nestorian87.eter.domain.repository.AuthRepository
import com.nestorian87.eter.domain.repository.PaymentRepository
import com.nestorian87.eter.domain.repository.PostRepository
import com.nestorian87.eter.service.PostPlayerManager
import dagger.assisted.Assisted
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.floor

@HiltViewModel(assistedFactory = PostSynchronizationViewModel.Factory::class)
class PostSynchronizationViewModel @AssistedInject constructor(
    @Assisted private val postId: Long,
    private val postRepository: PostRepository,
    private val authRepository: AuthRepository,
    private val paymentRepository: PaymentRepository,
    private val postPlayerManager: PostPlayerManager,
) : ViewModel() {
    private val _uiState = MutableStateFlow(
        PostSynchronizationUiState(
            currentUserId = authRepository.session.value?.user?.userId,
        ),
    )
    val uiState: StateFlow<PostSynchronizationUiState> = _uiState.asStateFlow()

    private val effectChannel = Channel<PostSynchronizationEffect>(Channel.BUFFERED)
    val effects = effectChannel.receiveAsFlow()

    init {
        observeSession()
        observePlayerState()
        postPlayerManager.closePlayer()
        load()
    }

    fun retryLoad() {
        load()
    }

    fun onFocusPrevious() {
        moveFocusBy(delta = -1)
    }

    fun onFocusNext() {
        moveFocusBy(delta = 1)
    }

    fun onFocusLine(position: Int) {
        _uiState.update { current ->
            current.copy(
                focusedLinePosition = position.coerceIn(
                    0,
                    (current.syncableLines.lastIndex).coerceAtLeast(0)
                ),
            )
        }
    }

    fun onFocusFirstInvalidLine() {
        val state = _uiState.value
        val position = firstInvalidLinePosition(
            syncableLines = state.syncableLines,
            validationIssues = state.validationIssues,
        ) ?: return
        onFocusLine(position)
    }

    fun onTogglePlayback() {
        val post = _uiState.value.post ?: return
        postPlayerManager.togglePostPlayback(post)
    }

    fun onSeekToPercent(percent: Float) {
        val state = _uiState.value
        val post = state.post ?: return
        if (state.isCurrentPostActive) {
            postPlayerManager.seekToPercent(percent)
            return
        }

        val durationMs = (state.durationSecondsOrPostFallback * 1_000f).toLong()
        val targetMs = ((durationMs * percent.coerceIn(0f, 100f)) / 100f).toLong()
        postPlayerManager.playPost(post = post, startPositionMs = targetMs)
    }

    fun onSeekBackward() {
        postPlayerManager.seekBy(deltaMs = -5_000L)
    }

    fun onSeekForward() {
        postPlayerManager.seekBy(deltaMs = 5_000L)
    }

    fun onJumpToLine(lineIndex: Int) {
        val state = _uiState.value
        val post = state.post ?: return
        val timestampMs = state.localSynchronization[lineIndex] ?: return
        val durationMs = (state.durationSecondsOrPostFallback * 1_000f).toLong()
        if (durationMs <= 0L) {
            return
        }
        if (state.isCurrentPostActive) {
            val percent = (timestampMs.toFloat() / durationMs.toFloat()) * 100f
            postPlayerManager.seekToPercent(percent)
        } else {
            postPlayerManager.playPost(post = post, startPositionMs = timestampMs.toLong())
        }
    }

    fun onStampCurrentLine() {
        val state = _uiState.value
        val post = state.post ?: return
        val focusedLine = state.focusedLine ?: return

        viewModelScope.launch {
            if (focusedLine.isLocked) {
                moveFocusBy(delta = 1)
                return@launch
            }

            if (!state.isCurrentPostActive) {
                postPlayerManager.playPost(post)
                delay(START_PLAYBACK_DELAY_MS)
            }

            val timestampMs = floor(postPlayerManager.uiState.value.currentTimeSeconds * 1_000f)
                .toInt()
                .coerceAtLeast(0)
            val updatedSynchronization = state.localSynchronization.toMutableMap().apply {
                put(focusedLine.lineIndex, timestampMs)
            }
            val validationIssues = validateSynchronization(
                syncableLines = state.syncableLines,
                localSynchronization = updatedSynchronization,
                durationSeconds = post.audioDurationSeconds,
                includeMissing = state.hasAttemptedSave,
            )
            val nextFocusedPosition =
                (focusedLine.position + 1).coerceAtMost(state.syncableLines.lastIndex)

            _uiState.update {
                it.copy(
                    localSynchronization = updatedSynchronization.toMap(),
                    focusedLinePosition = nextFocusedPosition,
                    hasChanges = true,
                    saveError = null,
                    validationIssues = validationIssues,
                )
            }
            effectChannel.send(PostSynchronizationEffect.ShowStampFeedback)
        }
    }

    fun onClearLine(lineIndex: Int) {
        val state = _uiState.value
        val line = state.syncableLines.firstOrNull { it.lineIndex == lineIndex } ?: return
        if (line.isLocked || !state.localSynchronization.containsKey(lineIndex)) {
            return
        }

        val updatedSynchronization = state.localSynchronization.toMutableMap().apply {
            remove(lineIndex)
        }
        _uiState.update {
            it.copy(
                localSynchronization = updatedSynchronization.toMap(),
                hasChanges = true,
                saveError = null,
                validationIssues = validateSynchronization(
                    syncableLines = state.syncableLines,
                    localSynchronization = updatedSynchronization,
                    durationSeconds = state.post?.audioDurationSeconds,
                    includeMissing = state.hasAttemptedSave,
                ),
            )
        }
    }

    fun onClearAllConfirmed() {
        val state = _uiState.value
        val resetSynchronization = buildMap {
            state.syncableLines.firstOrNull()?.takeIf(SyncableLineUiModel::isLocked)
                ?.let { lockedLine ->
                    put(lockedLine.lineIndex, 0)
                }
        }

        _uiState.update {
            it.copy(
                localSynchronization = resetSynchronization,
                focusedLinePosition = initialFocusedLinePosition(
                    syncableLines = state.syncableLines,
                    localSynchronization = resetSynchronization,
                ),
                hasChanges = true,
                saveError = null,
                validationIssues = validateSynchronization(
                    syncableLines = state.syncableLines,
                    localSynchronization = resetSynchronization,
                    durationSeconds = state.post?.audioDurationSeconds,
                    includeMissing = state.hasAttemptedSave,
                ),
            )
        }
    }

    fun onSaveClick() {
        val state = _uiState.value
        val post = state.post ?: return

        val validationIssues = validateSynchronization(
            syncableLines = state.syncableLines,
            localSynchronization = state.localSynchronization,
            durationSeconds = post.audioDurationSeconds,
            includeMissing = true,
        )
        _uiState.update {
            it.copy(
                hasAttemptedSave = true,
                validationIssues = validationIssues,
                saveError = null,
            )
        }
        if (validationIssues.isNotEmpty() || state.syncableLines.any { line ->
                !state.localSynchronization.containsKey(line.lineIndex)
            }
        ) {
            onFocusFirstInvalidLine()
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isSaving = true,
                    saveError = null,
                )
            }
            runCatching {
                postRepository.updatePostTextSynchronization(
                    postId = post.postId,
                    payload = buildSynchronizationPayload(state.localSynchronization),
                )
            }.onSuccess { updatedPost ->
                postPlayerManager.closePlayer()
                _uiState.update {
                    it.copy(
                        isSaving = false,
                        post = updatedPost,
                        hasChanges = false,
                        validationIssues = emptyMap(),
                    )
                }
                effectChannel.send(PostSynchronizationEffect.NavigateBack)
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        isSaving = false,
                        saveError = error,
                    )
                }
            }
        }
    }

    fun onExitConfirmed() {
        postPlayerManager.closePlayer()
        viewModelScope.launch {
            effectChannel.send(PostSynchronizationEffect.NavigateBack)
        }
    }

    private fun load() {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isLoading = true,
                    loadError = null,
                    saveError = null,
                )
            }

            runCatching {
                val post = postRepository.getPost(postId)
                val subscription = paymentRepository.getSubscription()
                post to subscription
            }.onSuccess { (post, subscription) ->
                applyLoadedPost(
                    post = post,
                    currentUserId = authRepository.session.value?.user?.userId,
                    isPremium = subscription?.isPremium == true,
                )
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        loadError = error,
                    )
                }
            }
        }
    }

    private fun applyLoadedPost(
        post: Post,
        currentUserId: Long?,
        isPremium: Boolean,
    ) {
        val syncableLines = buildSyncableLines(post.text.orEmpty())
        val localSynchronization = seedSynchronization(
            initialSynchronization = post.textSynchronization,
            syncableLines = syncableLines,
        )
        _uiState.update {
            it.copy(
                isLoading = false,
                post = post,
                currentUserId = currentUserId,
                isPremium = isPremium,
                blockingReason = resolveBlockingReason(
                    post = post,
                    currentUserId = currentUserId,
                    isPremium = isPremium,
                ),
                loadError = null,
                syncableLines = syncableLines,
                localSynchronization = localSynchronization,
                focusedLinePosition = initialFocusedLinePosition(
                    syncableLines = syncableLines,
                    localSynchronization = localSynchronization,
                ),
                hasChanges = false,
                hasAttemptedSave = false,
                validationIssues = validateSynchronization(
                    syncableLines = syncableLines,
                    localSynchronization = localSynchronization,
                    durationSeconds = post.audioDurationSeconds,
                    includeMissing = false,
                ),
            )
        }
    }

    private fun moveFocusBy(delta: Int) {
        _uiState.update { current ->
            val currentPosition = current.focusedLinePosition ?: 0
            val nextPosition = (currentPosition + delta).coerceIn(
                0,
                current.syncableLines.lastIndex.coerceAtLeast(0)
            )
            current.copy(focusedLinePosition = nextPosition)
        }
    }

    private fun observeSession() {
        viewModelScope.launch {
            authRepository.session.collect { session ->
                val currentUserId = session?.user?.userId
                _uiState.update { current ->
                    current.copy(
                        currentUserId = currentUserId,
                        blockingReason = current.post?.let { post ->
                            resolveBlockingReason(
                                post = post,
                                currentUserId = currentUserId,
                                isPremium = current.isPremium,
                            )
                        },
                    )
                }
            }
        }
    }

    private fun observePlayerState() {
        viewModelScope.launch {
            postPlayerManager.uiState.collect { playerState ->
                _uiState.update {
                    it.copy(
                        activePostId = playerState.activePost?.postId,
                        isPlaying = playerState.isPlaying,
                        currentTimeSeconds = playerState.currentTimeSeconds,
                        durationSeconds = playerState.durationSeconds,
                    )
                }
            }
        }
    }

    @AssistedFactory
    interface Factory {
        fun create(postId: Long): PostSynchronizationViewModel
    }

    companion object {
        private const val START_PLAYBACK_DELAY_MS = 100L
    }
}
