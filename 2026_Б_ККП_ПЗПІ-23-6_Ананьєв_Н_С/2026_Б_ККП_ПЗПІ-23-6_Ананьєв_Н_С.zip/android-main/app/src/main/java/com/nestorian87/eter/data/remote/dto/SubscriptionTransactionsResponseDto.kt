package com.nestorian87.eter.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class SubscriptionTransactionsResponseDto(
    val items: List<SubscriptionTransactionDto>,
    val total: Int,
    val offset: Int,
)
