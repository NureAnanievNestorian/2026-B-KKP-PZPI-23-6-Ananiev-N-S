package com.nestorian87.eter.ui.components.layout

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nestorian87.eter.R
import com.nestorian87.eter.domain.model.Post
import com.nestorian87.eter.domain.model.PostAuthor
import com.nestorian87.eter.domain.model.PostStatus
import com.nestorian87.eter.ui.components.audio.EterPlayButton
import com.nestorian87.eter.ui.components.feedback.shimmer
import com.nestorian87.eter.ui.theme.EditorialCardShape
import com.nestorian87.eter.ui.theme.EterPreview
import com.nestorian87.eter.ui.theme.EterScreenPreviews
import com.nestorian87.eter.ui.theme.EterSpacing
import com.nestorian87.eter.ui.theme.PillShape
import com.nestorian87.eter.ui.theme.TouchShape
import com.nestorian87.eter.util.toCompactCountText
import com.nestorian87.eter.util.toDurationText
import com.nestorian87.eter.util.toRelativeAgeText

enum class PostCardStyle {
    Card,
    EditorialRow,
}

@Composable
fun PostCard(
    item: PostCardUiModel,
    isLikePending: Boolean,
    isPlaybackActive: Boolean,
    isPlaying: Boolean,
    onToggleLike: () -> Unit,
    onTogglePlayback: () -> Unit,
    onOpenPost: () -> Unit,
    onOpenComments: () -> Unit,
    modifier: Modifier = Modifier,
    style: PostCardStyle = PostCardStyle.Card,
    onOpenAuthor: (() -> Unit)? = null,
    onCategoryClick: ((Long) -> Unit)? = null,
) {
    when (style) {
        PostCardStyle.Card -> PoemPostCard(
            item = item,
            isLikePending = isLikePending,
            isPlaybackActive = isPlaybackActive,
            isPlaying = isPlaying,
            onToggleLike = onToggleLike,
            onTogglePlayback = onTogglePlayback,
            onOpenPost = onOpenPost,
            onOpenComments = onOpenComments,
            modifier = modifier,
            onOpenAuthor = onOpenAuthor,
            onCategoryClick = onCategoryClick,
        )

        PostCardStyle.EditorialRow -> EditorialPostRow(
            item = item,
            isLikePending = isLikePending,
            isPlaybackActive = isPlaybackActive,
            isPlaying = isPlaying,
            onToggleLike = onToggleLike,
            onTogglePlayback = onTogglePlayback,
            onOpenPost = onOpenPost,
            onOpenComments = onOpenComments,
            modifier = modifier,
            onOpenAuthor = onOpenAuthor,
        )
    }
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
private fun PoemPostCard(
    item: PostCardUiModel,
    isLikePending: Boolean,
    isPlaybackActive: Boolean,
    isPlaying: Boolean,
    onToggleLike: () -> Unit,
    onTogglePlayback: () -> Unit,
    onOpenPost: () -> Unit,
    onOpenComments: () -> Unit,
    modifier: Modifier = Modifier,
    onOpenAuthor: (() -> Unit)? = null,
    onCategoryClick: ((Long) -> Unit)? = null,
) {
    val post = item.post

    Surface(
        modifier = modifier.fillMaxWidth(),
        onClick = onOpenPost,
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.98f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.14f)),
        shape = EditorialCardShape,
        shadowElevation = 3.dp,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = EterSpacing.medium, vertical = EterSpacing.medium),
            verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
        ) {
            UserPostHeader(
                authorName = post.author?.name ?: stringResource(R.string.post_unknown_author),
                authorUsername = post.author?.username,
                authorPhotoUrl = post.author?.photo,
                createdAt = post.createdAt.toRelativeAgeText(),
                modifier = Modifier.fillMaxWidth(),
                onOpenAuthor = onOpenAuthor,
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(EterSpacing.small),
                verticalAlignment = Alignment.Top,
            ) {
                PoemTitleBlock(
                    title = post.title.orEmpty().ifBlank { stringResource(R.string.post_untitled) },
                    originalAuthor = post.originAuthorName,
                    excerpt = post.text.takeUnless { it.isNullOrBlank() } ?: post.description,
                    showPlayingState = isPlaybackActive,
                    nowPlayingAsPill = true,
                    modifier = Modifier.weight(1f),
                )
                CompactPlayButton(
                    isPlaying = isPlaying,
                    isActive = isPlaybackActive,
                    onClick = onTogglePlayback,
                )
            }

            HorizontalDivider(
                thickness = 0.5.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.18f),
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                PostEngagementRow(
                    isLiked = item.isLiked,
                    isLikePending = isLikePending,
                    likes = post.likesCount.toCompactCountText(),
                    comments = post.commentsCount.toCompactCountText(),
                    listens = post.listens.toCompactCountText(),
                    onToggleLike = onToggleLike,
                    onOpenComments = onOpenComments,
                    modifier = Modifier.weight(1f),
                )

                if (post.categories.isNotEmpty()) {
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
                    ) {
                        post.categories.take(2).forEach { category ->
                            TagChip(
                                name = category.categoryName,
                                onClick = onCategoryClick?.let { callback -> { callback(category.categoryId) } },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
private fun EditorialPostRow(
    item: PostCardUiModel,
    isLikePending: Boolean,
    isPlaybackActive: Boolean,
    isPlaying: Boolean,
    onToggleLike: () -> Unit,
    onTogglePlayback: () -> Unit,
    onOpenPost: () -> Unit,
    onOpenComments: () -> Unit,
    modifier: Modifier = Modifier,
    onOpenAuthor: (() -> Unit)? = null,
) {
    val post = item.post

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onOpenPost),
        verticalArrangement = Arrangement.spacedBy(0.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = EterSpacing.xSmall, vertical = EterSpacing.medium),
            verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
        ) {
            EditorialMetadataRow(
                authorName = post.author?.name ?: stringResource(R.string.post_unknown_author),
                username = post.author?.username,
                performerPhotoUrl = post.author?.photo,
                createdAt = post.createdAt.toRelativeAgeText(),
                duration = post.audioDurationSeconds.toDurationText(),
                onOpenAuthor = onOpenAuthor,
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium),
                verticalAlignment = Alignment.Top,
            ) {
                PoemTitleBlock(
                    title = post.title.orEmpty().ifBlank { stringResource(R.string.post_untitled) },
                    originalAuthor = post.originAuthorName,
                    excerpt = post.text.takeUnless { it.isNullOrBlank() } ?: post.description,
                    showPlayingState = false,
                    nowPlayingAsPill = false,
                    modifier = Modifier.weight(1f),
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom,
            ) {
                PostEngagementRow(
                    isLiked = item.isLiked,
                    isLikePending = isLikePending,
                    likes = post.likesCount.toCompactCountText(),
                    comments = post.commentsCount.toCompactCountText(),
                    listens = post.listens.toCompactCountText(),
                    onToggleLike = onToggleLike,
                    onOpenComments = onOpenComments,
                    showListens = false,
                    useBackground = false,
                    modifier = Modifier.weight(1f, fill = false),
                )

                CompactPlayButton(
                    isPlaying = isPlaying,
                    isActive = isPlaybackActive,
                    size = 42.dp,
                    onClick = onTogglePlayback,
                )
            }
        }

        HorizontalDivider(
            modifier = Modifier.padding(horizontal = EterSpacing.xSmall),
            thickness = 0.5.dp,
            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.18f),
        )
    }
}

@Composable
private fun UserPostHeader(
    authorName: String,
    authorUsername: String?,
    authorPhotoUrl: String?,
    createdAt: String,
    modifier: Modifier = Modifier,
    onOpenAuthor: (() -> Unit)? = null,
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(EterSpacing.small),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AuthorAvatar(
            name = authorName,
            photoUrl = authorPhotoUrl,
            size = 40.dp,
            modifier = if (onOpenAuthor != null) {
                Modifier.clickable(onClick = onOpenAuthor)
            } else {
                Modifier
            },
        )
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text(
                text = authorName,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = buildAnnotatedString {
                    authorUsername?.takeIf { it.isNotBlank() }?.let {
                        append("@")
                        append(it)
                        append(" · ")
                    }
                    append(createdAt)
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun PoemTitleBlock(
    title: String,
    originalAuthor: String?,
    excerpt: String?,
    showPlayingState: Boolean,
    nowPlayingAsPill: Boolean,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
    ) {
        if (showPlayingState) {
            if (nowPlayingAsPill) {
                FeedMetaPill(
                    text = stringResource(R.string.feed_now_playing),
                    emphasized = true,
                )
            } else {
                Text(
                    text = stringResource(R.string.feed_now_playing),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
        }
        Text(
            text = title,
            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        originalAuthor?.takeIf { it.isNotBlank() }?.let {
            Text(
                text = it,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Medium),
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.82f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        } ?: Text(
            text = stringResource(R.string.feed_original_work),
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Medium),
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.72f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        excerpt?.trim()?.takeIf { it.isNotBlank() }?.let { preview ->
            EditorialExcerptBlock(excerpt = preview)
        }
    }
}

@Composable
private fun EditorialExcerptBlock(
    excerpt: String,
    modifier: Modifier = Modifier,
) {
    val preview = remember(excerpt) { excerpt.toEditorialPreview() }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
    ) {
        preview.lines.forEach { line ->
            Text(
                text = line,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun CompactPlayButton(
    isPlaying: Boolean,
    isActive: Boolean,
    size: Dp = 52.dp,
    onClick: () -> Unit,
) {
    EterPlayButton(
        isPlaying = isPlaying,
        isActive = isActive,
        size = size,
        onClick = onClick,
    )
}

@Composable
private fun EditorialMetadataRow(
    authorName: String,
    username: String?,
    performerPhotoUrl: String?,
    createdAt: String,
    duration: String,
    modifier: Modifier = Modifier,
    onOpenAuthor: (() -> Unit)? = null,
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AuthorAvatar(
            name = authorName,
            photoUrl = performerPhotoUrl,
            size = 24.dp,
            modifier = if (onOpenAuthor != null) {
                Modifier.clickable(onClick = onOpenAuthor)
            } else {
                Modifier
            },
        )
        Text(
            modifier = Modifier.weight(1f),
            text = buildAnnotatedString {
                username?.takeIf { it.isNotBlank() }?.let {
                    pushStyle(
                        SpanStyle(
                            fontWeight = FontWeight.Medium,
                        ),
                    )
                    append("@$it")
                    pop()
                } ?: append(authorName)
                append(" · ")
                append(createdAt)
                append(" · ")
                append(duration)
            },
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.74f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun PostEngagementRow(
    isLiked: Boolean,
    isLikePending: Boolean,
    likes: String,
    comments: String,
    listens: String,
    onToggleLike: () -> Unit,
    onOpenComments: () -> Unit,
    modifier: Modifier = Modifier,
    showListens: Boolean = true,
    useBackground: Boolean = true,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CompactStat(
            icon = if (isLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
            text = likes,
            contentDescription = stringResource(R.string.feed_like_post),
            tint = if (isLiked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            textColor = if (isLiked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            enabled = !isLikePending,
            useBackground = useBackground,
            onClick = onToggleLike,
        )
        CompactStat(
            icon = Icons.Rounded.ChatBubbleOutline,
            text = comments,
            contentDescription = stringResource(R.string.feed_open_comments),
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            textColor = MaterialTheme.colorScheme.onSurfaceVariant,
            useBackground = useBackground,
            onClick = onOpenComments,
        )
        if (showListens) {
            CompactStat(
                icon = Icons.Rounded.Headphones,
                text = listens,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.82f),
                textColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.82f),
            )
        }
    }
}

@Composable
private fun FeedMetaPill(
    text: String,
    emphasized: Boolean = false,
) {
    Surface(
        color = if (emphasized) {
            MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
        } else {
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.18f)
        },
        shape = PillShape,
        border = BorderStroke(
            1.dp,
            if (emphasized) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.24f)
            } else {
                MaterialTheme.colorScheme.outline.copy(alpha = 0.18f)
            },
        ),
    ) {
        Text(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            text = text,
            style = MaterialTheme.typography.labelMedium,
            color = if (emphasized) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
        )
    }
}

@Composable
private fun CompactStat(
    icon: ImageVector,
    text: String,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    textColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    enabled: Boolean = true,
    useBackground: Boolean = true,
    onClick: (() -> Unit)? = null,
) {
    val scale by animateFloatAsState(
        targetValue = if (enabled) 1f else 0.98f,
        animationSpec = tween(180),
        label = "compact_stat_scale",
    )
    val background by animateColorAsState(
        targetValue = if (onClick != null && useBackground) {
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.14f)
        } else {
            Color.Transparent
        },
        animationSpec = tween(180),
        label = "compact_stat_background",
    )

    Row(
        modifier = modifier
            .scale(scale)
            .clip(TouchShape)
            .background(background)
            .then(
                if (onClick != null) {
                    Modifier.clickable(
                        enabled = enabled,
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onClick,
                    )
                } else {
                    Modifier
                },
            )
            .padding(horizontal = 4.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            modifier = Modifier.size(18.dp),
            tint = tint,
        )
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = textColor,
        )
    }
}

@Composable
fun PostCardSkeleton(
    modifier: Modifier = Modifier,
    style: PostCardStyle = PostCardStyle.Card,
) {
    when (style) {
        PostCardStyle.Card -> Surface(
            modifier = modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.72f),
            shape = EditorialCardShape,
            border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = EterSpacing.medium, vertical = EterSpacing.medium),
                verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(EterSpacing.small),
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .shimmer(),
                    )
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Box(
                            modifier = Modifier
                                .width(140.dp)
                                .height(12.dp)
                                .shimmer()
                        )
                        Box(
                            modifier = Modifier
                                .width(110.dp)
                                .height(10.dp)
                                .shimmer()
                        )
                    }
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.84f)
                                .height(28.dp)
                                .shimmer()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.62f)
                                .height(18.dp)
                                .shimmer()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(58.dp)
                                .shimmer()
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .shimmer(),
                    )
                }
                HorizontalDivider(
                    thickness = 0.5.dp,
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.24f),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(EterSpacing.small)) {
                    Box(
                        modifier = Modifier
                            .width(58.dp)
                            .height(20.dp)
                            .shimmer()
                    )
                    Box(
                        modifier = Modifier
                            .width(66.dp)
                            .height(20.dp)
                            .shimmer()
                    )
                    Box(
                        modifier = Modifier
                            .width(54.dp)
                            .height(20.dp)
                            .shimmer()
                    )
                }
            }
        }

        PostCardStyle.EditorialRow -> Column(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = EterSpacing.medium),
            verticalArrangement = Arrangement.spacedBy(0.dp),
        ) {
            Column(
                modifier = Modifier.padding(horizontal = EterSpacing.xSmall),
                verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium),
                    verticalAlignment = Alignment.Top,
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
                    ) {
                        Box(
                            modifier = Modifier
                                .width(82.dp)
                                .height(10.dp)
                                .shimmer()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.88f)
                                .height(24.dp)
                                .shimmer()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.56f)
                                .height(14.dp)
                                .shimmer()
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .shimmer(),
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(0.72f)
                                    .height(12.dp)
                                    .shimmer()
                            )
                        }
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.94f)
                                .height(16.dp)
                                .shimmer()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.76f)
                                .height(16.dp)
                                .shimmer()
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .shimmer(),
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium)) {
                    Box(
                        modifier = Modifier
                            .width(48.dp)
                            .height(16.dp)
                            .shimmer()
                    )
                    Box(
                        modifier = Modifier
                            .width(48.dp)
                            .height(16.dp)
                            .shimmer()
                    )
                    Box(
                        modifier = Modifier
                            .width(48.dp)
                            .height(16.dp)
                            .shimmer()
                    )
                }
            }
            HorizontalDivider(
                modifier = Modifier.padding(horizontal = EterSpacing.xSmall),
                thickness = 0.5.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.18f),
            )
        }
    }
}

@Composable
internal fun TagChip(name: String, onClick: (() -> Unit)? = null) {
    val content: @Composable () -> Unit = {
        Text(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            text = "#${name.lowercase()}",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.88f),
        )
    }
    val chipColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)
    val chipBorder = BorderStroke(0.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.18f))
    if (onClick != null) {
        Surface(
            shape = PillShape,
            color = chipColor,
            border = chipBorder,
            onClick = onClick,
            content = content,
        )
    } else {
        Surface(
            shape = PillShape,
            color = chipColor,
            border = chipBorder,
            content = content,
        )
    }
}

@Composable
internal fun CategoryChip(name: String, onClick: (() -> Unit)? = null) {
    TagChip(name = name, onClick = onClick)
}

private data class EditorialPreview(
    val lines: List<String>,
)

private fun String.toEditorialPreview(): EditorialPreview {
    val normalized = replace('\r', '\n')
        .lines()
        .map { it.trim() }
        .filter { it.isNotBlank() }

    val visibleLines = normalized.take(PREVIEW_LINE_COUNT).ifEmpty {
        listOf(this)
    }
    val isTruncated = normalized.size > PREVIEW_LINE_COUNT
    val lines = if (isTruncated && visibleLines.isNotEmpty()) {
        visibleLines.dropLast(1) + visibleLines.last().trimEnd('.', ',', ' ', '…') + "…"
    } else {
        visibleLines
    }

    return EditorialPreview(lines = lines)
}

private const val PREVIEW_LINE_COUNT = 3

@EterScreenPreviews
@Composable
private fun PostCardPreview() {
    EterPreview {
        PostCard(
            item = PostCardUiModel(
                post = Post(
                    postId = 1L,
                    title = "Вони навіть можуть жити в різних містах",
                    description = "Вони навіть можуть жити в різних містах, і в своїх розмовах не торкатися головного.",
                    text = "Вони навіть можуть жити в різних містах,\nі в своїх розмовах не торкатися головного.",
                    audioFileName = null,
                    audioFileUrl = null,
                    audioDurationSeconds = 112,
                    status = PostStatus.PUBLISHED,
                    listens = 52,
                    likesCount = 14,
                    isLiked = true,
                    commentsCount = 8,
                    originAuthorName = "Сергій Жадан",
                    textSynchronization = emptyList(),
                    categories = emptyList(),
                    authorId = 2L,
                    author = PostAuthor(
                        userId = 2L,
                        name = "Nestorian",
                        username = "nestorianananiev",
                        photo = null,
                        isPremium = false,
                    ),
                    createdAt = "2026-05-18T11:30:00.000Z",
                    updatedAt = "",
                ),
                isLiked = true,
            ),
            isLikePending = false,
            isPlaybackActive = true,
            isPlaying = false,
            onToggleLike = {},
            onTogglePlayback = {},
            onOpenPost = {},
            onOpenComments = {},
        )
    }
}
