package com.nestorian87.eter.ui.screens.profile

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Sort
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nestorian87.eter.R
import com.nestorian87.eter.domain.model.Post
import com.nestorian87.eter.domain.model.ProfilePostsAuthorType
import com.nestorian87.eter.domain.model.ProfilePostsSortBy
import com.nestorian87.eter.domain.model.SortOrder
import com.nestorian87.eter.ui.app.PostPlayerViewModel
import com.nestorian87.eter.ui.components.buttons.PrimaryActionButton
import com.nestorian87.eter.ui.components.dialog.EterBottomSheet
import com.nestorian87.eter.ui.components.dialog.EterSheetTitle
import com.nestorian87.eter.ui.components.feedback.EterLoadingIndicator
import com.nestorian87.eter.ui.components.layout.AuthorAvatar
import com.nestorian87.eter.ui.components.layout.PostCardStyle
import com.nestorian87.eter.ui.screens.feed.PostListVisualStyle
import com.nestorian87.eter.ui.screens.feed.postListItems
import com.nestorian87.eter.ui.theme.EditorialPanelShape
import com.nestorian87.eter.ui.theme.EterPreview
import com.nestorian87.eter.ui.theme.EterScreenPreviews
import com.nestorian87.eter.ui.theme.EterSpacing
import com.nestorian87.eter.ui.theme.TouchShape
import com.nestorian87.eter.util.toCompactCountText
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    modifier: Modifier = Modifier,
    profileUserId: Long? = null,
    profileUsername: String? = null,
    onOpenPost: (Long) -> Unit = { _ -> },
    onOpenComments: (Long) -> Unit = { _ -> },
    onOpenDraft: (Long) -> Unit = { _ -> },
    onOpenAuthor: (Long?, String?) -> Unit = { _, _ -> },
    onBack: () -> Unit = {},
    onOpenSettings: () -> Unit = {},
    onOpenFollowers: (Long) -> Unit = { _ -> },
    onOpenFollowing: (Long) -> Unit = { _ -> },
    onLoginRequested: () -> Unit = {},
    onOpenOwnProfile: () -> Unit = {},
    viewModel: ProfileViewModel = hiltViewModel<ProfileViewModel, ProfileViewModel.Factory> { factory ->
        factory.create(profileUserId, profileUsername)
    },
    playerViewModel: PostPlayerViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val playerUiState by playerViewModel.uiState.collectAsStateWithLifecycle()
    val lifecycleOwner = LocalLifecycleOwner.current
    val context = LocalContext.current

    LaunchedEffect(viewModel, context) {
        viewModel.effects.collect { effect ->
            when (effect) {
                ProfileEffect.NavigateToLogin -> onLoginRequested()
                ProfileEffect.NavigateToOwnProfile -> onOpenOwnProfile()
                ProfileEffect.ProfileSaved -> Unit
                is ProfileEffect.ShareProfile -> {
                    val shareIntent = Intent(Intent.ACTION_SEND)
                        .setType("text/plain")
                        .putExtra(Intent.EXTRA_TEXT, effect.url)
                    context.startActivity(
                        Intent.createChooser(
                            shareIntent,
                            context.getString(R.string.profile_share),
                        ),
                    )
                }
            }
        }
    }

    DisposableEffect(viewModel, lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> viewModel.onScreenVisibilityChanged(true)
                Lifecycle.Event.ON_STOP -> viewModel.onScreenVisibilityChanged(false)
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            viewModel.stopDraftsPolling()
        }
    }

    ProfileScreenContent(
        uiState = uiState,
        activePlaybackPostId = playerUiState.activePost?.postId,
        isActivePostPlaying = playerUiState.isPlaying,
        modifier = modifier,
        onRetryProfile = viewModel::onRetryProfile,
        onTabSelected = viewModel::onTabSelected,
        onApplyPublishedFilters = viewModel::applyPublishedFilters,
        onRetryPublished = viewModel::loadPublishedInitial,
        onLoadMorePublished = viewModel::onLoadMorePublished,
        onRetryDrafts = viewModel::loadDraftsInitial,
        onLoadMoreDrafts = viewModel::onLoadMoreDrafts,
        onToggleLike = viewModel::onToggleLike,
        onTogglePlayback = playerViewModel::togglePlayback,
        onOpenPost = onOpenPost,
        onOpenComments = onOpenComments,
        onOpenDraft = onOpenDraft,
        onOpenAuthor = onOpenAuthor,
        onBack = onBack,
        onToggleHeroFollow = viewModel::onToggleHeroFollow,
        onOpenFollowers = onOpenFollowers,
        onOpenFollowing = onOpenFollowing,
        onOpenSettings = onOpenSettings,
        onShareProfile = viewModel::onShareProfileClick,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProfileScreenContent(
    uiState: ProfileUiState,
    activePlaybackPostId: Long?,
    isActivePostPlaying: Boolean,
    onRetryProfile: () -> Unit,
    onTabSelected: (ProfileTab) -> Unit,
    onApplyPublishedFilters: (ProfilePostsAuthorType, ProfilePostsSortBy, SortOrder) -> Unit,
    onRetryPublished: () -> Unit,
    onLoadMorePublished: () -> Unit,
    onRetryDrafts: () -> Unit,
    onLoadMoreDrafts: () -> Unit,
    onToggleLike: (Long) -> Unit,
    onTogglePlayback: (Post) -> Unit,
    onOpenPost: (Long) -> Unit,
    onOpenComments: (Long) -> Unit,
    onOpenDraft: (Long) -> Unit,
    onOpenAuthor: (Long?, String?) -> Unit,
    onBack: () -> Unit,
    onToggleHeroFollow: () -> Unit,
    onOpenFollowers: (Long) -> Unit,
    onOpenFollowing: (Long) -> Unit,
    onOpenSettings: () -> Unit,
    onShareProfile: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var isActionsSheetVisible by remember { mutableStateOf(false) }
    var isPublishedFiltersSheetVisible by remember { mutableStateOf(false) }
    val isDraftsTab = uiState.selectedTab == ProfileTab.DRAFTS && uiState.isOwner
    val emptyTitle = if (isDraftsTab) {
        stringResource(R.string.profile_drafts_empty_title)
    } else {
        stringResource(R.string.profile_posts_empty_title)
    }
    val emptySubtitle = if (isDraftsTab) {
        stringResource(R.string.profile_drafts_empty_subtitle)
    } else {
        stringResource(R.string.profile_posts_empty_subtitle)
    }
    val activeListState = if (uiState.selectedTab == ProfileTab.DRAFTS && uiState.isOwner) {
        uiState.drafts
    } else {
        uiState.published
    }
    val listState = rememberLazyListState()

    LaunchedEffect(
        listState,
        activeListState.items.size,
        activeListState.isInitialLoading,
        activeListState.isLoadingMore,
        activeListState.canLoadMore,
        uiState.selectedTab,
        uiState.isOwner,
    ) {
        if (activeListState.isInitialLoading) {
            return@LaunchedEffect
        }

        snapshotFlow {
            listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index
        }.filterNotNull()
            .distinctUntilChanged()
            .collect { lastVisibleIndex ->
                val triggerIndex = listState.layoutInfo.totalItemsCount - 3
                if (lastVisibleIndex >= triggerIndex && activeListState.canLoadMore && !activeListState.isLoadingMore) {
                    if (uiState.selectedTab == ProfileTab.DRAFTS && uiState.isOwner) {
                        onLoadMoreDrafts()
                    } else {
                        onLoadMorePublished()
                    }
                }
            }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        when {
            uiState.isLoadingProfile && uiState.profileUserId == null && uiState.name.isBlank() -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center,
                ) {
                    EterLoadingIndicator()
                }
            }

            uiState.profileLoadError != null && uiState.name.isBlank() -> {
                ProfileLoadErrorState(
                    onRetry = onRetryProfile,
                    modifier = Modifier.fillMaxSize(),
                )
            }

            else -> {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(0.dp),
                    contentPadding = PaddingValues(
                        start = EterSpacing.medium,
                        end = EterSpacing.medium,
                        top = EterSpacing.medium,
                        bottom = EterSpacing.hero,
                    ),
                ) {
                    item(key = "profile_hero") {
                        ProfileHeroSection(
                            uiState = uiState,
                            onBack = onBack,
                            onToggleHeroFollow = onToggleHeroFollow,
                            onOpenFollowers = onOpenFollowers,
                            onOpenFollowing = onOpenFollowing,
                            onOpenSettings = onOpenSettings,
                            onOpenActions = { isActionsSheetVisible = true },
                            modifier = Modifier.padding(bottom = EterSpacing.small),
                        )
                    }

                    if (uiState.isOwner) {
                        item(key = "profile_tabs") {
                            ProfileTopTabs(
                                uiState = uiState,
                                onTabSelected = onTabSelected,
                                modifier = Modifier.padding(bottom = EterSpacing.small),
                            )
                        }
                    }

                    item(key = "profile_posts_header") {
                        ProfilePostsSectionHeader(
                            title = if (isDraftsTab) {
                                stringResource(R.string.profile_drafts_title)
                            } else {
                                stringResource(R.string.profile_posts_title)
                            },
                            controlsSummary = if (uiState.selectedTab == ProfileTab.PUBLISHED) {
                                buildProfilePublishedControlsSummary(
                                    selectedAuthorType = uiState.publishedAuthorType,
                                    selectedSortBy = uiState.publishedSortBy,
                                    selectedSortOrder = uiState.publishedSortOrder,
                                )
                            } else {
                                null
                            },
                            onOpenPublishedFilters = if (uiState.selectedTab == ProfileTab.PUBLISHED) {
                                { isPublishedFiltersSheetVisible = true }
                            } else {
                                null
                            },
                            modifier = Modifier.padding(bottom = EterSpacing.small),
                        )
                    }

                    postListItems(
                        listState = activeListState,
                        activePlaybackPostId = activePlaybackPostId,
                        isActivePostPlaying = isActivePostPlaying,
                        emptyTitle = emptyTitle,
                        emptySubtitle = emptySubtitle,
                        postCardStyle = PostCardStyle.EditorialRow,
                        visualStyle = PostListVisualStyle.Editorial,
                        showEmptyRetryButton = false,
                        onRetry = if (isDraftsTab) {
                            onRetryDrafts
                        } else {
                            onRetryPublished
                        },
                        onToggleLike = onToggleLike,
                        onTogglePlayback = onTogglePlayback,
                        onOpenPost = if (isDraftsTab) {
                            onOpenDraft
                        } else {
                            onOpenPost
                        },
                        onOpenComments = if (isDraftsTab) {
                            onOpenDraft
                        } else {
                            onOpenComments
                        },
                        onOpenAuthor = { post ->
                            onOpenAuthor(
                                post.author?.userId ?: post.authorId,
                                post.author?.username,
                            )
                        },
                    )
                }
            }
        }
    }

    if (isActionsSheetVisible && !uiState.isOwner) {
        ProfileActionsSheet(
            onDismiss = { isActionsSheetVisible = false },
            onShareProfile = {
                isActionsSheetVisible = false
                onShareProfile()
            },
        )
    }

    if (isPublishedFiltersSheetVisible && uiState.selectedTab == ProfileTab.PUBLISHED) {
        ProfilePublishedFiltersSheet(
            selectedAuthorType = uiState.publishedAuthorType,
            selectedSortBy = uiState.publishedSortBy,
            selectedSortOrder = uiState.publishedSortOrder,
            onDismiss = { },
            onApply = { authorType, sortBy, sortOrder ->
                onApplyPublishedFilters(authorType, sortBy, sortOrder)
            },
        )
    }
}

@Composable
private fun ProfileHeroSection(
    uiState: ProfileUiState,
    onBack: () -> Unit,
    onToggleHeroFollow: () -> Unit,
    onOpenFollowers: (Long) -> Unit,
    onOpenFollowing: (Long) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenActions: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val uriHandler = LocalUriHandler.current

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
    ) {
        ProfileTopBar(
            isOwner = uiState.isOwner,
            onBack = onBack,
            onOpenSettings = onOpenSettings,
            onOpenActions = onOpenActions,
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = EterSpacing.small, vertical = EterSpacing.xSmall),
            verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(EterSpacing.large),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AuthorAvatar(
                    name = uiState.name.ifBlank { stringResource(R.string.profile_default_name) },
                    photoUrl = uiState.photo,
                    size = 92.dp,
                )
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(EterSpacing.small),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = uiState.name.ifBlank { stringResource(R.string.profile_default_name) },
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false),
                        )
                        if (uiState.isPremium) {
                            PremiumBadge()
                        }
                    }
                    Text(
                        text = stringResource(R.string.profile_username_format, uiState.username),
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            uiState.bio?.takeIf { it.isNotBlank() }?.let { bio ->
                Text(
                    text = bio,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.9f),
                )
            }

            uiState.link?.takeIf { it.isNotBlank() }?.let { link ->
                Row(
                    modifier = Modifier
                        .clip(MaterialTheme.shapes.small)
                        .clickable { uriHandler.openUri(link) }
                        .padding(vertical = EterSpacing.xxSmall),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Link,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        text = link,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            ProfileStatsRow(
                uiState = uiState,
                onOpenFollowers = onOpenFollowers,
                onOpenFollowing = onOpenFollowing,
            )
        }

        if (!uiState.isOwner) {
            PrimaryActionButton(
                text = when {
                    !uiState.isAuthenticated -> stringResource(R.string.auth_login_short_cta)
                    uiState.isFollowActionLoading -> stringResource(R.string.profile_following_cta)
                    uiState.isFollowing -> stringResource(R.string.profile_unfollow_cta)
                    else -> stringResource(R.string.profile_follow_cta)
                },
                modifier = Modifier.fillMaxWidth(),
                isLoading = uiState.isFollowActionLoading,
                onClick = onToggleHeroFollow,
            )
        }

        HorizontalDivider(
            thickness = 0.5.dp,
            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.16f),
        )
    }
}

@Composable
private fun ProfileTopBar(
    isOwner: Boolean,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenActions: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ProfileHeaderIconButton(
            icon = Icons.AutoMirrored.Rounded.ArrowBack,
            onClick = onBack,
        )

        if (isOwner) {
            ProfileHeaderIconButton(
                icon = Icons.Rounded.Settings,
                onClick = onOpenSettings,
            )
        } else {
            ProfileHeaderIconButton(
                icon = Icons.Rounded.MoreVert,
                onClick = onOpenActions,
            )
        }
    }
}

@Composable
private fun ProfileHeaderIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    iconTint: Color = MaterialTheme.colorScheme.onSurface,
) {
    Surface(
        modifier = Modifier.size(44.dp),
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.72f),
        onClick = onClick,
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
            )
        }
    }
}

@Composable
private fun PremiumBadge() {
    Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
    ) {
        Text(
            text = stringResource(R.string.profile_premium_badge),
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
        )
    }
}

@Composable
private fun ProfileStatsRow(
    uiState: ProfileUiState,
    onOpenFollowers: (Long) -> Unit,
    onOpenFollowing: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    val profileUserId = uiState.profileUserId

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ProfileStatItem(
            label = stringResource(R.string.profile_stat_posts),
            value = uiState.postsCount.toCompactCountText(),
            modifier = Modifier.weight(1f),
        )
        VerticalStatDivider()
        ProfileStatItem(
            label = stringResource(R.string.followers),
            value = uiState.followersCount.toCompactCountText(),
            modifier = Modifier.weight(1f),
            onClick = profileUserId?.let { userId ->
                { onOpenFollowers(userId) }
            },
        )
        VerticalStatDivider()
        ProfileStatItem(
            label = stringResource(R.string.following),
            value = uiState.followingCount.toCompactCountText(),
            modifier = Modifier.weight(1f),
            onClick = profileUserId?.let { userId ->
                { onOpenFollowing(userId) }
            },
        )
    }
}

@Composable
private fun ProfileStatItem(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
) {
    Column(
        modifier = modifier
            .clip(MaterialTheme.shapes.small)
            .clickable(enabled = onClick != null) { onClick?.invoke() }
            .padding(horizontal = EterSpacing.xSmall, vertical = EterSpacing.small),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
        )
    }
}

@Composable
private fun VerticalStatDivider() {
    Box(
        modifier = Modifier
            .width(1.dp)
            .height(32.dp)
            .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.16f)),
    )
}

@Composable
private fun ProfileSectionDivider(modifier: Modifier = Modifier) {
    HorizontalDivider(
        modifier = modifier,
        thickness = 0.5.dp,
        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.16f),
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProfileTopTabs(
    uiState: ProfileUiState,
    onTabSelected: (ProfileTab) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
    ) {
        PrimaryTabRow(
            selectedTabIndex = if (uiState.selectedTab == ProfileTab.PUBLISHED) 0 else 1,
            containerColor = Color.Transparent,
            divider = {
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.fillMaxWidth(),
                    height = 0.5.dp,
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.16f),
                )
            },
        ) {
            Tab(
                selected = uiState.selectedTab == ProfileTab.PUBLISHED,
                onClick = { onTabSelected(ProfileTab.PUBLISHED) },
                text = { Text(text = stringResource(R.string.profile_tab_posts)) },
            )
            if (uiState.isOwner) {
                Tab(
                    selected = uiState.selectedTab == ProfileTab.DRAFTS,
                    onClick = { onTabSelected(ProfileTab.DRAFTS) },
                    text = { Text(text = stringResource(R.string.profile_tab_drafts)) },
                )
            }
        }
        ProfileSectionDivider()
    }
}

@Composable
private fun ProfilePostsSectionHeader(
    title: String,
    controlsSummary: String?,
    onOpenPublishedFilters: (() -> Unit)?,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface,
            )
            onOpenPublishedFilters?.let { onOpenFilters ->
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.36f),
                    onClick = onOpenFilters,
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Outlined.Sort,
                            contentDescription = stringResource(R.string.profile_filter_and_sort),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp),
                        )
                        Text(
                            text = controlsSummary
                                ?: stringResource(R.string.profile_filter_and_sort),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }

        ProfileSectionDivider()
    }
}

@Composable
private fun buildProfilePublishedControlsSummary(
    selectedAuthorType: ProfilePostsAuthorType,
    selectedSortBy: ProfilePostsSortBy,
    selectedSortOrder: SortOrder,
): String {
    val authorLabel = stringResource(
        when (selectedAuthorType) {
            ProfilePostsAuthorType.ALL -> R.string.profile_filter_all
            ProfilePostsAuthorType.AUTHOR -> R.string.profile_filter_author
            ProfilePostsAuthorType.ORIGINAL -> R.string.profile_filter_original
        },
    )
    val sortLabel = stringResource(
        when (selectedSortBy) {
            ProfilePostsSortBy.CREATED_AT -> R.string.profile_sort_date
            ProfilePostsSortBy.LISTENS -> R.string.profile_sort_listens
        },
    )
    val orderArrow = if (selectedSortOrder == SortOrder.DESC) "↓" else "↑"
    return "$authorLabel · $sortLabel $orderArrow"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProfilePublishedFiltersSheet(
    selectedAuthorType: ProfilePostsAuthorType,
    selectedSortBy: ProfilePostsSortBy,
    selectedSortOrder: SortOrder,
    onDismiss: () -> Unit,
    onApply: (ProfilePostsAuthorType, ProfilePostsSortBy, SortOrder) -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var pendingAuthorType by remember(selectedAuthorType) { mutableStateOf(selectedAuthorType) }
    var pendingSortBy by remember(selectedSortBy) { mutableStateOf(selectedSortBy) }
    var pendingSortOrder by remember(selectedSortOrder) { mutableStateOf(selectedSortOrder) }
    val hasChanges = pendingAuthorType != selectedAuthorType ||
            pendingSortBy != selectedSortBy ||
            pendingSortOrder != selectedSortOrder

    EterBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = EterSpacing.medium)
                .padding(bottom = EterSpacing.large)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(EterSpacing.large),
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
            ) {
                EterSheetTitle(text = stringResource(R.string.profile_filter_and_sort))
                Text(
                    text = stringResource(R.string.profile_filter_sheet_description),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            ProfileFilterSectionCard(
                title = stringResource(R.string.profile_filter_author_type),
                content = {
                    listOf(
                        ProfilePostsAuthorType.ALL to R.string.profile_filter_all,
                        ProfilePostsAuthorType.AUTHOR to R.string.profile_filter_author,
                        ProfilePostsAuthorType.ORIGINAL to R.string.profile_filter_original,
                    ).forEach { (type, labelRes) ->
                        ProfileFilterOptionChip(
                            text = stringResource(labelRes),
                            selected = pendingAuthorType == type,
                            onClick = { pendingAuthorType = type },
                        )
                    }
                },
            )
            ProfileFilterSectionCard(
                title = stringResource(R.string.profile_filter_sort_by),
                content = {
                    listOf(
                        ProfilePostsSortBy.CREATED_AT to R.string.profile_sort_date,
                        ProfilePostsSortBy.LISTENS to R.string.profile_sort_listens,
                    ).forEach { (sortBy, labelRes) ->
                        ProfileFilterOptionChip(
                            text = stringResource(labelRes),
                            selected = pendingSortBy == sortBy,
                            onClick = { pendingSortBy = sortBy },
                        )
                    }
                },
            )
            ProfileFilterSectionCard(
                title = stringResource(R.string.profile_filter_sort_order),
                content = {
                    listOf(
                        SortOrder.DESC to R.string.profile_sort_order_desc,
                        SortOrder.ASC to R.string.profile_sort_order_asc,
                    ).forEach { (sortOrder, labelRes) ->
                        ProfileFilterOptionChip(
                            text = stringResource(labelRes),
                            selected = pendingSortOrder == sortOrder,
                            onClick = { pendingSortOrder = sortOrder },
                        )
                    }
                },
            )
            PrimaryActionButton(
                text = stringResource(R.string.profile_filter_apply_cta),
                enabled = hasChanges,
                onClick = {
                    onApply(
                        pendingAuthorType,
                        pendingSortBy,
                        pendingSortOrder,
                    )
                },
            )
        }
    }
}

@Composable
private fun ProfileFilterSectionCard(
    title: String,
    content: @Composable () -> Unit,
) {
    Surface(
        shape = EditorialPanelShape,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.24f),
        border = BorderStroke(
            width = 1.dp,
            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f),
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(EterSpacing.medium),
            verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface,
            )
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(EterSpacing.small),
                verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
            ) {
                content()
            }
        }
    }
}

@Composable
private fun ProfileFilterOptionChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Surface(
        shape = TouchShape,
        color = if (selected) {
            MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
        } else {
            MaterialTheme.colorScheme.surface
        },
        border = BorderStroke(
            width = 1.dp,
            color = if (selected) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.42f)
            } else {
                MaterialTheme.colorScheme.outline.copy(alpha = 0.18f)
            },
        ),
        onClick = onClick,
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Medium),
            color = if (selected) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.onSurface
            },
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProfileActionsSheet(
    onDismiss: () -> Unit,
    onShareProfile: () -> Unit,
) {
    EterBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = EterSpacing.medium, vertical = EterSpacing.small)
                .navigationBarsPadding(),
        ) {
            ProfileSheetActionItem(
                icon = Icons.Rounded.Share,
                title = stringResource(R.string.profile_share),
                onClick = onShareProfile,
            )
        }
    }
}

@Composable
private fun ProfileSheetActionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = EterSpacing.medium, vertical = EterSpacing.medium),
        horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            text = title,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface,
        )
    }
}

@Composable
private fun ProfileLoadErrorState(
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier.padding(EterSpacing.xxLarge),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
            )
            Text(
                text = stringResource(R.string.profile_error_generic),
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
            )
            PrimaryActionButton(
                text = stringResource(R.string.feed_retry),
                onClick = onRetry,
            )
        }
    }
}

@EterScreenPreviews
@Composable
private fun ProfileScreenPreview() {
    EterPreview {
        ProfileScreenContent(
            uiState = ProfileUiState(
                isLoadingProfile = false,
                profileUserId = 42L,
                name = "Ivan Petrenko",
                username = "ivan_petrenko",
                bio = "Reading and recording poetry.",
                link = "https://instagram.com/ivan",
                isPremium = true,
                isOwner = true,
                postsCount = 19,
                followersCount = 128,
                followingCount = 47,
                currentViolationsCount = 1,
                maxViolationsBeforeBlock = 3,
            ),
            activePlaybackPostId = null,
            isActivePostPlaying = false,
            onRetryProfile = {},
            onTabSelected = {},
            onApplyPublishedFilters = { _, _, _ -> },
            onRetryPublished = {},
            onLoadMorePublished = {},
            onRetryDrafts = {},
            onLoadMoreDrafts = {},
            onToggleLike = {},
            onTogglePlayback = {},
            onOpenPost = {},
            onOpenComments = {},
            onOpenDraft = {},
            onOpenAuthor = { _, _ -> },
            onBack = {},
            onToggleHeroFollow = {},
            onOpenFollowers = {},
            onOpenFollowing = {},
            onOpenSettings = {},
            onShareProfile = {},
        )
    }
}
