package com.nestorian87.eter.ui.screens.profile

import com.nestorian87.eter.domain.model.ProfileFollowListItem
import com.nestorian87.eter.domain.model.ProfilePostsAuthorType
import com.nestorian87.eter.domain.model.ProfilePostsSortBy
import com.nestorian87.eter.domain.model.SortOrder
import com.nestorian87.eter.ui.screens.feed.PostListUiState

data class ProfileUiState(
    val isLoadingProfile: Boolean = true,
    val profileLoadError: Throwable? = null,
    val profileUserId: Long? = null,
    val name: String = "",
    val username: String = "",
    val email: String = "",
    val photo: String? = null,
    val bio: String? = null,
    val link: String? = null,
    val isPremium: Boolean = false,
    val isOwner: Boolean = false,
    val isAuthenticated: Boolean = false,
    val isFollowing: Boolean = false,
    val isFollowActionLoading: Boolean = false,
    val postsCount: Int = 0,
    val followersCount: Int = 0,
    val followingCount: Int = 0,
    val currentViolationsCount: Int = 0,
    val maxViolationsBeforeBlock: Int = 0,
    val isLoggingOut: Boolean = false,
    val selectedTab: ProfileTab = ProfileTab.PUBLISHED,
    val publishedAuthorType: ProfilePostsAuthorType = ProfilePostsAuthorType.ALL,
    val publishedSortBy: ProfilePostsSortBy = ProfilePostsSortBy.CREATED_AT,
    val publishedSortOrder: SortOrder = SortOrder.DESC,
    val published: PostListUiState = PostListUiState(
        isInitialLoading = false,
        canLoadMore = false,
    ),
    val drafts: PostListUiState = PostListUiState(
        isInitialLoading = false,
        canLoadMore = false,
    ),
    val isFollowDialogVisible: Boolean = false,
    val followDialog: ProfileFollowDialogUiState = ProfileFollowDialogUiState(),
    val isEditDialogVisible: Boolean = false,
    val editDialog: EditProfileDialogUiState = EditProfileDialogUiState(),
    val isViolationsDialogVisible: Boolean = false,
    val violationsDialog: ProfileViolationsDialogUiState = ProfileViolationsDialogUiState(),
)

enum class ProfileTab {
    PUBLISHED,
    DRAFTS,
}

enum class ProfileFollowListType {
    FOLLOWERS,
    FOLLOWING,
}

data class ProfileFollowDialogUiState(
    val type: ProfileFollowListType = ProfileFollowListType.FOLLOWERS,
    val searchQuery: String = "",
    val items: List<ProfileFollowListItem> = emptyList(),
    val total: Int = 0,
    val nextCursor: String? = null,
    val hasMore: Boolean = false,
    val isInitialLoading: Boolean = false,
    val isLoadingMore: Boolean = false,
    val error: Throwable? = null,
    val pendingUserIds: Set<Long> = emptySet(),
)

data class EditProfileDialogUiState(
    val name: String = "",
    val username: String = "",
    val bio: String = "",
    val link: String = "",
    val currentAvatarUrl: String? = null,
    val selectedAvatarUri: String? = null,
    val removeAvatar: Boolean = false,
    val isSaving: Boolean = false,
    val nameErrorResId: Int? = null,
    val usernameErrorResId: Int? = null,
    val linkErrorResId: Int? = null,
    val avatarErrorResId: Int? = null,
    val formErrorResId: Int? = null,
)

data class ProfileViolationsDialogUiState(
    val isLoading: Boolean = false,
    val error: Throwable? = null,
    val items: List<ProfileViolationUiState> = emptyList(),
)

data class ProfileViolationUiState(
    val complaintId: Long,
    val reasonLabel: String,
    val statusLabel: String,
    val postTitle: String,
    val expiresAt: String? = null,
    val daysRemaining: Long? = null,
)
