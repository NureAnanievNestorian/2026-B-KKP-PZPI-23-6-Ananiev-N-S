package com.nestorian87.eter.ui.components.audio

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Forward5
import androidx.compose.material.icons.rounded.Replay5
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nestorian87.eter.R
import com.nestorian87.eter.domain.model.Post
import com.nestorian87.eter.domain.model.PostAuthor
import com.nestorian87.eter.domain.model.PostStatus
import com.nestorian87.eter.ui.app.PostPlayerViewModel
import com.nestorian87.eter.ui.theme.EterPreview
import com.nestorian87.eter.ui.theme.EterScreenPreviews
import com.nestorian87.eter.ui.theme.EterSpacing

@Composable
fun MiniPlayer(
    modifier: Modifier = Modifier,
    onOpenPost: (Long) -> Unit = {},
    viewModel: PostPlayerViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val activePost = uiState.activePost ?: return
    MiniPlayerContent(
        post = activePost,
        isPlaying = uiState.isPlaying,
        progressPercent = uiState.progressPercent,
        currentTimeSeconds = uiState.currentTimeSeconds,
        durationSeconds = uiState.durationSeconds.takeIf { it > 0f } ?: (activePost.audioDurationSeconds ?: 0).toFloat(),
        onTogglePlayback = { viewModel.togglePlayback(activePost) },
        onSeek = viewModel::seekToPercent,
        onClose = viewModel::closePlayer,
        onOpenPost = { onOpenPost(activePost.postId) },
        modifier = modifier,
    )
}

@Composable
private fun MiniPlayerContent(
    post: Post,
    isPlaying: Boolean,
    progressPercent: Float,
    currentTimeSeconds: Float,
    durationSeconds: Float,
    onTogglePlayback: () -> Unit,
    onSeek: (Float) -> Unit,
    onClose: () -> Unit,
    onOpenPost: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val poemTitle = post.title.orEmpty().ifBlank { stringResource(R.string.post_untitled) }
    val performer =
        post.originAuthorName ?: post.author?.name ?: stringResource(R.string.post_unknown_author)
    val progressFraction = if (durationSeconds > 0f) {
        (currentTimeSeconds / durationSeconds).coerceIn(0f, 1f)
    } else {
        (progressPercent / 100f).coerceIn(0f, 1f)
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.background,
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = EterSpacing.xSmall),
            shape = MiniPlayerShape,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.14f)),
            shadowElevation = 6.dp,
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = EterSpacing.small, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(EterSpacing.small),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                EterPlayButton(
                    isPlaying = isPlaying,
                    isActive = true,
                    size = 44.dp,
                    onClick = onTogglePlayback,
                )
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable(onClick = onOpenPost),
                    verticalArrangement = Arrangement.spacedBy(EterSpacing.xxSmall),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = poemTitle,
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = durationSeconds.toAudioTimeText(),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Text(
                        text = performer,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    AudioWaveformSeekBar(
                        waveform = post.audioAnalysis?.waveform,
                        progressFraction = progressFraction,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(28.dp),
                        onSeek = onSeek,
                    )
                }
                MiniPlayerCloseButton(onClick = onClose)
            }
        }
    }
}

@Composable
private fun MiniPlayerCloseButton(
    onClick: () -> Unit,
) {
    Surface(
        modifier = Modifier.size(EterSpacing.xxLarge),
        onClick = onClick,
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.08f)),
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = Icons.Rounded.Close,
                contentDescription = stringResource(R.string.player_close),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.72f),
                modifier = Modifier.size(14.dp),
            )
        }
    }
}

private val MiniPlayerShape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)

@Composable
fun CompactWaveformPlayerBar(
    currentTimeLabel: String,
    waveform: String?,
    progressFraction: Float,
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    onTogglePlayback: () -> Unit,
    onSeek: (Float) -> Unit,
    onSeekBackward: () -> Unit,
    onSeekForward: () -> Unit,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.background,
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = EterSpacing.medium, vertical = EterSpacing.small),
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.12f)),
            shadowElevation = 4.dp,
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = EterSpacing.small, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(EterSpacing.small),
                verticalAlignment = Alignment.Top,
            ) {
                Column(
                    modifier = Modifier.weight(1f, fill = true),
                    verticalArrangement = Arrangement.spacedBy(EterSpacing.xxSmall),
                ) {
                    AudioWaveformSeekBar(
                        waveform = waveform,
                        progressFraction = progressFraction,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(28.dp),
                        onSeek = onSeek,
                    )
                    Text(
                        text = currentTimeLabel,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(EterSpacing.xxSmall),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(
                        modifier = Modifier.size(28.dp),
                        onClick = onSeekBackward,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Replay5,
                            contentDescription = stringResource(R.string.player_seek_back),
                        )
                    }
                    EterPlayButton(
                        isPlaying = isPlaying,
                        isActive = true,
                        size = 38.dp,
                        onClick = onTogglePlayback,
                    )
                    IconButton(
                        modifier = Modifier.size(28.dp),
                        onClick = onSeekForward,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Forward5,
                            contentDescription = stringResource(R.string.player_seek_forward),
                        )
                    }
                }
            }
        }
    }
}

@EterScreenPreviews
@Composable
private fun MiniPlayerPreview() {
    EterPreview {
        MiniPlayerContent(
            post = Post(
                postId = 1L,
                title = "Вони навіть можуть жити в різних містах",
                description = null,
                text = null,
                audioFileName = null,
                audioFileUrl = null,
                audioDurationSeconds = 112,
                status = PostStatus.PUBLISHED,
                listens = 4,
                likesCount = 4,
                isLiked = false,
                commentsCount = 4,
                originAuthorName = "Сергій Жадан",
                textSynchronization = emptyList(),
                categories = emptyList(),
                authorId = 2L,
                author = PostAuthor(
                    userId = 2L,
                    name = "Єгор Белік",
                    username = "yehor",
                    photo = null,
                    isPremium = false,
                ),
                createdAt = "",
                updatedAt = "",
            ),
            isPlaying = false,
            progressPercent = 22f,
            currentTimeSeconds = 42f,
            durationSeconds = 112f,
            onTogglePlayback = {},
            onSeek = {},
            onClose = {},
            onOpenPost = {},
        )
    }
}
