package com.nestorian87.eter.ui.screens.profile

sealed class SubscriptionManagementEffect {
    data class OpenUrl(
        val url: String,
        val invoiceId: String,
        val paymentType: String,
    ) : SubscriptionManagementEffect()
}
