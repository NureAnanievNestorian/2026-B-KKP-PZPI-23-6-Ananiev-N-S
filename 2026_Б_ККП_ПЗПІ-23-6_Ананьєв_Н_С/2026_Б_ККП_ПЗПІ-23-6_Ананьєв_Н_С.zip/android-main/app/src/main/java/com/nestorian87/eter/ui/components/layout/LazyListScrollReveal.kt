package com.nestorian87.eter.ui.components.layout

import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp

@Composable
fun rememberLazyListScrollRevealProgress(
    listState: LazyListState,
    revealDistance: Dp,
    headerItemIndex: Int = 0,
): State<Float> {
    val density = LocalDensity.current
    val revealDistancePx = with(density) { revealDistance.toPx() }

    return remember(listState, revealDistancePx, headerItemIndex) {
        derivedStateOf {
            when {
                listState.firstVisibleItemIndex > headerItemIndex -> 1f
                listState.firstVisibleItemIndex < headerItemIndex -> 0f
                else -> (listState.firstVisibleItemScrollOffset / revealDistancePx).coerceIn(0f, 1f)
            }
        }
    }
}
