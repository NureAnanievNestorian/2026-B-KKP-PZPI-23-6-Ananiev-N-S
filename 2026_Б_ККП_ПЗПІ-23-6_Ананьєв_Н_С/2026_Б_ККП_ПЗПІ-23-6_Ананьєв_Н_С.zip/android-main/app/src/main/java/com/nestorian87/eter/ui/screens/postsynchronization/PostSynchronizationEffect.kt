package com.nestorian87.eter.ui.screens.postsynchronization

sealed class PostSynchronizationEffect {
    data object NavigateBack : PostSynchronizationEffect()
    data object ShowStampFeedback : PostSynchronizationEffect()
}
