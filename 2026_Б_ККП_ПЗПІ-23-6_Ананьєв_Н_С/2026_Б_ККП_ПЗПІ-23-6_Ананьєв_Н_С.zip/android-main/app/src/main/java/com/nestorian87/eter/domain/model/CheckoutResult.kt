package com.nestorian87.eter.domain.model

data class CheckoutResult(
    val invoiceId: String,
    val checkoutUrl: String?,
)
