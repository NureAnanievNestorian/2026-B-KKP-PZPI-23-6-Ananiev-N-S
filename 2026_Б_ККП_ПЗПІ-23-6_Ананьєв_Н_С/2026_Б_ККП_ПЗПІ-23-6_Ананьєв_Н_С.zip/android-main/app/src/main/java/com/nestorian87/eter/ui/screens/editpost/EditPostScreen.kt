package com.nestorian87.eter.ui.screens.editpost

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts.GetContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.HourglassTop
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nestorian87.eter.R
import com.nestorian87.eter.domain.model.PostStatus
import com.nestorian87.eter.ui.components.audio.AudioPlaybackCard
import com.nestorian87.eter.ui.components.buttons.BackIconButton
import com.nestorian87.eter.ui.components.buttons.PrimaryActionButton
import com.nestorian87.eter.ui.components.buttons.SecondaryActionButton
import com.nestorian87.eter.ui.components.dialog.EterConfirmationDialog
import com.nestorian87.eter.ui.components.feedback.AnimatedErrorMessage
import com.nestorian87.eter.ui.components.feedback.LoadingOverlay
import com.nestorian87.eter.ui.components.forms.UnderlinedTextField
import com.nestorian87.eter.ui.components.layout.FormScreenScaffold
import com.nestorian87.eter.ui.theme.EditorialPanelShape
import com.nestorian87.eter.ui.theme.EterPreview
import com.nestorian87.eter.ui.theme.EterScreenPreviews
import com.nestorian87.eter.ui.theme.EterSpacing
import com.nestorian87.eter.ui.theme.TouchShape

@Composable
fun EditPostScreen(
    postId: Long,
    modifier: Modifier = Modifier,
    onBack: () -> Unit = {},
    onPostDeleted: () -> Unit = {},
    viewModel: EditPostViewModel = hiltViewModel<EditPostViewModel, EditPostViewModel.Factory> { factory ->
        factory.create(postId)
    },
) {
    val uiState = viewModel.uiState.collectAsStateWithLifecycle().value
    val replaceAudioLauncher = rememberLauncherForActivityResult(GetContent()) { uri ->
        viewModel.onReplaceAudioPicked(uri)
    }

    LaunchedEffect(uiState.isDeleted) {
        if (uiState.isDeleted) {
            onPostDeleted()
        }
    }

    EditPostScreenContent(
        uiState = uiState,
        modifier = modifier,
        onBack = onBack,
        onTitleChanged = viewModel::onTitleChanged,
        onTextChanged = viewModel::onTextChanged,
        onOriginAuthorNameChanged = viewModel::onOriginAuthorNameChanged,
        onDescriptionChanged = viewModel::onDescriptionChanged,
        onCategorySearchChanged = viewModel::onCategorySearchChanged,
        onCategorySelected = viewModel::onCategorySelected,
        onCategoryRemoved = viewModel::onCategoryRemoved,
        onCopyrightConfirmedChanged = viewModel::onCopyrightConfirmedChanged,
        onSaveClick = viewModel::onSaveClick,
        onDeleteDraftClick = viewModel::onDeleteDraftClick,
        onRetryProcessingClick = viewModel::onRetryProcessingClick,
        onReplaceAudioClick = { replaceAudioLauncher.launch("audio/*") },
    )
}

@Composable
private fun EditPostScreenContent(
    uiState: EditPostUiState,
    onBack: () -> Unit,
    onTitleChanged: (String) -> Unit,
    onTextChanged: (String) -> Unit,
    onOriginAuthorNameChanged: (String) -> Unit,
    onDescriptionChanged: (String) -> Unit,
    onCategorySearchChanged: (String) -> Unit,
    onCategorySelected: (EditPostCategoryUiState) -> Unit,
    onCategoryRemoved: (Long) -> Unit,
    onCopyrightConfirmedChanged: (Boolean) -> Unit,
    onSaveClick: () -> Unit,
    onDeleteDraftClick: () -> Unit,
    onRetryProcessingClick: () -> Unit,
    onReplaceAudioClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var isCategoryPickerOpen by rememberSaveable { mutableStateOf(false) }
    var isDeleteDialogVisible by rememberSaveable { mutableStateOf(false) }
    var deleteAttempted by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(isDeleteDialogVisible) {
        if (!isDeleteDialogVisible) deleteAttempted = false
    }

    FormScreenScaffold(
        modifier = modifier,
    ) {
        Box {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(EterSpacing.large),
            ) {
                EditPostTopBar(
                    onBack = onBack,
                    showDeleteDraft = uiState.postStatus == PostStatus.DRAFT,
                    isDeleteEnabled = uiState.canDeleteDraft,
                    onDeleteDraftClick = { isDeleteDialogVisible = true },
                )
                EditPostHeader()
                EditPostAudioStatusCard(
                    uiState = uiState,
                    onRetryProcessingClick = onRetryProcessingClick,
                    onReplaceAudioClick = onReplaceAudioClick,
                )
                if (uiState.isProcessing) {
                    EditPostProcessingStateCard()
                } else {
                    EditPostForm(
                        uiState = uiState,
                        onTitleChanged = onTitleChanged,
                        onTextChanged = onTextChanged,
                        onOriginAuthorNameChanged = onOriginAuthorNameChanged,
                        onDescriptionChanged = onDescriptionChanged,
                        onOpenCategoryPicker = { isCategoryPickerOpen = true },
                        onCategoryRemoved = onCategoryRemoved,
                        onCopyrightConfirmedChanged = onCopyrightConfirmedChanged,
                    )
                }
                AnimatedErrorMessage(
                    messageResId = uiState.errorMessage?.toMessageResId(),
                )
                EditPostBottomActions(
                    uiState = uiState,
                    onSaveClick = onSaveClick,
                )
                Spacer(modifier = Modifier.height(EterSpacing.xxLarge))
            }

            LoadingOverlay(
                isVisible = uiState.isLoadingPost,
                modifier = Modifier.matchParentSize(),
            )
        }
    }

    if (isCategoryPickerOpen) {
        EditPostCategoryPickerSheet(
            uiState = uiState,
            onDismissRequest = {},
            onCategorySearchChanged = onCategorySearchChanged,
            onCategorySelected = onCategorySelected,
            onCategoryRemoved = onCategoryRemoved,
        )
    }

    if (isDeleteDialogVisible) {
        EterConfirmationDialog(
            title = stringResource(R.string.publish_delete_draft_title),
            message = stringResource(R.string.publish_delete_draft_message),
            confirmText = stringResource(R.string.publish_delete_draft_confirm),
            confirmIcon = Icons.Rounded.DeleteOutline,
            isConfirmLoading = uiState.isDeleting,
            errorMessage = if (deleteAttempted && !uiState.isDeleting) {
                uiState.errorMessage?.let { stringResource(it.toMessageResId()) }
            } else null,
            onConfirm = {
                onDeleteDraftClick()
            },
            onDismiss = { isDeleteDialogVisible = false },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditPostTopBar(
    onBack: () -> Unit,
    showDeleteDraft: Boolean,
    isDeleteEnabled: Boolean,
    onDeleteDraftClick: () -> Unit,
) {
    TopAppBar(
        title = {
            Text(
                text = stringResource(R.string.publish_title),
                style = MaterialTheme.typography.headlineLarge,
            )
        },
        navigationIcon = {
            BackIconButton(onClick = onBack)
        },
        actions = {
            if (showDeleteDraft) {
                IconButton(
                    onClick = onDeleteDraftClick,
                    enabled = isDeleteEnabled,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.DeleteOutline,
                        contentDescription = stringResource(R.string.publish_delete_draft_cta),
                        tint = if (isDeleteEnabled) {
                            MaterialTheme.colorScheme.error
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.42f)
                        },
                    )
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.background,
        ),
    )
}

@Composable
private fun EditPostHeader() {
    Column(
        verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
    ) {
        Text(
            text = stringResource(R.string.publish_subtitle),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
            text = stringResource(R.string.publish_section_content_subtitle),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun EditPostBottomActions(
    uiState: EditPostUiState,
    onSaveClick: () -> Unit,
) {
    Column {
        PrimaryActionButton(
            text = stringResource(
                if (uiState.postStatus == PostStatus.PUBLISHED) {
                    R.string.publish_update_cta
                } else {
                    R.string.publish_submit_cta
                },
            ),
            modifier = Modifier.fillMaxWidth(),
            enabled = uiState.canSave,
            isLoading = uiState.isSubmitting,
            onClick = onSaveClick,
        )
    }
}

@Composable
private fun EditPostAudioStatusCard(
    uiState: EditPostUiState,
    onRetryProcessingClick: () -> Unit,
    onReplaceAudioClick: () -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.18f),
        tonalElevation = 0.dp,
        shape = EditorialPanelShape,
        border = BorderStroke(
            width = 1.dp,
            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f),
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(EterSpacing.medium),
        ) {
            if (!uiState.isProcessing && uiState.audioFileUrl != null) {
                EditPostAudioPreviewPlayer(
                    title = stringResource(R.string.publish_audio_default_name),
                    audioUrl = uiState.audioFileUrl,
                    canReplaceAudio = uiState.canReplaceAudio,
                    onReplaceAudioClick = onReplaceAudioClick,
                )
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(TouchShape)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = if (uiState.isProcessing) {
                                Icons.Rounded.HourglassTop
                            } else {
                                Icons.Rounded.MusicNote
                            },
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                        )
                    }
                    Spacer(modifier = Modifier.width(EterSpacing.medium))
                    Column(
                        modifier = Modifier.weight(1f),
                    ) {
                        Text(
                            text = stringResource(R.string.publish_audio_default_name),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = stringResource(
                                when (uiState.postStatus) {
                                    PostStatus.PROCESSING -> R.string.publish_audio_processing_status
                                    PostStatus.PUBLISHED -> R.string.publish_audio_published_status
                                    PostStatus.DRAFT -> R.string.publish_audio_draft_status
                                    null -> R.string.publish_audio_loading_status
                                },
                            ),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    if (uiState.isProcessing) {
                        EditPostAudioActionChip(
                            icon = Icons.Rounded.Refresh,
                            text = stringResource(R.string.publish_check_status_cta),
                            contentDescription = stringResource(R.string.publish_retry_processing),
                            onClick = onRetryProcessingClick,
                        )
                    } else if (uiState.canReplaceAudio) {
                        SecondaryActionButton(
                            text = stringResource(R.string.publish_replace_audio_cta),
                            modifier = Modifier.width(164.dp),
                            isSmall = true,
                            onClick = onReplaceAudioClick,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EditPostAudioPreviewPlayer(
    title: String,
    audioUrl: String,
    canReplaceAudio: Boolean,
    onReplaceAudioClick: () -> Unit,
) {
    AudioPlaybackCard(
        mediaUri = audioUrl,
        title = title,
        playContentDescription = stringResource(R.string.publish_play_audio),
        pauseContentDescription = stringResource(R.string.publish_pause_audio),
        trailingContent = if (canReplaceAudio) {
            {
                SecondaryActionButton(
                    text = stringResource(R.string.publish_replace_audio_cta),
                    modifier = Modifier.width(164.dp),
                    isSmall = true,
                    onClick = onReplaceAudioClick,
                )
            }
        } else {
            null
        },
    )
}

@Composable
private fun EditPostAudioActionChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    contentDescription: String,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f),
        contentColor = MaterialTheme.colorScheme.primary,
        shape = MaterialTheme.shapes.small,
        border = BorderStroke(
            width = 1.dp,
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
        ),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.labelLarge,
            )
        }
    }
}

@Composable
private fun EditPostProcessingStateCard() {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.18f),
        tonalElevation = 0.dp,
        shape = EditorialPanelShape,
        border = BorderStroke(
            width = 1.dp,
            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f),
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(EterSpacing.xLarge),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(
                imageVector = Icons.Rounded.HourglassTop,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(52.dp),
            )
            Spacer(modifier = Modifier.height(EterSpacing.large))
            Text(
                text = stringResource(R.string.publish_processing_title),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center,
            )
            Spacer(modifier = Modifier.height(EterSpacing.xSmall))
            Text(
                text = stringResource(R.string.publish_processing_description),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
private fun EditPostForm(
    uiState: EditPostUiState,
    onTitleChanged: (String) -> Unit,
    onTextChanged: (String) -> Unit,
    onOriginAuthorNameChanged: (String) -> Unit,
    onDescriptionChanged: (String) -> Unit,
    onOpenCategoryPicker: () -> Unit,
    onCategoryRemoved: (Long) -> Unit,
    onCopyrightConfirmedChanged: (Boolean) -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(EterSpacing.xLarge),
    ) {
        EditPostSection(
            title = stringResource(R.string.publish_section_content_title),
            subtitle = stringResource(R.string.publish_section_content_subtitle),
        ) {
            UnderlinedTextField(
                value = uiState.title,
                onValueChange = onTitleChanged,
                label = stringResource(R.string.publish_field_title),
                placeholder = stringResource(R.string.publish_field_title_placeholder),
            )
            Spacer(modifier = Modifier.height(EterSpacing.large))
            UnderlinedTextField(
                value = uiState.text,
                onValueChange = onTextChanged,
                label = stringResource(R.string.publish_field_text),
                placeholder = stringResource(R.string.publish_field_text_placeholder),
                singleLine = false,
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Sentences,
                    imeAction = ImeAction.Default,
                ),
            )
            Spacer(modifier = Modifier.height(EterSpacing.large))
            UnderlinedTextField(
                value = uiState.originAuthorName,
                onValueChange = onOriginAuthorNameChanged,
                label = stringResource(R.string.publish_field_author),
                placeholder = stringResource(R.string.publish_field_author_placeholder),
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Words,
                    imeAction = ImeAction.Next,
                ),
            )
            Spacer(modifier = Modifier.height(EterSpacing.large))
            UnderlinedTextField(
                value = uiState.description,
                onValueChange = onDescriptionChanged,
                label = stringResource(R.string.publish_field_description),
                placeholder = stringResource(R.string.publish_field_description_placeholder),
                singleLine = false,
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Sentences,
                    imeAction = ImeAction.Default,
                ),
            )
        }
        EditPostSection(
            title = stringResource(R.string.publish_section_categories_title),
            subtitle = stringResource(R.string.publish_section_categories_subtitle),
        ) {
            EditPostCategoriesSection(
                uiState = uiState,
                onOpenPicker = onOpenCategoryPicker,
                onCategoryRemoved = onCategoryRemoved,
            )
        }
        EditPostSection(
            title = stringResource(R.string.publish_section_rights_title),
            subtitle = stringResource(R.string.publish_section_rights_subtitle),
        ) {
            CopyrightRow(
                checked = uiState.isCopyrightConfirmed,
                onCheckedChange = onCopyrightConfirmedChanged,
            )
            if (uiState.isSaved) {
                Spacer(modifier = Modifier.height(EterSpacing.medium))
                Text(
                    text = stringResource(R.string.publish_saved_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
        }
    }
}

@Composable
private fun EditPostCategoriesSection(
    uiState: EditPostUiState,
    onOpenPicker: () -> Unit,
    onCategoryRemoved: (Long) -> Unit,
) {
    Column {
        Row(
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = stringResource(R.string.publish_categories_title),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f),
            )
            Text(
                text = stringResource(
                    R.string.publish_categories_selected_count,
                    uiState.selectedCountLabel,
                ),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(modifier = Modifier.height(EterSpacing.medium))
        Text(
            text = stringResource(R.string.publish_categories_helper),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(modifier = Modifier.height(EterSpacing.small))
        EditPostCategoryPickerTrigger(
            selectionSummary = uiState.selectedCategories.joinToString { it.categoryName },
            onClick = onOpenPicker,
        )
        if (uiState.selectedCategories.isNotEmpty()) {
            Spacer(modifier = Modifier.height(EterSpacing.medium))
            Text(
                text = stringResource(R.string.publish_categories_selected_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Spacer(modifier = Modifier.height(EterSpacing.small))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(EterSpacing.small),
                verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
            ) {
                uiState.selectedCategories.forEach { category ->
                    EditPostSelectableChip(
                        text = category.categoryName,
                        selected = true,
                        onClick = { onCategoryRemoved(category.categoryId) },
                    )
                }
            }
        }
    }
}


@EterScreenPreviews
@Composable
private fun EditPostScreenProcessingPreview() {
    EterPreview {
        EditPostScreenContent(
            uiState = EditPostUiState(
                postId = 1L,
                postStatus = PostStatus.PROCESSING,
                isLoadingPost = false,
                audioDisplayName = "Аудіозапис",
            ),
            onBack = {},
            onTitleChanged = {},
            onTextChanged = {},
            onOriginAuthorNameChanged = {},
            onDescriptionChanged = {},
            onCategorySearchChanged = {},
            onCategorySelected = {},
            onCategoryRemoved = {},
            onCopyrightConfirmedChanged = {},
            onSaveClick = {},
            onDeleteDraftClick = {},
            onRetryProcessingClick = {},
            onReplaceAudioClick = {},
        )
    }
}

@EterScreenPreviews
@Composable
private fun EditPostScreenDraftPreview() {
    EterPreview {
        EditPostScreenContent(
            uiState = EditPostUiState(
                postId = 1L,
                postStatus = PostStatus.DRAFT,
                isLoadingPost = false,
                title = "Ніч над містом",
                text = "Текст вірша, який уже підготовлений до публікації.",
                originAuthorName = "Леся Українка",
                description = "Короткий опис або контекст для слухача.",
                audioDisplayName = "Запис 05.04.2026 18:37",
                selectedCategories = listOf(
                    EditPostCategoryUiState(1, "Лірика"),
                    EditPostCategoryUiState(2, "Кохання"),
                ),
                availableCategories = listOf(
                    EditPostCategoryUiState(3, "Меланхолія"),
                    EditPostCategoryUiState(4, "Сучасне"),
                ),
                isCopyrightConfirmed = true,
            ),
            onBack = {},
            onTitleChanged = {},
            onTextChanged = {},
            onOriginAuthorNameChanged = {},
            onDescriptionChanged = {},
            onCategorySearchChanged = {},
            onCategorySelected = {},
            onCategoryRemoved = {},
            onCopyrightConfirmedChanged = {},
            onSaveClick = {},
            onDeleteDraftClick = {},
            onRetryProcessingClick = {},
            onReplaceAudioClick = {},
        )
    }
}
