package com.nestorian87.eter.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class SubscriptionTransactionDto(
    val transactionId: Long,
    val invoiceId: String,
    val status: String? = null,
    val type: String,
    val amount: String,
    val currency: String,
    val isCardUpdating: Boolean = false,
    val modifiedDate: String? = null,
    val createdAt: String,
    val updatedAt: String,
)
