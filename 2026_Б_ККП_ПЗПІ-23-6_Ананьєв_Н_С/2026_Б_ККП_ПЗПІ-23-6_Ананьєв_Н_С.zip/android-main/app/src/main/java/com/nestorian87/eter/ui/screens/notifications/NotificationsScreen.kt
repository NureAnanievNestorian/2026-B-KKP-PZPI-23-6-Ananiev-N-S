package com.nestorian87.eter.ui.screens.notifications

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nestorian87.eter.R
import com.nestorian87.eter.domain.model.NotificationItem
import com.nestorian87.eter.domain.model.NotificationType
import com.nestorian87.eter.ui.components.buttons.BackIconButton
import com.nestorian87.eter.ui.components.feedback.EterLoadingIndicator
import com.nestorian87.eter.ui.components.layout.AuthorAvatar
import com.nestorian87.eter.ui.components.layout.PlaceholderScreen
import com.nestorian87.eter.ui.theme.EditorialCardShape
import com.nestorian87.eter.ui.theme.EterPreview
import com.nestorian87.eter.ui.theme.EterScreenPreviews
import com.nestorian87.eter.ui.theme.EterSpacing
import com.nestorian87.eter.ui.theme.PillShape
import com.nestorian87.eter.util.toRelativeAgeText
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull

@Composable
fun NotificationsScreen(
    modifier: Modifier = Modifier,
    onBack: () -> Unit = {},
    onOpenPost: (Long, Boolean) -> Unit = { _, _ -> },
    onOpenProfile: (String) -> Unit = {},
    viewModel: NotificationsViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current

    LaunchedEffect(viewModel, snackbarHostState, context) {
        viewModel.effects.collect { effect ->
            when (effect) {
                is NotificationsEffect.OpenPost -> onOpenPost(effect.postId, effect.focusComments)
                is NotificationsEffect.OpenProfile -> onOpenProfile(effect.username)
                is NotificationsEffect.ShowMessage -> {
                    snackbarHostState.showSnackbar(
                        message = context.getString(effect.messageResId),
                    )
                }
            }
        }
    }

    NotificationsScreenContent(
        uiState = uiState,
        snackbarHostState = snackbarHostState,
        onBack = onBack,
        onRetry = viewModel::loadInitial,
        onLoadMore = viewModel::onLoadMore,
        onFilterSelected = viewModel::onFilterSelected,
        onNotificationClick = viewModel::onNotificationClick,
        onMarkAllRead = viewModel::onMarkAllRead,
        modifier = modifier,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NotificationsScreenContent(
    uiState: NotificationsUiState,
    snackbarHostState: SnackbarHostState,
    onBack: () -> Unit,
    onRetry: () -> Unit,
    onLoadMore: () -> Unit,
    onFilterSelected: (NotificationsFilter) -> Unit,
    onNotificationClick: (Long) -> Unit,
    onMarkAllRead: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val listState = rememberLazyListState()

    LaunchedEffect(
        listState,
        uiState.items.size,
        uiState.isInitialLoading,
        uiState.isLoadingMore,
        uiState.canLoadMore,
    ) {
        if (uiState.isInitialLoading) {
            return@LaunchedEffect
        }

        snapshotFlow { listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index }
            .filterNotNull()
            .distinctUntilChanged()
            .collect { lastVisibleIndex ->
                val triggerIndex = uiState.items.lastIndex - 2
                if (lastVisibleIndex >= triggerIndex) {
                    onLoadMore()
                }
            }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(R.string.notifications),
                        style = MaterialTheme.typography.headlineSmall,
                    )
                },
                navigationIcon = {
                    BackIconButton(onClick = onBack)
                },
                actions = {
                    if (uiState.unreadCount > 0) {
                        TextButton(
                            onClick = onMarkAllRead,
                            enabled = !uiState.isMarkAllReadLoading,
                        ) {
                            Text(text = stringResource(R.string.notifications_mark_all_read))
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                ),
            )
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            NotificationsFilterRow(
                selectedFilter = uiState.selectedFilter,
                onFilterSelected = onFilterSelected,
            )
            HorizontalDivider(
                thickness = 0.5.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.16f),
            )

            when {
                uiState.isInitialLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center,
                    ) {
                        EterLoadingIndicator()
                    }
                }

                uiState.error != null && uiState.items.isEmpty() -> {
                    NotificationsInitialErrorState(
                        onRetry = onRetry,
                        modifier = Modifier.weight(1f),
                    )
                }

                uiState.items.isEmpty() -> {
                    PlaceholderScreen(
                        title = stringResource(R.string.notifications_empty_title),
                        description = stringResource(
                            if (uiState.selectedFilter == NotificationsFilter.UNREAD) {
                                R.string.notifications_empty_unread_description
                            } else {
                                R.string.notifications_empty_description
                            }
                        ),
                        modifier = Modifier.weight(1f),
                    )
                }

                else -> {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(
                            vertical = EterSpacing.small,
                        ),
                    ) {
                        item(key = "summary") {
                            NotificationsSummaryRow(
                                unseenCount = uiState.unseenCount,
                                unreadCount = uiState.unreadCount,
                            )
                        }

                        itemsIndexed(
                            items = uiState.items,
                            key = { _, item -> item.notificationId },
                        ) { index, item ->
                            NotificationRow(
                                item = item,
                                isPending = uiState.pendingNotificationIds.contains(item.notificationId),
                                showDivider = index != uiState.items.lastIndex,
                                onClick = { onNotificationClick(item.notificationId) },
                            )
                        }

                        if (uiState.isLoadingMore) {
                            item(key = "loading_more") {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = EterSpacing.small),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    EterLoadingIndicator()
                                }
                            }
                        }

                        if (uiState.error != null) {
                            item(key = "retry") {
                                NotificationsRetryCard(onRetry = onRetry)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NotificationsFilterRow(
    selectedFilter: NotificationsFilter,
    onFilterSelected: (NotificationsFilter) -> Unit,
) {
    LazyRow(
        modifier = Modifier
            .fillMaxWidth(),
        contentPadding = PaddingValues(
            horizontal = EterSpacing.medium,
            vertical = EterSpacing.small
        ),
        horizontalArrangement = Arrangement.spacedBy(EterSpacing.small),
    ) {
        items(
            items = NotificationsFilter.entries,
            key = { it.name },
        ) { filter ->
            FilterChip(
                selected = selectedFilter == filter,
                onClick = { onFilterSelected(filter) },
                shape = PillShape,
                label = {
                    Text(
                        text = stringResource(filter.labelResId),
                        maxLines = 1,
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.82f),
                    labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f),
                    selectedLabelColor = MaterialTheme.colorScheme.primary,
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = selectedFilter == filter,
                    borderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.22f),
                    selectedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.58f),
                    disabledBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.16f),
                    disabledSelectedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.16f),
                    borderWidth = 0.5.dp,
                    selectedBorderWidth = 0.5.dp,
                ),
            )
        }
    }
}

@Composable
private fun NotificationsSummaryRow(
    unseenCount: Int,
    unreadCount: Int,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = EterSpacing.medium, vertical = EterSpacing.small),
        horizontalArrangement = Arrangement.spacedBy(EterSpacing.small),
    ) {
        NotificationsCountPill(
            label = stringResource(R.string.notifications_summary_new, unseenCount),
            isEmphasized = unseenCount > 0,
        )
        NotificationsCountPill(
            label = stringResource(R.string.notifications_summary_unread, unreadCount),
            isEmphasized = unreadCount > 0,
        )
    }
}

@Composable
private fun NotificationsCountPill(
    label: String,
    isEmphasized: Boolean,
) {
    Surface(
        shape = PillShape,
        color = if (isEmphasized) {
            MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)
        } else {
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f)
        },
        border = BorderStroke(
            width = 0.5.dp,
            color = if (isEmphasized) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.42f)
            } else {
                MaterialTheme.colorScheme.outline.copy(alpha = 0.14f)
            },
        ),
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            style = MaterialTheme.typography.labelLarge,
            color = if (isEmphasized) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.onSurfaceVariant
            },
        )
    }
}

@Composable
private fun NotificationRow(
    item: NotificationItem,
    isPending: Boolean,
    showDivider: Boolean,
    onClick: () -> Unit,
) {
    val actorDisplayName = item.lastActor?.name?.trim()?.takeIf { it.isNotEmpty() }
        ?: item.lastActor?.username?.trim()?.takeIf { it.isNotEmpty() }
        ?: stringResource(R.string.notifications_actor_default)

    Surface(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick,
        enabled = !isPending,
        color = MaterialTheme.colorScheme.background,
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = EterSpacing.medium, vertical = EterSpacing.large),
                horizontalArrangement = Arrangement.spacedBy(EterSpacing.small),
                verticalAlignment = Alignment.Top,
            ) {
                AuthorAvatar(
                    name = actorDisplayName,
                    photoUrl = item.lastActor?.photo,
                    size = 40.dp,
                )
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
                        verticalAlignment = Alignment.Top,
                    ) {
                        Text(
                            text = stringResource(item.titleResId, actorDisplayName),
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = if (item.isRead) {
                                    FontWeight.Medium
                                } else {
                                    FontWeight.SemiBold
                                },
                            ),
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                        if (!item.isRead) {
                            Box(
                                modifier = Modifier
                                    .padding(top = 7.dp)
                                    .size(7.dp)
                                    .background(
                                        color = MaterialTheme.colorScheme.primary,
                                        shape = CircleShape,
                                    ),
                            )
                        }
                    }
                    Text(
                        text = item.lastEventAt.toRelativeAgeText(),
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.SemiBold,
                        ),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )

                    item.previewLine?.let { preview ->
                        Text(
                            text = preview,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }

                    if (item.eventsCount > 1) {
                        Text(
                            text = stringResource(
                                R.string.notifications_events_count,
                                item.eventsCount
                            ),
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                }
            }
            if (showDivider) {
                HorizontalDivider(
                    modifier = Modifier.padding(start = EterSpacing.medium + 40.dp + EterSpacing.small),
                    thickness = 0.5.dp,
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.14f),
                )
            }
        }
    }
}

@Composable
private fun NotificationsInitialErrorState(
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier.fillMaxSize()) {
        PlaceholderScreen(
            title = stringResource(R.string.notifications_error_title),
            description = stringResource(R.string.notifications_error_generic),
            modifier = Modifier.weight(1f),
        )
        TextButton(
            onClick = onRetry,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(bottom = EterSpacing.large),
        ) {
            Text(text = stringResource(R.string.feed_retry))
        }
    }
}

@Composable
private fun NotificationsRetryCard(
    onRetry: () -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = EditorialCardShape,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.64f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.16f)),
    ) {
        Row(
            modifier = Modifier.padding(EterSpacing.medium),
            horizontalArrangement = Arrangement.spacedBy(EterSpacing.small),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = stringResource(R.string.notifications_error_generic),
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            TextButton(onClick = onRetry) {
                Text(text = stringResource(R.string.feed_retry))
            }
        }
    }
}

private val NotificationItem.previewLine: String?
    get() = replyPreviewText
        ?.trim()
        ?.takeIf { it.isNotEmpty() }
        ?: commentPreviewText?.trim()?.takeIf { it.isNotEmpty() }
        ?: previewText?.trim()?.takeIf { it.isNotEmpty() }
        ?: targetLabel?.trim()?.takeIf { it.isNotEmpty() }
        ?: postTitle?.trim()?.takeIf { it.isNotEmpty() }

private val NotificationItem.titleResId: Int
    get() = when (notificationType) {
        NotificationType.POST_LIKED -> R.string.notifications_type_post_liked
        NotificationType.POST_COMMENTED -> R.string.notifications_type_post_commented
        NotificationType.COMMENT_REPLIED -> R.string.notifications_type_comment_replied
        NotificationType.COMMENT_LIKED -> R.string.notifications_type_comment_liked
        NotificationType.USER_FOLLOWED -> R.string.notifications_type_user_followed
        NotificationType.POST_VIOLATION_CONFIRMED -> R.string.notifications_type_post_violation_confirmed
        NotificationType.UNKNOWN -> R.string.notifications_type_post_violation_confirmed
    }

private val NotificationsFilter.labelResId: Int
    get() = when (this) {
        NotificationsFilter.ALL -> R.string.notifications_filter_all
        NotificationsFilter.UNREAD -> R.string.notifications_filter_unread
        NotificationsFilter.COMMENTS -> R.string.notifications_filter_comments
        NotificationsFilter.FOLLOWS -> R.string.notifications_filter_follows
    }

@EterScreenPreviews
@Composable
private fun NotificationsScreenPreview() {
    EterPreview {
        NotificationsScreenContent(
            uiState = NotificationsUiState(
                items = listOf(
                    NotificationItem(
                        notificationId = 1,
                        notificationType = NotificationType.POST_COMMENTED,
                        isRead = false,
                        isSeen = true,
                        previewText = "Beautiful cadence in this line.",
                        postTitle = "Night river",
                        lastEventAt = "2026-05-27T12:00:00Z",
                        createdAt = "2026-05-27T12:00:00Z",
                    ),
                ),
                selectedFilter = NotificationsFilter.ALL,
                unreadCount = 3,
                unseenCount = 1,
                isInitialLoading = false,
            ),
            snackbarHostState = remember { SnackbarHostState() },
            onBack = {},
            onRetry = {},
            onLoadMore = {},
            onFilterSelected = {},
            onNotificationClick = {},
            onMarkAllRead = {},
        )
    }
}
