package com.nestorian87.eter.data.remote.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class CreateComplaintRequestDto(
    @SerialName("complaintReason") val complaintReason: String,
)
