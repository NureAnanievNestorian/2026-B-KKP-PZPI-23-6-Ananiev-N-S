package com.nestorian87.eter.domain.model

data class ComplaintReasonItem(
    val key: String,
    val label: String,
)
