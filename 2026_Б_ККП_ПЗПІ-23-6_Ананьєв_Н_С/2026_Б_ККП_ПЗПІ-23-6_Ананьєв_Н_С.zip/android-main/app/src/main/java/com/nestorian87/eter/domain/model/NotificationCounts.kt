package com.nestorian87.eter.domain.model

data class NotificationCounts(
    val unreadCount: Int = 0,
    val unseenCount: Int = 0,
)
