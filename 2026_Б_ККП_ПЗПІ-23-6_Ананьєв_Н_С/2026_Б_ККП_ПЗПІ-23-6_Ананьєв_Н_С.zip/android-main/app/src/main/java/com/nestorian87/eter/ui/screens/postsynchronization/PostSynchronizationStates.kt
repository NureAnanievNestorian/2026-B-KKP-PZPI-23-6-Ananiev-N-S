package com.nestorian87.eter.ui.screens.postsynchronization

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nestorian87.eter.R
import com.nestorian87.eter.ui.components.buttons.PrimaryActionButton
import com.nestorian87.eter.ui.components.buttons.SecondaryActionButton
import com.nestorian87.eter.ui.components.feedback.shimmer
import com.nestorian87.eter.ui.theme.EterSpacing

@Composable
internal fun PostSynchronizationLoadingState(contentPadding: PaddingValues) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding)
            .padding(horizontal = EterSpacing.medium)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
    ) {
        Spacer(modifier = Modifier.height(EterSpacing.small))
        LoadingBlock(height = 108.dp)
        LoadingBlock(height = 92.dp)
        LoadingBlock(height = 86.dp)
        LoadingBlock(height = 86.dp)
        LoadingBlock(height = 86.dp)
    }
}

@Composable
internal fun PostSynchronizationLoadErrorState(
    contentPadding: PaddingValues,
    messageResId: Int,
    onRetry: () -> Unit,
    onBack: () -> Unit,
) {
    CenteredMessageState(
        contentPadding = contentPadding,
        message = stringResource(messageResId),
    ) {
        PrimaryActionButton(
            text = stringResource(R.string.post_retry),
            onClick = onRetry,
        )
        Spacer(modifier = Modifier.height(EterSpacing.small))
        SecondaryActionButton(
            text = stringResource(R.string.post_sync_back_cta),
            onClick = onBack,
        )
    }
}

@Composable
internal fun PostSynchronizationBlockingState(
    contentPadding: PaddingValues,
    reason: PostSynchronizationBlockingReason,
    onBack: () -> Unit,
) {
    CenteredMessageState(
        contentPadding = contentPadding,
        message = stringResource(reason.toMessageResId()),
    ) {
        SecondaryActionButton(
            text = stringResource(R.string.post_sync_back_cta),
            onClick = onBack,
        )
    }
}

@Composable
internal fun ErrorCard(message: String) {
    Surface(
        color = MaterialTheme.colorScheme.errorContainer,
        shape = RoundedCornerShape(24.dp),
    ) {
        Text(
            text = message,
            modifier = Modifier.padding(EterSpacing.large),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onErrorContainer,
        )
    }
}

@Composable
private fun LoadingBlock(height: Dp) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(24.dp))
            .shimmer(),
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(24.dp),
    ) {}
}

@Composable
private fun CenteredMessageState(
    contentPadding: PaddingValues,
    message: String,
    actions: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding)
            .padding(horizontal = EterSpacing.large),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        ErrorCard(message = message)
        Spacer(modifier = Modifier.height(EterSpacing.medium))
        actions()
    }
}
