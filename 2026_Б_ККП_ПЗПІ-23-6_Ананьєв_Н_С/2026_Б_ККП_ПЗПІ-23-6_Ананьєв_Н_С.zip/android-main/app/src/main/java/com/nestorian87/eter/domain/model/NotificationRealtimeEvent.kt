package com.nestorian87.eter.domain.model

sealed interface NotificationRealtimeEvent {
    data class NotificationReceived(
        val notification: NotificationItem,
        val unreadCount: Int,
        val unseenCount: Int,
    ) : NotificationRealtimeEvent

    data class CountsUpdated(
        val unreadCount: Int,
        val unseenCount: Int,
    ) : NotificationRealtimeEvent
}
