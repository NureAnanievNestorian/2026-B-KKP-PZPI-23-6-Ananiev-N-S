package com.nestorian87.eter.ui.navigation

import androidx.navigation3.runtime.NavKey
import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
sealed interface EterNavKey : NavKey

@Serializable
sealed interface TopLevelNavKey : EterNavKey

@Serializable
data object FeedKey : TopLevelNavKey

@Serializable
data object SubscriptionsKey : TopLevelNavKey

@Serializable
data class CreateKey(
    val sessionId: String = UUID.randomUUID().toString(),
) : TopLevelNavKey

@Serializable
data object FavoritesKey : TopLevelNavKey

@Serializable
data object SearchKey : TopLevelNavKey

@Serializable
data object ProfileKey : TopLevelNavKey

@Serializable
data object LoginKey : EterNavKey

@Serializable
data object RegisterKey : EterNavKey

@Serializable
data object EmailConfirmationKey : EterNavKey

@Serializable
data object ForgotPasswordKey : EterNavKey

@Serializable
data class RecordAudioKey(
    val draftId: String = UUID.randomUUID().toString(),
) : EterNavKey

@Serializable
data class EditPostKey(
    val postId: Long,
) : EterNavKey

@Serializable
data class PostSynchronizationKey(
    val postId: Long,
) : EterNavKey

@Serializable
data class PostKey(
    val postId: Long,
    val focusComments: Boolean = false,
) : EterNavKey

@Serializable
data class UserProfileKey(
    val userId: Long? = null,
    val username: String? = null,
) : EterNavKey

@Serializable
data class FollowersKey(
    val userId: Long,
    val initialTab: String = "followers",
) : EterNavKey

@Serializable
data object NotificationsKey : EterNavKey

@Serializable
data object EditProfileKey : EterNavKey

@Serializable
data object SettingsKey : EterNavKey

@Serializable
data object ManageSubscriptionKey : EterNavKey

@Serializable
data class PaymentWebViewKey(
    val url: String,
    val callbackUrlPrefix: String = "",
    val invoiceId: String = "",
    val paymentType: String = "",
) : EterNavKey

@Serializable
data class PaymentReturnKey(
    val invoiceId: String,
    val paymentType: String,
) : EterNavKey
