package com.nestorian87.eter.domain.model

enum class TransactionStatus {
    CREATED,
    PROCESSING,
    HOLD,
    SUCCESS,
    FAILURE,
    REVERSED,
    EXPIRED,
    UNKNOWN;

    companion object {
        fun fromString(value: String): TransactionStatus = when (value.lowercase()) {
            "created" -> CREATED
            "processing" -> PROCESSING
            "hold" -> HOLD
            "success" -> SUCCESS
            "failure" -> FAILURE
            "reversed" -> REVERSED
            "expired" -> EXPIRED
            else -> UNKNOWN
        }
    }
}
