package com.nestorian87.eter.service

import com.google.firebase.messaging.RemoteMessage

internal data class PushNotificationPayload(
    val title: String,
    val description: String,
) {
    companion object {
        private const val KEY_TITLE = "title"
        private const val KEY_DESCRIPTION = "desription"
        private const val KEY_DESCRIPTION_LEGACY = "description"
        private const val KEY_TAG = "tag"

        fun from(remoteMessage: RemoteMessage): PushNotificationPayload? = from(
            data = remoteMessage.data,
            fallbackTitle = remoteMessage.notification?.title,
            fallbackDescription = remoteMessage.notification?.body,
        )

        fun from(
            data: Map<String, String>,
            fallbackTitle: String? = null,
            fallbackDescription: String? = null,
        ): PushNotificationPayload? {
            val title = data[KEY_TITLE].orEmpty().trim().ifEmpty { fallbackTitle?.trim().orEmpty() }
            val description = data[KEY_DESCRIPTION]
                .ifNullOrBlank { data[KEY_DESCRIPTION_LEGACY] }
                .orEmpty()
                .trim()
                .ifEmpty { fallbackDescription?.trim().orEmpty() }
            if (title.isBlank() || description.isBlank()) {
                return null
            }
            return PushNotificationPayload(
                title = title,
                description = description,
            )
        }

        fun notificationTag(data: Map<String, String>): String? =
            data[KEY_TAG]?.trim()?.takeIf { it.isNotEmpty() }
    }
}

private inline fun String?.ifNullOrBlank(block: () -> String?): String? =
    if (this.isNullOrBlank()) {
        block()
    } else {
        this
    }
