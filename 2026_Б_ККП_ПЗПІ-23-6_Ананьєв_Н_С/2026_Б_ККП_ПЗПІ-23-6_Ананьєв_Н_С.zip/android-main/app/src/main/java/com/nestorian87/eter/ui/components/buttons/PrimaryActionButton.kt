package com.nestorian87.eter.ui.components.buttons

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nestorian87.eter.ui.components.feedback.EterLoadingIndicator
import com.nestorian87.eter.ui.theme.EterSpacing
import com.nestorian87.eter.ui.theme.TouchShape
import kotlinx.coroutines.delay

private const val LOADER_VISIBILITY_DELAY_MS = 180
private const val LOADER_FADE_DURATION_MS = 180

@Composable
fun PrimaryActionButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    isLoading: Boolean = false,
    isSmall: Boolean = false,
    onClick: () -> Unit = {},
) {
    val textStyle = MaterialTheme.typography.run {
        val style = if (isSmall) titleSmall else titleMedium
        style.copy(fontWeight = FontWeight.SemiBold)
    }
    var isLoaderVisible by remember { mutableStateOf(false) }

    LaunchedEffect(isLoading) {
        if (isLoading) {
            delay(LOADER_VISIBILITY_DELAY_MS.toLong())
            isLoaderVisible = true
        } else {
            isLoaderVisible = false
        }
    }

    val textAlpha by animateFloatAsState(
        targetValue = if (isLoaderVisible) 0f else 1f,
        animationSpec = tween(durationMillis = LOADER_FADE_DURATION_MS),
        label = "primary_button_text_alpha",
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = if (isSmall) 36.dp else 56.dp)
            .clip(TouchShape)
            .background(
                if (enabled) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)
                },
            )
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.26f), TouchShape)
            .clickable(enabled = enabled && !isLoading, onClick = onClick)
            .padding(horizontal = EterSpacing.medium, vertical = if (isSmall) 12.dp else 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            style = textStyle,
            color = MaterialTheme.colorScheme.onPrimary,
            textAlign = TextAlign.Center,
            modifier = Modifier.alpha(textAlpha),
        )

        AnimatedVisibility(
            visible = isLoaderVisible,
            enter = fadeIn(animationSpec = tween(durationMillis = LOADER_FADE_DURATION_MS)),
            exit = fadeOut(animationSpec = tween(durationMillis = LOADER_FADE_DURATION_MS)),
        ) {
            EterLoadingIndicator(
                color = MaterialTheme.colorScheme.onPrimary,
                dotSize = 8.dp,
                spacing = 6.dp,
            )
        }
    }
}
