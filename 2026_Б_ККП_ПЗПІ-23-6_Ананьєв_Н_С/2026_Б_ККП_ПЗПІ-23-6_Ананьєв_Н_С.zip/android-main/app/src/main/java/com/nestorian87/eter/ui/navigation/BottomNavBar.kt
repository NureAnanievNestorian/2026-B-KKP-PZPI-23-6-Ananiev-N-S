package com.nestorian87.eter.ui.navigation

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.nestorian87.eter.ui.theme.EterPreview
import com.nestorian87.eter.ui.theme.EterScreenPreviews
import com.nestorian87.eter.ui.theme.EterSpacing
import com.nestorian87.eter.ui.theme.NavigationDockShape

@Composable
fun BottomNavBar(
    currentTab: TopLevelDestination?,
    onTabSelected: (TopLevelDestination) -> Unit,
) {
    Surface(
        shape = NavigationDockShape,
        color = MaterialTheme.colorScheme.background.copy(alpha = 0.98f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.08f)),
        shadowElevation = 10.dp,
    ) {
        Column {
            HorizontalDivider(
                thickness = 0.5.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.18f),
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(
                        start = EterSpacing.xSmall,
                        end = EterSpacing.xSmall,
                        bottom = 8.dp,
                        top = 5.dp
                    ),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                TopLevelDestination.entries
                    .filter(TopLevelDestination::showInBottomBar)
                    .forEach { destination ->
                        if (destination == TopLevelDestination.CREATE) {
                            CreateNavItem(
                                label = stringResource(destination.labelRes),
                                icon = destination.icon,
                                selected = currentTab == destination,
                                onClick = { onTabSelected(destination) },
                            )
                        } else {
                            EditorialNavItem(
                                label = stringResource(destination.labelRes),
                                icon = destination.icon,
                                selected = currentTab == destination,
                                onClick = { onTabSelected(destination) },
                            )
                        }
                    }
            }
        }
    }
}

@Composable
private fun RowScope.EditorialNavItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val iconTint by animateColorAsState(
        targetValue = if (selected) {
            MaterialTheme.colorScheme.primary
        } else {
            MaterialTheme.colorScheme.onSurfaceVariant
        },
        animationSpec = tween(180),
        label = "nav_icon_tint",
    )
    val labelAlpha = if (selected) 1f else 0.8f

    Surface(
        modifier = Modifier
            .weight(1f)
            .animateContentSize(),
        color = MaterialTheme.colorScheme.background,
        onClick = onClick,
    ) {
        Column(
            modifier = Modifier.padding(vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                modifier = Modifier.size(24.dp),
                tint = iconTint,
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                ),
                color = iconTint,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.alpha(labelAlpha),
            )
            Box(
                modifier = Modifier
                    .height(2.dp)
                    .fillMaxWidth(0.22f)
                    .alpha(if (selected) 1f else 0f)
                    .background(
                        color = MaterialTheme.colorScheme.primary,
                        shape = CircleShape,
                    ),
            )
        }
    }
}

@Composable
private fun RowScope.CreateNavItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val containerColor by animateColorAsState(
        targetValue = if (selected) {
            MaterialTheme.colorScheme.primary
        } else {
            MaterialTheme.colorScheme.primary.copy(alpha = 0.9f)
        },
        animationSpec = tween(180),
        label = "create_nav_container",
    )
    val contentColor by animateColorAsState(
        targetValue = MaterialTheme.colorScheme.onPrimary,
        animationSpec = tween(180),
        label = "create_nav_content",
    )

    Surface(
        modifier = Modifier.weight(1f),
        color = MaterialTheme.colorScheme.background,
        onClick = onClick,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Spacer(modifier = Modifier.height(2.dp))
            Surface(
                modifier = Modifier.size(45.dp),
                shape = CircleShape,
                color = containerColor,
                contentColor = contentColor,
                border = BorderStroke(
                    1.dp,
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
                ),
                onClick = onClick,
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        modifier = Modifier.size(22.dp),
                    )
                }
            }
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@EterScreenPreviews
@Composable
private fun BottomNavBarPreview() {
    EterPreview {
        BottomNavBar(
            currentTab = TopLevelDestination.FEED,
            onTabSelected = {},
        )
    }
}
