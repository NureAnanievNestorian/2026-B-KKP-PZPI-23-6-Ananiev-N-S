package com.nestorian87.eter.domain.model

class ComplaintAlreadyReportedException : Exception()
