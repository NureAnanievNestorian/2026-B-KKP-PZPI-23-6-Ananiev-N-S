package com.nestorian87.eter.ui.screens.postsynchronization

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nestorian87.eter.R
import com.nestorian87.eter.ui.components.buttons.BackIconButton
import com.nestorian87.eter.ui.components.buttons.PrimaryActionButton
import com.nestorian87.eter.ui.components.buttons.SecondaryActionButton
import com.nestorian87.eter.ui.components.dialog.EterConfirmationDialog
import com.nestorian87.eter.ui.theme.EterSpacing

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostSynchronizationScreen(
    postId: Long,
    modifier: Modifier = Modifier,
    onBack: () -> Unit = {},
    viewModel: PostSynchronizationViewModel =
        hiltViewModel<PostSynchronizationViewModel, PostSynchronizationViewModel.Factory> { factory ->
            factory.create(postId)
        },
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val hapticFeedback = LocalHapticFeedback.current
    var isLeaveDialogVisible by rememberSaveable { mutableStateOf(false) }
    var isClearAllDialogVisible by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(viewModel) {
        viewModel.effects.collect { effect ->
            when (effect) {
                PostSynchronizationEffect.NavigateBack -> onBack()
                PostSynchronizationEffect.ShowStampFeedback -> {
                    hapticFeedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                }
            }
        }
    }

    BackHandler {
        if (uiState.hasChanges) {
            isLeaveDialogVisible = true
        } else {
            viewModel.onExitConfirmed()
        }
    }

    PostSynchronizationScreenContent(
        uiState = uiState,
        modifier = modifier,
        onBack = {
            if (uiState.hasChanges) {
                isLeaveDialogVisible = true
            } else {
                viewModel.onExitConfirmed()
            }
        },
        onRetryLoad = viewModel::retryLoad,
        onSave = viewModel::onSaveClick,
        onTogglePlayback = viewModel::onTogglePlayback,
        onSeekToPercent = viewModel::onSeekToPercent,
        onSeekBackward = viewModel::onSeekBackward,
        onSeekForward = viewModel::onSeekForward,
        onPreviousLine = viewModel::onFocusPrevious,
        onStampLine = viewModel::onStampCurrentLine,
        onNextLine = viewModel::onFocusNext,
        onClearAll = { isClearAllDialogVisible = true },
        onFocusLine = viewModel::onFocusLine,
        onJumpToLine = viewModel::onJumpToLine,
        onClearLine = viewModel::onClearLine,
    )

    if (isLeaveDialogVisible) {
        EterConfirmationDialog(
            title = stringResource(R.string.post_sync_leave_title),
            message = stringResource(R.string.post_sync_leave_message),
            confirmText = stringResource(R.string.post_sync_leave_confirm),
            confirmIcon = Icons.Rounded.WarningAmber,
            onConfirm = {
                isLeaveDialogVisible = false
                viewModel.onExitConfirmed()
            },
            onDismiss = { isLeaveDialogVisible = false },
        )
    }

    if (isClearAllDialogVisible) {
        EterConfirmationDialog(
            title = stringResource(R.string.post_sync_clear_all_title),
            message = stringResource(R.string.post_sync_clear_all_message),
            confirmText = stringResource(R.string.post_sync_clear_all_confirm),
            confirmIcon = Icons.Rounded.Clear,
            onConfirm = {
                isClearAllDialogVisible = false
                viewModel.onClearAllConfirmed()
            },
            onDismiss = { isClearAllDialogVisible = false },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun PostSynchronizationScreenContent(
    uiState: PostSynchronizationUiState,
    modifier: Modifier = Modifier,
    onBack: () -> Unit,
    onRetryLoad: () -> Unit,
    onSave: () -> Unit,
    onTogglePlayback: () -> Unit,
    onSeekToPercent: (Float) -> Unit,
    onSeekBackward: () -> Unit,
    onSeekForward: () -> Unit,
    onPreviousLine: () -> Unit,
    onStampLine: () -> Unit,
    onNextLine: () -> Unit,
    onClearAll: () -> Unit,
    onFocusLine: (Int) -> Unit,
    onJumpToLine: (Int) -> Unit,
    onClearLine: (Int) -> Unit,
) {
    var isMoreMenuExpanded by rememberSaveable { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            PostSynchronizationTopBar(
                canSave = uiState.canSave,
                canOpenEditor = uiState.canOpenEditor,
                isMoreMenuExpanded = isMoreMenuExpanded,
                onBack = onBack,
                onSave = onSave,
                onMoreMenuExpandedChange = { isMoreMenuExpanded = it },
                onClearAll = onClearAll,
            )
        },
        bottomBar = {
            if (uiState.canOpenEditor) {
                PostSynchronizationBottomBar(
                    isSaving = uiState.isSaving,
                    currentTimestampLabel = formatTimestampMs(
                        (uiState.currentTimeSeconds * 1_000f).toInt().coerceAtLeast(0),
                    ),
                    onPreviousLine = onPreviousLine,
                    onStampLine = onStampLine,
                    onNextLine = onNextLine,
                )
            }
        },
    ) { contentPadding ->
        when {
            uiState.isLoading -> PostSynchronizationLoadingState(contentPadding = contentPadding)
            uiState.loadError != null -> PostSynchronizationLoadErrorState(
                contentPadding = contentPadding,
                messageResId = uiState.loadError.toPostSyncErrorMessageResId(),
                onRetry = onRetryLoad,
                onBack = onBack,
            )

            uiState.blockingReason != null -> PostSynchronizationBlockingState(
                contentPadding = contentPadding,
                reason = uiState.blockingReason,
                onBack = onBack,
            )

            else -> PostSynchronizationEditorContent(
                uiState = uiState,
                contentPadding = contentPadding,
                onTogglePlayback = onTogglePlayback,
                onSeekToPercent = onSeekToPercent,
                onSeekBackward = onSeekBackward,
                onSeekForward = onSeekForward,
                onFocusLine = onFocusLine,
                onJumpToLine = onJumpToLine,
                onClearLine = onClearLine,
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PostSynchronizationTopBar(
    canSave: Boolean,
    canOpenEditor: Boolean,
    isMoreMenuExpanded: Boolean,
    onBack: () -> Unit,
    onSave: () -> Unit,
    onMoreMenuExpandedChange: (Boolean) -> Unit,
    onClearAll: () -> Unit,
) {
    TopAppBar(
        title = {
            Text(
                text = stringResource(R.string.post_sync_title),
                style = MaterialTheme.typography.headlineSmall,
            )
        },
        navigationIcon = { BackIconButton(onClick = onBack) },
        actions = {
            TextButton(
                onClick = onSave,
                enabled = canSave,
            ) {
                Text(
                    text = stringResource(R.string.post_sync_save),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                )
            }
            Box {
                IconButton(
                    onClick = { onMoreMenuExpandedChange(true) },
                    enabled = canOpenEditor,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.MoreVert,
                        contentDescription = stringResource(R.string.post_sync_more_actions),
                    )
                }
                DropdownMenu(
                    expanded = isMoreMenuExpanded,
                    onDismissRequest = { onMoreMenuExpandedChange(false) },
                ) {
                    DropdownMenuItem(
                        text = { Text(text = stringResource(R.string.post_sync_clear_all_cta)) },
                        onClick = {
                            onMoreMenuExpandedChange(false)
                            onClearAll()
                        },
                    )
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.background,
        ),
    )
}

@Composable
private fun PostSynchronizationBottomBar(
    isSaving: Boolean,
    currentTimestampLabel: String,
    onPreviousLine: () -> Unit,
    onStampLine: () -> Unit,
    onNextLine: () -> Unit,
) {
    androidx.compose.material3.Surface(
        tonalElevation = 2.dp,
        shadowElevation = 6.dp,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = EterSpacing.medium, vertical = EterSpacing.medium),
            horizontalArrangement = Arrangement.spacedBy(EterSpacing.small),
        ) {
            SecondaryActionButton(
                text = stringResource(R.string.post_sync_previous_cta),
                modifier = Modifier.weight(1f),
                isSmall = true,
                onClick = onPreviousLine,
            )
            PrimaryActionButton(
                text = stringResource(R.string.post_sync_set_cta, currentTimestampLabel),
                modifier = Modifier.weight(1.35f),
                isSmall = true,
                isLoading = isSaving,
                onClick = onStampLine,
            )
            SecondaryActionButton(
                text = stringResource(R.string.post_sync_next_cta),
                modifier = Modifier.weight(1f),
                isSmall = true,
                onClick = onNextLine,
            )
        }
    }
}
