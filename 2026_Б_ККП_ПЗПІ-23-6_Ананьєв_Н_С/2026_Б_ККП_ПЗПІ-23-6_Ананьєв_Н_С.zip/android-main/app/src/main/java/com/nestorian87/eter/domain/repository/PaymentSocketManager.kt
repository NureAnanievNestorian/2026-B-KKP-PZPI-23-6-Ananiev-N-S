package com.nestorian87.eter.domain.repository

import com.nestorian87.eter.domain.model.PaymentSocketEvent
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

interface PaymentSocketManager {
    val events: SharedFlow<PaymentSocketEvent>
    val connected: StateFlow<Boolean>

    fun connect()

    fun disconnect()
}
