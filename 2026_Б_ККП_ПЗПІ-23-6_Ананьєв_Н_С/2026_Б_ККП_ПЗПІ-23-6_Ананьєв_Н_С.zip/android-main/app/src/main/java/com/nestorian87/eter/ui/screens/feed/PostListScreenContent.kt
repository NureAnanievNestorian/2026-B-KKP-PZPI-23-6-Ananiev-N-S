package com.nestorian87.eter.ui.screens.feed

import androidx.annotation.StringRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nestorian87.eter.R
import com.nestorian87.eter.domain.model.Post
import com.nestorian87.eter.domain.model.PostException
import com.nestorian87.eter.ui.components.buttons.BackIconButton
import com.nestorian87.eter.ui.components.buttons.PrimaryActionButton
import com.nestorian87.eter.ui.components.feedback.EterLoadingIndicator
import com.nestorian87.eter.ui.components.layout.PostCard
import com.nestorian87.eter.ui.components.layout.PostCardSkeleton
import com.nestorian87.eter.ui.components.layout.PostCardStyle
import com.nestorian87.eter.ui.components.layout.PostCardUiModel
import com.nestorian87.eter.ui.theme.EterSpacing
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull

enum class PostListVisualStyle {
    Standard,
    Editorial,
}

@Composable
fun PostListScreenContent(
    title: String,
    listState: PostListUiState,
    activePlaybackPostId: Long?,
    isActivePostPlaying: Boolean,
    emptyTitle: String,
    emptySubtitle: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    showHeader: Boolean = true,
    visualStyle: PostListVisualStyle = PostListVisualStyle.Standard,
    showHeaderLogo: Boolean = false,
    showSearchAction: Boolean = false,
    showNotificationsAction: Boolean = false,
    notificationsBadgeCount: Int = 0,
    controls: (@Composable () -> Unit)? = null,
    hideEmptyState: Boolean = false,
    emptyStateMinimal: Boolean = false,
    showEmptyRetryButton: Boolean = true,
    onRetry: () -> Unit,
    onLoadMore: () -> Unit,
    onToggleLike: (Long) -> Unit,
    onTogglePlayback: (Post) -> Unit,
    onOpenPost: (Long) -> Unit,
    onOpenComments: (Long) -> Unit,
    onCategoryClick: ((Long) -> Unit)? = null,
    onOpenAuthor: ((Long) -> Unit)? = null,
    onOpenSearch: (() -> Unit)? = null,
    onOpenNotifications: (() -> Unit)? = null,
    onBack: (() -> Unit)? = null,
) {
    val lazyListState = rememberLazyListState()
    val postCardStyle = when (visualStyle) {
        PostListVisualStyle.Standard -> PostCardStyle.Card
        PostListVisualStyle.Editorial -> PostCardStyle.EditorialRow
    }
    val listItemSpacing = when (visualStyle) {
        PostListVisualStyle.Standard -> EterSpacing.small
        PostListVisualStyle.Editorial -> 0.dp
    }
    val listBottomPadding = when (visualStyle) {
        PostListVisualStyle.Standard -> EterSpacing.hero
        PostListVisualStyle.Editorial -> EterSpacing.section
    }

    LaunchedEffect(
        lazyListState,
        listState.items.size,
        listState.isInitialLoading,
        listState.isLoadingMore,
        listState.canLoadMore,
    ) {
        if (listState.isInitialLoading) {
            return@LaunchedEffect
        }

        snapshotFlow {
            lazyListState.layoutInfo.visibleItemsInfo.lastOrNull()?.index
        }.filterNotNull()
            .distinctUntilChanged()
            .collect { lastVisibleIndex ->
                val triggerIndex = listState.items.lastIndex - 2
                if (lastVisibleIndex >= triggerIndex) {
                    onLoadMore()
                }
            }
    }

    Surface(
        modifier = modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
        ) {
            LazyColumn(
                state = lazyListState,
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(listItemSpacing),
                contentPadding = PaddingValues(
                    start = EterSpacing.medium,
                    end = EterSpacing.medium,
                    top = EterSpacing.medium,
                    bottom = listBottomPadding,
                ),
            ) {
                if (showHeader) {
                    item(key = "feed_header") {
                        PostListHeader(
                            title = title,
                            subtitle = subtitle,
                            visualStyle = visualStyle,
                            showHeaderLogo = showHeaderLogo,
                            showSearchAction = showSearchAction,
                            showNotificationsAction = showNotificationsAction,
                            notificationsBadgeCount = notificationsBadgeCount,
                            onOpenSearch = onOpenSearch,
                            onOpenNotifications = onOpenNotifications,
                            onBack = onBack,
                            controls = controls,
                        )
                    }
                }

                postListItems(
                    listState = listState,
                    activePlaybackPostId = activePlaybackPostId,
                    isActivePostPlaying = isActivePostPlaying,
                    emptyTitle = emptyTitle,
                    emptySubtitle = emptySubtitle,
                    postCardStyle = postCardStyle,
                    visualStyle = visualStyle,
                    hideEmptyState = hideEmptyState,
                    emptyStateMinimal = emptyStateMinimal,
                    showEmptyRetryButton = showEmptyRetryButton,
                    onRetry = onRetry,
                    onToggleLike = onToggleLike,
                    onTogglePlayback = onTogglePlayback,
                    onOpenPost = onOpenPost,
                    onOpenComments = onOpenComments,
                    onCategoryClick = onCategoryClick,
                    onOpenAuthor = onOpenAuthor?.let { callback -> { post -> callback(post.authorId) } },
                )
            }
        }
    }
}

fun LazyListScope.postListItems(
    listState: PostListUiState,
    activePlaybackPostId: Long?,
    isActivePostPlaying: Boolean,
    emptyTitle: String,
    emptySubtitle: String,
    postCardStyle: PostCardStyle,
    visualStyle: PostListVisualStyle,
    onRetry: () -> Unit,
    onToggleLike: (Long) -> Unit,
    onTogglePlayback: (Post) -> Unit,
    onOpenPost: (Long) -> Unit,
    onOpenComments: (Long) -> Unit,
    hideEmptyState: Boolean = false,
    emptyStateMinimal: Boolean = false,
    showEmptyRetryButton: Boolean = true,
    onCategoryClick: ((Long) -> Unit)? = null,
    onOpenAuthor: ((Post) -> Unit)? = null,
) {
    if (listState.isInitialLoading) {
        items(count = 4, key = { index -> "skeleton_$index" }) {
            PostCardSkeleton(style = postCardStyle)
        }
        return
    }

    if (listState.items.isEmpty()) {
        if (!hideEmptyState) {
            item(key = "feed_empty") {
                PostListEmptyState(
                    title = emptyTitle,
                    subtitle = emptySubtitle,
                    onRetry = onRetry,
                    minimal = emptyStateMinimal,
                    showRetryButton = showEmptyRetryButton,
                )
            }
        }
        return
    }

    items(
        items = listState.items,
        key = { item: PostCardUiModel -> item.post.postId },
    ) { item ->
        PostCard(
            item = item,
            isLikePending = listState.pendingLikePostIds.contains(item.post.postId),
            isPlaybackActive = activePlaybackPostId == item.post.postId,
            isPlaying = activePlaybackPostId == item.post.postId && isActivePostPlaying,
            onToggleLike = { onToggleLike(item.post.postId) },
            onTogglePlayback = { onTogglePlayback(item.post) },
            onOpenPost = { onOpenPost(item.post.postId) },
            onOpenComments = { onOpenComments(item.post.postId) },
            style = postCardStyle,
            onOpenAuthor = onOpenAuthor?.let { callback -> { callback(item.post) } },
            onCategoryClick = onCategoryClick,
        )
    }

    if (listState.isLoadingMore) {
        item(key = "loading_more") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = EterSpacing.small),
                horizontalArrangement = Arrangement.Center,
            ) {
                EterLoadingIndicator()
            }
        }
    }

    if (listState.error != null) {
        item(key = "error_footer") {
            PostListErrorFooter(
                messageResId = listState.error.toFeedMessageResId(),
                onRetry = onRetry,
                visualStyle = visualStyle,
            )
        }
    }
}

@Composable
private fun PostListHeader(
    title: String,
    subtitle: String?,
    visualStyle: PostListVisualStyle,
    showHeaderLogo: Boolean,
    showSearchAction: Boolean,
    showNotificationsAction: Boolean,
    notificationsBadgeCount: Int,
    onOpenSearch: (() -> Unit)?,
    onOpenNotifications: (() -> Unit)?,
    onBack: (() -> Unit)?,
    controls: (@Composable () -> Unit)?,
) {
    when (visualStyle) {
        PostListVisualStyle.Standard -> {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(
                        horizontal = EterSpacing.xSmall,
                        vertical = EterSpacing.small,
                    ),
                verticalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.headlineLarge,
                            color = MaterialTheme.colorScheme.onBackground,
                        )
                        subtitle?.let {
                            Text(
                                text = it,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.72f),
                            )
                        }
                    }
                }
                controls?.invoke()
            }
        }

        PostListVisualStyle.Editorial -> {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.background,
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = EterSpacing.xSmall, bottom = EterSpacing.xSmall),
                    verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(
                            modifier = Modifier.weight(1f, fill = false),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium),
                        ) {
                            if (onBack != null) {
                                BackIconButton(
                                    onClick = onBack,
                                    tint = MaterialTheme.colorScheme.onBackground,
                                )
                            }
                            if (showHeaderLogo) {
                                Image(
                                    painter = painterResource(R.drawable.ic_logo),
                                    contentDescription = stringResource(R.string.app_name),
                                    modifier = Modifier.size(42.dp),
                                )
                                Box(
                                    modifier = Modifier
                                        .size(width = 1.dp, height = 34.dp)
                                        .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.16f)),
                                )
                            }
                            Column(
                                verticalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                Text(
                                    text = title,
                                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.primary,
                                )
                                subtitle?.let {
                                    Text(
                                        text = it,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(
                                            alpha = 0.72f
                                        ),
                                    )
                                }
                            }
                        }
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            if (showSearchAction && onOpenSearch != null) {
                                EditorialHeaderActionButton(
                                    icon = Icons.Outlined.Search,
                                    contentDescription = stringResource(R.string.search),
                                    onClick = onOpenSearch,
                                )
                            }
                            if (showNotificationsAction && onOpenNotifications != null) {
                                EditorialHeaderActionButton(
                                    icon = Icons.Outlined.NotificationsNone,
                                    contentDescription = stringResource(R.string.notifications),
                                    badgeCount = notificationsBadgeCount,
                                    onClick = onOpenNotifications,
                                )
                            }
                        }
                    }

                    controls?.invoke()

                    HorizontalDivider(
                        thickness = 0.5.dp,
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.16f),
                    )
                }
            }
        }
    }
}

@Composable
private fun EditorialHeaderActionButton(
    icon: ImageVector,
    contentDescription: String,
    badgeCount: Int = 0,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(36.dp)
            .background(color = MaterialTheme.colorScheme.background, shape = CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = MaterialTheme.colorScheme.onBackground,
        )
        if (badgeCount > 0) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .background(
                        color = MaterialTheme.colorScheme.primary,
                        shape = CircleShape,
                    )
                    .padding(horizontal = 5.dp, vertical = 1.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = badgeCount.coerceAtMost(99).toString(),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onPrimary,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
private fun PostListEmptyState(
    title: String,
    subtitle: String,
    onRetry: () -> Unit,
    minimal: Boolean = false,
    showRetryButton: Boolean = true,
) {
    val topPadding = if (minimal) EterSpacing.medium else EterSpacing.section

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = topPadding),
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface,
        )
        if (!minimal) {
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (showRetryButton) {
                PrimaryActionButton(
                    text = stringResource(R.string.feed_retry),
                    onClick = onRetry,
                )
            }
        }
    }
}

@Composable
private fun PostListErrorFooter(
    @StringRes messageResId: Int,
    onRetry: () -> Unit,
    visualStyle: PostListVisualStyle,
) {
    val messageTextStyle = when (visualStyle) {
        PostListVisualStyle.Standard -> MaterialTheme.typography.bodyLarge
        PostListVisualStyle.Editorial -> MaterialTheme.typography.bodyMedium
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
    ) {
        Text(
            text = stringResource(messageResId),
            style = messageTextStyle,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        PrimaryActionButton(
            text = stringResource(R.string.feed_retry),
            onClick = onRetry,
        )
    }
}

internal fun Throwable.toFeedMessageResId(): Int = when ((this as? PostException)?.primaryReason) {
    PostException.Reason.NETWORK -> R.string.feed_error_network
    PostException.Reason.FORBIDDEN -> R.string.feed_error_forbidden
    else -> R.string.feed_error_generic
}
