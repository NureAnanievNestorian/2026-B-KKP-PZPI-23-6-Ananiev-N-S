package com.nestorian87.eter.ui.navigation

import android.content.Intent
import android.net.Uri
import androidx.core.net.toUri

object EterDeepLink {
    private const val EXTRA_URI = "eter_external_uri"
    private const val SCHEME = "eter"
    private const val HOST_POST = "post"
    private const val HOST_PROFILE = "profile"
    private const val WEB_SCHEME = "https"
    private const val WEB_HOST = "eter.pp.ua"
    private const val WEB_POSTS_SEGMENT = "posts"
    private const val QUERY_FOCUS_COMMENTS = "focusComments"
    private const val PROFILE_PREFIX = "@"

    fun postUri(postId: Long, focusComments: Boolean = false): Uri = Uri.Builder()
        .scheme(SCHEME)
        .authority(HOST_POST)
        .appendPath(postId.toString())
        .appendQueryParameter(QUERY_FOCUS_COMMENTS, focusComments.toString())
        .build()

    fun parsePostRequest(intent: Intent?): PostRequest? {
        val data = extractUri(intent) ?: return null
        return when {
            data.scheme == SCHEME && data.authority == HOST_POST -> {
                val postId = data.pathSegments.firstOrNull()?.toLongOrNull() ?: return null
                val focusComments = data.getBooleanQueryParameter(QUERY_FOCUS_COMMENTS, false)
                PostRequest(
                    postId = postId,
                    focusComments = focusComments,
                )
            }

            data.scheme == WEB_SCHEME &&
                    data.host == WEB_HOST &&
                    data.pathSegments.firstOrNull() == WEB_POSTS_SEGMENT -> {
                val postSegment = data.pathSegments.getOrNull(1) ?: return null
                val postId = postSegment.substringBefore('-').toLongOrNull() ?: return null
                PostRequest(
                    postId = postId,
                    focusComments = false,
                )
            }

            else -> null
        }
    }

    fun parseProfileRequest(intent: Intent?): ProfileRequest? {
        val data = extractUri(intent) ?: return null
        return when {
            data.scheme == SCHEME && data.authority == HOST_PROFILE -> {
                val username = data.pathSegments.firstOrNull()
                    ?.removePrefix(PROFILE_PREFIX)
                    ?.takeIf { it.isNotBlank() }
                    ?: return null
                ProfileRequest(username = username)
            }

            data.scheme == WEB_SCHEME &&
                    data.host == WEB_HOST &&
                    data.pathSegments.size == 1 &&
                    data.pathSegments.first().startsWith(PROFILE_PREFIX) -> {
                val username = data.pathSegments.first()
                    .removePrefix(PROFILE_PREFIX)
                    .takeIf { it.isNotBlank() }
                    ?: return null
                ProfileRequest(username = username)
            }

            else -> null
        }
    }

    fun postWebUri(
        postId: Long,
        slug: String,
    ): Uri = Uri.Builder()
        .scheme(WEB_SCHEME)
        .authority(WEB_HOST)
        .appendPath(WEB_POSTS_SEGMENT)
        .appendPath("$postId-$slug")
        .build()

    fun profileUri(username: String): Uri = Uri.Builder()
        .scheme(SCHEME)
        .authority(HOST_PROFILE)
        .appendPath(username.trim().removePrefix(PROFILE_PREFIX))
        .build()

    fun profileWebUri(username: String): Uri {
        val sanitizedUsername = username.trim().removePrefix(PROFILE_PREFIX)
        return "$WEB_SCHEME://$WEB_HOST/$PROFILE_PREFIX$sanitizedUsername".toUri()
    }

    fun isPaymentReturn(intent: Intent?): Boolean {
        val data = extractUri(intent) ?: return false
        return data.scheme == "https" &&
                data.host == "eter.pp.ua" &&
                data.path?.startsWith("/payments/return") == true
    }

    fun putUri(intent: Intent, uri: Uri) {
        intent.data = uri
        intent.putExtra(EXTRA_URI, uri.toString())
    }

    private fun extractUri(intent: Intent?): Uri? {
        val directData = intent?.data
        if (directData != null) {
            return directData
        }
        return intent?.getStringExtra(EXTRA_URI)?.toUri()
    }

    data class PostRequest(
        val postId: Long,
        val focusComments: Boolean,
    )

    data class ProfileRequest(
        val username: String,
    )
}
