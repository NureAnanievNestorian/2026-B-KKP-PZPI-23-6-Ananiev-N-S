package com.nestorian87.eter.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class UpdatePushNotificationSettingsRequestDto(
    val disabledTypes: List<String>,
)
