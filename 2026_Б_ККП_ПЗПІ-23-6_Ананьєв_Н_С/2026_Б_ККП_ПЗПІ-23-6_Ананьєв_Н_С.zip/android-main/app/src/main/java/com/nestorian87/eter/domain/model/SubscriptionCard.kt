package com.nestorian87.eter.domain.model

data class SubscriptionCard(
    val cardId: Long,
    val paymentSystem: String,
    val maskedNumber: String,
)
