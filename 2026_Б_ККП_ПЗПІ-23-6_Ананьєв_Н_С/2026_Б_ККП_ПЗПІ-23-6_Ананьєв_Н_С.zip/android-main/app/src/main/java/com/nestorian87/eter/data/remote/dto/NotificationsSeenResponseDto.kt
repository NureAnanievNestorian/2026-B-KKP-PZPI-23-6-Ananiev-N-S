package com.nestorian87.eter.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class NotificationsSeenResponseDto(
    val ok: Boolean,
    val unseenCount: Int = 0,
)
