package com.nestorian87.eter.domain.repository

import com.nestorian87.eter.domain.model.CheckoutResult
import com.nestorian87.eter.domain.model.Subscription
import com.nestorian87.eter.domain.model.SubscriptionTransactionsPage

interface PaymentRepository {
    suspend fun getSubscription(): Subscription?
    suspend fun createCheckout(): CheckoutResult
    suspend fun cancelSubscription()
    suspend fun getTransactions(offset: Int = 0, limit: Int = 20): SubscriptionTransactionsPage
    suspend fun updateCard(): CheckoutResult
}
