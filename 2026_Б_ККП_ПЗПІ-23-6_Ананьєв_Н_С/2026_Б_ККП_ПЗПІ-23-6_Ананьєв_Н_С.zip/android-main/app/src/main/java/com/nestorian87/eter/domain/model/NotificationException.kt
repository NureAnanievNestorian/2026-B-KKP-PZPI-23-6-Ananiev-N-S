package com.nestorian87.eter.domain.model

class NotificationException(
    val reasons: Set<Reason>,
    cause: Throwable? = null,
) : Exception(cause) {
    init {
        require(reasons.isNotEmpty()) { "NotificationException requires at least one reason" }
    }

    val primaryReason: Reason
        get() = reasons.first()

    enum class Reason {
        NETWORK,
        UNAUTHORIZED,
        NOT_FOUND,
        UNKNOWN,
    }
}
