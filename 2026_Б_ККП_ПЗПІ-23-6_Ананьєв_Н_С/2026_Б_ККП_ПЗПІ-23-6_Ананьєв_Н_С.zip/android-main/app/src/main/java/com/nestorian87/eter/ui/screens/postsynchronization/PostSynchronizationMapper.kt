package com.nestorian87.eter.ui.screens.postsynchronization

import com.nestorian87.eter.R
import com.nestorian87.eter.domain.model.PostException
import com.nestorian87.eter.domain.model.PostTextSynchronization
import com.nestorian87.eter.domain.model.UpdatePostTextSynchronizationPayload

fun buildSynchronizationPayload(
    localSynchronization: Map<Int, Int>,
): UpdatePostTextSynchronizationPayload = UpdatePostTextSynchronizationPayload(
    textSynchronization = localSynchronization
        .toList()
        .sortedBy { it.first }
        .map { (lineIndex, audioStartMomentMs) ->
            PostTextSynchronization(
                lineIndex = lineIndex,
                audioStartMomentMs = audioStartMomentMs,
            )
        },
)

internal fun formatTimestampMs(timestampMs: Int): String = (timestampMs / 1_000f).let { seconds ->
    val totalSeconds = seconds.toInt().coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val remainingSeconds = totalSeconds % 60
    "%02d:%02d".format(minutes, remainingSeconds)
}

internal fun Throwable.toPostSyncErrorMessageResId(): Int =
    when ((this as? PostException)?.primaryReason) {
        PostException.Reason.NETWORK -> R.string.post_error_network
        PostException.Reason.NOT_FOUND -> R.string.post_error_not_found
        PostException.Reason.FORBIDDEN -> R.string.post_error_forbidden
        else -> R.string.post_error_generic
    }

internal fun PostSynchronizationBlockingReason.toMessageResId(): Int = when (this) {
    PostSynchronizationBlockingReason.ACCESS_DENIED -> R.string.post_sync_access_denied
    PostSynchronizationBlockingReason.PREMIUM_REQUIRED -> R.string.post_sync_premium_required
    PostSynchronizationBlockingReason.POST_IS_PROCESSING -> R.string.post_sync_processing
    PostSynchronizationBlockingReason.MISSING_TEXT -> R.string.post_sync_missing_text
    PostSynchronizationBlockingReason.MISSING_AUDIO -> R.string.post_sync_missing_audio
}

internal fun PostSynchronizationValidationKind.toMessageResId(): Int = when (this) {
    PostSynchronizationValidationKind.MISSING -> R.string.post_sync_validation_missing
    PostSynchronizationValidationKind.OUT_OF_ORDER -> R.string.post_sync_validation_out_of_order
    PostSynchronizationValidationKind.EXCEEDS_DURATION -> R.string.post_sync_validation_exceeds_duration
}
