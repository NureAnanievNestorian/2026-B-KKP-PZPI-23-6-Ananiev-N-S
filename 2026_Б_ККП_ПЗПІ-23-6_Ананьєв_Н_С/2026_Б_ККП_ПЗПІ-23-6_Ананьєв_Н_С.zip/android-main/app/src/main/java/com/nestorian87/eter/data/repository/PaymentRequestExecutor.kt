package com.nestorian87.eter.data.repository

import com.nestorian87.eter.domain.model.PaymentException
import retrofit2.HttpException
import java.io.IOException

suspend inline fun <T> executePaymentRequest(
    crossinline httpErrorMapper: (error: HttpException) -> Throwable = {
        PaymentException(
            reasons = setOf(PaymentException.Reason.UNKNOWN),
            cause = it,
        )
    },
    crossinline block: suspend () -> T,
): T {
    try {
        return block()
    } catch (error: IOException) {
        throw PaymentException(
            reasons = setOf(PaymentException.Reason.NETWORK),
            cause = error,
        )
    } catch (error: HttpException) {
        throw httpErrorMapper(error)
    }
}
