package com.nestorian87.eter.ui.screens.profile

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.CreditCard
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.ReportProblem
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nestorian87.eter.R
import com.nestorian87.eter.domain.model.NotificationType
import com.nestorian87.eter.ui.components.buttons.BackIconButton
import com.nestorian87.eter.ui.components.dialog.EterBottomSheet
import com.nestorian87.eter.ui.components.feedback.EterLoadingIndicator
import com.nestorian87.eter.ui.screens.notifications.NotificationSettingsUiState
import com.nestorian87.eter.ui.screens.notifications.NotificationSettingsViewModel
import com.nestorian87.eter.ui.theme.EditorialPanelShape
import com.nestorian87.eter.ui.theme.EterPreview
import com.nestorian87.eter.ui.theme.EterScreenPreviews
import com.nestorian87.eter.ui.theme.EterSpacing
import com.nestorian87.eter.ui.theme.TouchShape

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    modifier: Modifier = Modifier,
    onBack: () -> Unit = {},
    onOpenEditProfile: () -> Unit = {},
    onManageSubscription: () -> Unit = {},
    onLoginRequested: () -> Unit = {},
    onOpenOwnProfile: () -> Unit = {},
    viewModel: ProfileViewModel = hiltViewModel<ProfileViewModel, ProfileViewModel.Factory> { factory ->
        factory.create(null, null)
    },
    notificationSettingsViewModel: NotificationSettingsViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val notificationSettingsUiState by notificationSettingsViewModel.uiState.collectAsStateWithLifecycle()
    var isNotificationSettingsVisible by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(viewModel) {
        viewModel.effects.collect { effect ->
            when (effect) {
                ProfileEffect.NavigateToLogin -> onLoginRequested()
                ProfileEffect.NavigateToOwnProfile -> onOpenOwnProfile()
                ProfileEffect.ProfileSaved -> Unit
                is ProfileEffect.ShareProfile -> Unit
            }
        }
    }

    SettingsScreenContent(
        uiState = uiState,
        modifier = modifier,
        onBack = onBack,
        onOpenEditProfile = onOpenEditProfile,
        onManageSubscription = onManageSubscription,
        onOpenNotificationSettings = {
            isNotificationSettingsVisible = true
            notificationSettingsViewModel.loadSettings()
        },
        notificationSettingsUiState = notificationSettingsUiState,
        isNotificationSettingsVisible = isNotificationSettingsVisible,
        onDismissNotificationSettings = { isNotificationSettingsVisible = false },
        onRetryNotificationSettings = { notificationSettingsViewModel.loadSettings(force = true) },
        onNotificationTypeEnabledChange = notificationSettingsViewModel::onTypeEnabledChange,
        onOpenViolations = viewModel::onOpenViolationsDialog,
        onDismissViolations = viewModel::onDismissViolationsDialog,
        onLogout = viewModel::onLogoutClick,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsScreenContent(
    uiState: ProfileUiState,
    onBack: () -> Unit,
    onOpenEditProfile: () -> Unit,
    onManageSubscription: () -> Unit,
    onOpenNotificationSettings: () -> Unit,
    notificationSettingsUiState: NotificationSettingsUiState,
    isNotificationSettingsVisible: Boolean,
    onDismissNotificationSettings: () -> Unit,
    onRetryNotificationSettings: () -> Unit,
    onNotificationTypeEnabledChange: (NotificationType, Boolean) -> Unit,
    onOpenViolations: () -> Unit,
    onDismissViolations: () -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val violationsSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val notificationSettingsSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    Box(
        modifier = modifier.fillMaxSize(),
    ) {
        if (uiState.isLoadingProfile && uiState.name.isBlank()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) {
                EterLoadingIndicator()
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    start = EterSpacing.medium,
                    end = EterSpacing.medium,
                    top = 0.dp,
                    bottom = EterSpacing.hero,
                ),
                verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
            ) {
                item(key = "settings_header") {
                    TopAppBar(
                        windowInsets = WindowInsets(0, 0, 0, 0),
                        title = {
                            Text(
                                text = stringResource(R.string.settings),
                                style = MaterialTheme.typography.headlineLarge,
                            )
                        },
                        navigationIcon = {
                            BackIconButton(onClick = onBack)
                        },
                        actions = {
                            IconButton(onClick = onLogout) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.Logout,
                                    contentDescription = stringResource(R.string.profile_logout_cta),
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.background,
                        ),
                    )
                }

                item(key = "settings_edit_profile") {
                    SettingsActionCard(
                        title = stringResource(R.string.profile_edit_cta),
                        subtitle = stringResource(R.string.settings_edit_profile_description),
                        icon = Icons.Rounded.Edit,
                        onClick = onOpenEditProfile,
                    )
                }

                item(key = "settings_manage_subscription") {
                    SettingsActionCard(
                        title = stringResource(R.string.manage_subscription),
                        subtitle = stringResource(R.string.settings_subscription_description),
                        icon = Icons.Rounded.CreditCard,
                        onClick = onManageSubscription,
                    )
                }

                item(key = "settings_notifications") {
                    SettingsActionCard(
                        title = stringResource(R.string.notification_settings_title),
                        subtitle = stringResource(R.string.notification_settings_description),
                        icon = Icons.Rounded.Notifications,
                        onClick = onOpenNotificationSettings,
                    )
                }

                item(key = "settings_violations") {
                    SettingsActionCard(
                        title = stringResource(R.string.profile_stat_violations),
                        subtitle = stringResource(
                            R.string.profile_violations_cta,
                            uiState.currentViolationsCount,
                            uiState.maxViolationsBeforeBlock,
                        ),
                        icon = Icons.Rounded.ReportProblem,
                        trailing = {
                            if (uiState.currentViolationsCount > 0) {
                                AssistChip(
                                    onClick = {},
                                    enabled = false,
                                    label = {
                                        Text(text = uiState.currentViolationsCount.toString())
                                    },
                                )
                            }
                        },
                        onClick = onOpenViolations,
                    )
                }
            }
        }
    }

    if (uiState.isViolationsDialogVisible) {
        EterBottomSheet(
            onDismissRequest = onDismissViolations,
            sheetState = violationsSheetState,
        ) {
            SettingsViolationsSheet(
                currentViolationsCount = uiState.currentViolationsCount,
                maxViolationsBeforeBlock = uiState.maxViolationsBeforeBlock,
                uiState = uiState.violationsDialog,
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding(),
            )
        }
    }

    if (isNotificationSettingsVisible) {
        EterBottomSheet(
            onDismissRequest = onDismissNotificationSettings,
            sheetState = notificationSettingsSheetState,
        ) {
            NotificationSettingsSheet(
                uiState = notificationSettingsUiState,
                onRetry = onRetryNotificationSettings,
                onTypeEnabledChange = onNotificationTypeEnabledChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding(),
            )
        }
    }
}

@Composable
private fun SettingsPanelCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    enabled: Boolean = true,
    content: @Composable () -> Unit,
) {
    if (onClick != null) {
        Surface(
            modifier = modifier.fillMaxWidth(),
            shape = EditorialPanelShape,
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.18f),
            border = BorderStroke(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f),
            ),
            onClick = onClick,
            enabled = enabled,
        ) {
            content()
        }
    } else {
        Surface(
            modifier = modifier.fillMaxWidth(),
            shape = EditorialPanelShape,
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.18f),
            border = BorderStroke(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f),
            ),
        ) {
            content()
        }
    }
}

@Composable
private fun SettingsActionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    trailing: (@Composable () -> Unit)? = null,
    onClick: () -> Unit,
) {
    SettingsPanelCard(
        modifier = modifier,
        onClick = onClick,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = EterSpacing.medium, vertical = EterSpacing.medium),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium),
        ) {
            Surface(
                modifier = Modifier.size(44.dp),
                shape = TouchShape,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                    )
                }
            }
            androidx.compose.foundation.layout.Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            trailing?.invoke()
        }
    }
}

@Composable
private fun NotificationSettingsSheet(
    uiState: NotificationSettingsUiState,
    onRetry: () -> Unit,
    onTypeEnabledChange: (NotificationType, Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyColumn(
        modifier = modifier.padding(horizontal = EterSpacing.medium),
        verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
        contentPadding = PaddingValues(bottom = EterSpacing.hero),
    ) {
        item(key = "notification_settings_header") {
            androidx.compose.foundation.layout.Column(
                verticalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
            ) {
                Text(
                    text = stringResource(R.string.notification_settings_title),
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = stringResource(R.string.notification_settings_sheet_description),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        if (uiState.error != null) {
            item(key = "notification_settings_error") {
                SettingsPanelCard {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(EterSpacing.medium),
                        horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = stringResource(R.string.notification_settings_error),
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        TextButton(onClick = onRetry) {
                            Text(text = stringResource(R.string.feed_retry))
                        }
                    }
                }
            }
        }

        if (uiState.isLoading) {
            item(key = "notification_settings_loading") {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(EterSpacing.large),
                    contentAlignment = Alignment.Center,
                ) {
                    EterLoadingIndicator()
                }
            }
        } else if (uiState.hasLoaded) {
            items(
                items = PushNotificationSettingType.entries,
                key = { it.notificationType.name },
            ) { item ->
                NotificationSettingRow(
                    item = item,
                    isEnabled = !uiState.disabledTypes.contains(item.notificationType),
                    enabled = !uiState.savingTypes.contains(item.notificationType),
                    onEnabledChange = { isEnabled ->
                        onTypeEnabledChange(item.notificationType, isEnabled)
                    },
                )
            }
        }
    }
}

@Composable
private fun NotificationSettingRow(
    item: PushNotificationSettingType,
    isEnabled: Boolean,
    enabled: Boolean,
    onEnabledChange: (Boolean) -> Unit,
) {
    SettingsPanelCard(
        onClick = { onEnabledChange(!isEnabled) },
        enabled = enabled,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(EterSpacing.medium),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium),
        ) {
            androidx.compose.foundation.layout.Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text(
                    text = stringResource(item.titleResId),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = stringResource(item.descriptionResId),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(
                checked = isEnabled,
                onCheckedChange = onEnabledChange,
                enabled = enabled,
            )
        }
    }
}

private enum class PushNotificationSettingType(
    val notificationType: NotificationType,
    val titleResId: Int,
    val descriptionResId: Int,
) {
    POST_LIKED(
        notificationType = NotificationType.POST_LIKED,
        titleResId = R.string.notification_settings_post_liked_title,
        descriptionResId = R.string.notification_settings_post_liked_description,
    ),
    POST_COMMENTED(
        notificationType = NotificationType.POST_COMMENTED,
        titleResId = R.string.notification_settings_post_commented_title,
        descriptionResId = R.string.notification_settings_post_commented_description,
    ),
    COMMENT_REPLIED(
        notificationType = NotificationType.COMMENT_REPLIED,
        titleResId = R.string.notification_settings_comment_replied_title,
        descriptionResId = R.string.notification_settings_comment_replied_description,
    ),
    COMMENT_LIKED(
        notificationType = NotificationType.COMMENT_LIKED,
        titleResId = R.string.notification_settings_comment_liked_title,
        descriptionResId = R.string.notification_settings_comment_liked_description,
    ),
    USER_FOLLOWED(
        notificationType = NotificationType.USER_FOLLOWED,
        titleResId = R.string.notification_settings_user_followed_title,
        descriptionResId = R.string.notification_settings_user_followed_description,
    ),
    POST_VIOLATION_CONFIRMED(
        notificationType = NotificationType.POST_VIOLATION_CONFIRMED,
        titleResId = R.string.notification_settings_post_violation_confirmed_title,
        descriptionResId = R.string.notification_settings_post_violation_confirmed_description,
    ),
}

@Composable
private fun SettingsViolationsSheet(
    currentViolationsCount: Int,
    maxViolationsBeforeBlock: Int,
    uiState: ProfileViolationsDialogUiState,
    modifier: Modifier = Modifier,
) {
    LazyColumn(
        modifier = modifier.padding(horizontal = EterSpacing.medium),
        verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
        contentPadding = PaddingValues(bottom = EterSpacing.hero),
    ) {
        item(key = "violations_summary") {
            SettingsPanelCard {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(EterSpacing.large),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ReportProblem,
                        contentDescription = null,
                        modifier = Modifier.size(28.dp),
                        tint = MaterialTheme.colorScheme.primary,
                    )
                    androidx.compose.foundation.layout.Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
                    ) {
                        Text(
                            text = stringResource(
                                R.string.profile_violations_cta,
                                currentViolationsCount,
                                maxViolationsBeforeBlock,
                            ),
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Text(
                            text = if (currentViolationsCount == 0) {
                                stringResource(R.string.profile_violations_none_summary)
                            } else {
                                stringResource(
                                    R.string.profile_violations_remaining_to_block,
                                    (maxViolationsBeforeBlock - currentViolationsCount).coerceAtLeast(
                                        0
                                    ),
                                )
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }

        when {
            uiState.isLoading -> {
                item(key = "violations_loading") {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(EterSpacing.large),
                        contentAlignment = Alignment.Center,
                    ) {
                        EterLoadingIndicator()
                    }
                }
            }

            uiState.items.isEmpty() -> {
                item(key = "violations_empty") {
                    SettingsPanelCard {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(EterSpacing.section),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = stringResource(R.string.profile_violations_empty),
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                }
            }

            else -> {
                items(uiState.items, key = { it.complaintId }) { item ->
                    SettingsPanelCard {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(EterSpacing.medium),
                            horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ReportProblem,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                            )
                            androidx.compose.foundation.layout.Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
                            ) {
                                Text(
                                    text = item.reasonLabel,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                                Text(
                                    text = item.postTitle,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                item.daysRemaining?.let { daysRemaining ->
                                    AssistChip(
                                        onClick = {},
                                        enabled = false,
                                        label = {
                                            Text(
                                                text = stringResource(
                                                    R.string.profile_violations_days_remaining,
                                                    daysRemaining,
                                                ),
                                            )
                                        },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item(key = "violations_note") {
            SettingsPanelCard {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(EterSpacing.large),
                    horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        text = stringResource(R.string.profile_violations_auto_expire_note),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@EterScreenPreviews
@Composable
private fun SettingsScreenPreview() {
    EterPreview {
        SettingsScreenContent(
            uiState = ProfileUiState(
                isLoadingProfile = false,
                name = "Ivan Petrenko",
                currentViolationsCount = 1,
                maxViolationsBeforeBlock = 3,
            ),
            onBack = {},
            onOpenEditProfile = {},
            onManageSubscription = {},
            onOpenNotificationSettings = {},
            notificationSettingsUiState = NotificationSettingsUiState(),
            isNotificationSettingsVisible = false,
            onDismissNotificationSettings = {},
            onRetryNotificationSettings = {},
            onNotificationTypeEnabledChange = { _, _ -> },
            onOpenViolations = {},
            onDismissViolations = {},
            onLogout = {},
        )
    }
}
