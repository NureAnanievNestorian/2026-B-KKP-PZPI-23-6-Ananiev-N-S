package com.nestorian87.eter.ui.screens.notifications

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nestorian87.eter.domain.model.NotificationType
import com.nestorian87.eter.domain.repository.NotificationRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class NotificationSettingsViewModel @Inject constructor(
    private val notificationRepository: NotificationRepository,
) : ViewModel() {
    private val _uiState = MutableStateFlow(NotificationSettingsUiState())
    val uiState: StateFlow<NotificationSettingsUiState> = _uiState.asStateFlow()

    private var hasLoaded = false
    private var saveRevision = 0

    fun loadSettings(force: Boolean = false) {
        if (!force && hasLoaded) {
            return
        }

        _uiState.update {
            it.copy(
                isLoading = true,
                error = null,
            )
        }
        viewModelScope.launch {
            runCatching {
                notificationRepository.getPushSettings()
            }.onSuccess { settings ->
                hasLoaded = true
                _uiState.update {
                    it.copy(
                        disabledTypes = settings.disabledTypes,
                        hasLoaded = true,
                        isLoading = false,
                        error = null,
                    )
                }
            }.onFailure { error ->
                if (error is CancellationException) {
                    throw error
                }
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error = error,
                    )
                }
            }
        }
    }

    fun onTypeEnabledChange(
        type: NotificationType,
        isEnabled: Boolean,
    ) {
        val currentState = _uiState.value
        if (
            currentState.isLoading ||
            currentState.savingTypes.contains(type) ||
            type == NotificationType.UNKNOWN
        ) {
            return
        }

        val revision = ++saveRevision
        val previousDisabledTypes = currentState.disabledTypes
        val nextDisabledTypes = if (isEnabled) {
            previousDisabledTypes - type
        } else {
            previousDisabledTypes + type
        }

        _uiState.update {
            it.copy(
                disabledTypes = nextDisabledTypes,
                savingTypes = it.savingTypes + type,
                error = null,
            )
        }
        viewModelScope.launch {
            runCatching {
                notificationRepository.updatePushSettings(disabledTypes = nextDisabledTypes)
            }.onSuccess { settings ->
                hasLoaded = true
                _uiState.update {
                    val currentDisabledTypes = if (revision == saveRevision) {
                        settings.disabledTypes
                    } else {
                        it.disabledTypes
                    }
                    it.copy(
                        disabledTypes = currentDisabledTypes,
                        hasLoaded = true,
                        savingTypes = it.savingTypes - type,
                        error = null,
                    )
                }
            }.onFailure { error ->
                if (error is CancellationException) {
                    throw error
                }
                _uiState.update {
                    it.copy(
                        disabledTypes = if (revision == saveRevision) {
                            previousDisabledTypes
                        } else {
                            it.disabledTypes
                        },
                        savingTypes = it.savingTypes - type,
                        error = error,
                    )
                }
            }
        }
    }
}
