package com.nestorian87.eter.domain.model

data class PostAudioAnalysis(
    val version: Int,
    val durationMs: Long,
    val frameMs: Int,
    val features: List<String> = emptyList(),
    val frames: String,
    val waveform: String,
    val accents: List<PostAudioAccent> = emptyList(),
    val silences: List<PostAudioSilence> = emptyList(),
)

data class PostAudioAccent(
    val timestampMs: Long,
    val intensity: Float,
)

data class PostAudioSilence(
    val startMs: Long,
    val endMs: Long,
)
