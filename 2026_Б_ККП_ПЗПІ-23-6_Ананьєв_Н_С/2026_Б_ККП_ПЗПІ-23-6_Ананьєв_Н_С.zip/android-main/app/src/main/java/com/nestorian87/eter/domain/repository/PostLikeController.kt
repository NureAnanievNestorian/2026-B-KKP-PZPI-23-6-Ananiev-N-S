package com.nestorian87.eter.domain.repository

import com.nestorian87.eter.domain.model.Post

interface PostLikeController {
    fun toggleLike(post: Post)
}
