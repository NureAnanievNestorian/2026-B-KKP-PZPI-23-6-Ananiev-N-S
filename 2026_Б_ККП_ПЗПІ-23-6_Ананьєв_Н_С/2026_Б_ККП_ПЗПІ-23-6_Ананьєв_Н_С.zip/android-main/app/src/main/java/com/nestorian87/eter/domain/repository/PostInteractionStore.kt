package com.nestorian87.eter.domain.repository

import com.nestorian87.eter.domain.model.Post
import com.nestorian87.eter.domain.model.PostInteractionOverride
import kotlinx.coroutines.flow.StateFlow

interface PostInteractionStore {
    val overrides: StateFlow<Map<Long, PostInteractionOverride>>

    fun apply(post: Post): Post

    fun ensureLikeBase(post: Post)

    fun isLikePending(postId: Long): Boolean

    fun updateLikeOptimistic(post: Post, shouldLike: Boolean)

    fun resolveLike(postId: Long, likesCount: Int, isLiked: Boolean)

    fun revertLike(post: Post)

    fun incrementListens(postId: Long)

    fun ensureListenBase(post: Post)
}
