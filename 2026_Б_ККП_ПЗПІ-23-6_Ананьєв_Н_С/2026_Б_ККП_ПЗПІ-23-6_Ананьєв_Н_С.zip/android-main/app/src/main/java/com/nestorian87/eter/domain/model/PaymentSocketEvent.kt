package com.nestorian87.eter.domain.model

sealed class PaymentSocketEvent {
    data class CheckoutCreated(val result: CheckoutResult) : PaymentSocketEvent()
    data class TransactionUpdated(val transaction: SubscriptionTransaction) : PaymentSocketEvent()
    data class CardLinked(
        val card: SubscriptionCard,
        val subscription: Subscription,
    ) : PaymentSocketEvent()
}
