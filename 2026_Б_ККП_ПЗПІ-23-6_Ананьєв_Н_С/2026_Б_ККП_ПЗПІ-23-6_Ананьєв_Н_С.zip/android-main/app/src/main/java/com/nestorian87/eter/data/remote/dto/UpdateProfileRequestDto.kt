package com.nestorian87.eter.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class UpdateProfileRequestDto(
    val name: String,
    val username: String,
    val bio: String? = null,
    val link: String? = null,
)
