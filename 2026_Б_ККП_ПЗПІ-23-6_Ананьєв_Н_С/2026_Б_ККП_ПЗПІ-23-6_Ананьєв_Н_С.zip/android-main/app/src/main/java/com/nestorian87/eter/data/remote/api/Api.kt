package com.nestorian87.eter.data.remote.api

import com.nestorian87.eter.data.remote.auth.NoAuth
import com.nestorian87.eter.data.remote.dto.ActiveViolationResponseDto
import com.nestorian87.eter.data.remote.dto.AuthResponseDto
import com.nestorian87.eter.data.remote.dto.CancelSubscriptionResponseDto
import com.nestorian87.eter.data.remote.dto.CheckoutResultDto
import com.nestorian87.eter.data.remote.dto.CommentLikeResponseDto
import com.nestorian87.eter.data.remote.dto.ComplaintReasonItemDto
import com.nestorian87.eter.data.remote.dto.CreateCommentRequestDto
import com.nestorian87.eter.data.remote.dto.CreateComplaintRequestDto
import com.nestorian87.eter.data.remote.dto.CreateComplaintResponseDto
import com.nestorian87.eter.data.remote.dto.DeleteAndroidPushTokenRequestDto
import com.nestorian87.eter.data.remote.dto.DeletePostResponseDto
import com.nestorian87.eter.data.remote.dto.EmailVerificationRequestDto
import com.nestorian87.eter.data.remote.dto.EmailVerificationStatusDto
import com.nestorian87.eter.data.remote.dto.ForgotPasswordRequestDto
import com.nestorian87.eter.data.remote.dto.GoogleMobileAuthRequestDto
import com.nestorian87.eter.data.remote.dto.ListenEndRequestDto
import com.nestorian87.eter.data.remote.dto.ListenEndResponseDto
import com.nestorian87.eter.data.remote.dto.ListenProgressRequestDto
import com.nestorian87.eter.data.remote.dto.ListenProgressResponseDto
import com.nestorian87.eter.data.remote.dto.ListenStartRequestDto
import com.nestorian87.eter.data.remote.dto.ListenStartResponseDto
import com.nestorian87.eter.data.remote.dto.LoginRequestDto
import com.nestorian87.eter.data.remote.dto.MyPostsResponseDto
import com.nestorian87.eter.data.remote.dto.NotificationsPageResponseDto
import com.nestorian87.eter.data.remote.dto.NotificationsSeenResponseDto
import com.nestorian87.eter.data.remote.dto.OkResponseDto
import com.nestorian87.eter.data.remote.dto.PopularPostsResponseDto
import com.nestorian87.eter.data.remote.dto.PostCategoryDto
import com.nestorian87.eter.data.remote.dto.PostCommentDto
import com.nestorian87.eter.data.remote.dto.PostCommentsResponseDto
import com.nestorian87.eter.data.remote.dto.PostDto
import com.nestorian87.eter.data.remote.dto.PostFeedResponseDto
import com.nestorian87.eter.data.remote.dto.PostLikeResponseDto
import com.nestorian87.eter.data.remote.dto.PostListResponseDto
import com.nestorian87.eter.data.remote.dto.ProfileFollowListPageResponseDto
import com.nestorian87.eter.data.remote.dto.ProfileMeDto
import com.nestorian87.eter.data.remote.dto.PublicConfigDto
import com.nestorian87.eter.data.remote.dto.PublicProfileDto
import com.nestorian87.eter.data.remote.dto.PushNotificationSettingsDto
import com.nestorian87.eter.data.remote.dto.RegisterAndroidPushTokenRequestDto
import com.nestorian87.eter.data.remote.dto.RegisterRequestDto
import com.nestorian87.eter.data.remote.dto.SubscriptionTransactionsResponseDto
import com.nestorian87.eter.data.remote.dto.UpdatePostRequestDto
import com.nestorian87.eter.data.remote.dto.UpdatePostTextSynchronizationRequestDto
import com.nestorian87.eter.data.remote.dto.UpdateProfileRequestDto
import com.nestorian87.eter.data.remote.dto.UpdatePushNotificationSettingsRequestDto
import com.nestorian87.eter.data.remote.dto.UpdatePushNotificationSettingsResponseDto
import okhttp3.MultipartBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Query

interface Api {

    @GET("config")
    suspend fun getPublicConfig(): PublicConfigDto

    @NoAuth
    @POST("auth/login")
    suspend fun login(
        @Body request: LoginRequestDto,
    ): AuthResponseDto

    @NoAuth
    @POST("auth/register")
    suspend fun register(
        @Body request: RegisterRequestDto,
    ): AuthResponseDto

    @NoAuth
    @POST("auth/google/mobile")
    suspend fun loginWithGoogle(
        @Body request: GoogleMobileAuthRequestDto,
    ): AuthResponseDto

    @NoAuth
    @POST("auth/refresh")
    suspend fun refresh(): AuthResponseDto

    @GET("auth/email/verify/request")
    suspend fun getEmailVerificationStatus(): EmailVerificationStatusDto

    @POST("auth/email/verify/request")
    suspend fun requestEmailVerificationCode()

    @POST("auth/email/verify")
    suspend fun verifyEmail(
        @Body request: EmailVerificationRequestDto,
    )

    @NoAuth
    @POST("auth/password/forgot")
    suspend fun requestPasswordReset(
        @Body request: ForgotPasswordRequestDto,
    )

    @PATCH("notifications/android-push/tokens")
    suspend fun registerAndroidPushToken(
        @Body request: RegisterAndroidPushTokenRequestDto,
    )

    @PATCH("notifications/android-push/tokens/delete")
    suspend fun deleteAndroidPushToken(
        @Body request: DeleteAndroidPushTokenRequestDto,
    )

    @GET("notifications/push/settings")
    suspend fun getPushNotificationSettings(): PushNotificationSettingsDto

    @PATCH("notifications/push/settings")
    suspend fun updatePushNotificationSettings(
        @Body request: UpdatePushNotificationSettingsRequestDto,
    ): UpdatePushNotificationSettingsResponseDto

    @GET("notifications")
    suspend fun getNotifications(
        @Query("limit") limit: Int? = null,
        @Query("cursor") cursor: String? = null,
        @Query("status") status: String? = null,
        @Query("type") type: String? = null,
    ): NotificationsPageResponseDto

    @PATCH("notifications/seen")
    suspend fun markAllNotificationsSeen(): NotificationsSeenResponseDto

    @PATCH("notifications/{notificationId}/seen")
    suspend fun markNotificationSeen(
        @Path("notificationId") notificationId: Long,
    ): NotificationsSeenResponseDto

    @PATCH("notifications/{notificationId}/read")
    suspend fun markNotificationRead(
        @Path("notificationId") notificationId: Long,
    ): OkResponseDto

    @PATCH("notifications/read-all")
    suspend fun markAllNotificationsRead(): OkResponseDto

    @GET("profile/me")
    suspend fun getProfileMe(): ProfileMeDto

    @PATCH("profile/me")
    suspend fun updateProfileMe(
        @Body request: UpdateProfileRequestDto,
    ): ProfileMeDto

    @Multipart
    @PATCH("profile/me/avatar")
    suspend fun updateProfileMeAvatar(
        @Part avatar: MultipartBody.Part,
    ): ProfileMeDto

    @DELETE("profile/me/avatar")
    suspend fun deleteProfileMeAvatar(): ProfileMeDto

    @GET("profile/{userId}")
    suspend fun getProfile(
        @Path("userId") userId: Long,
    ): PublicProfileDto

    @GET("profile/username/{username}")
    suspend fun getProfileByUsername(
        @Path("username") username: String,
    ): PublicProfileDto

    @POST("profile/{userId}/follow")
    suspend fun followProfile(
        @Path("userId") userId: Long,
    ): PublicProfileDto

    @DELETE("profile/{userId}/follow")
    suspend fun unfollowProfile(
        @Path("userId") userId: Long,
    ): PublicProfileDto

    @GET("profile/me/followers")
    suspend fun getMyFollowers(
        @Query("search") search: String? = null,
        @Query("cursor") cursor: String? = null,
        @Query("limit") limit: Int? = null,
    ): ProfileFollowListPageResponseDto

    @GET("profile/me/following")
    suspend fun getMyFollowing(
        @Query("search") search: String? = null,
        @Query("cursor") cursor: String? = null,
        @Query("limit") limit: Int? = null,
    ): ProfileFollowListPageResponseDto

    @GET("profile/{userId}/followers")
    suspend fun getFollowers(
        @Path("userId") userId: Long,
        @Query("search") search: String? = null,
        @Query("cursor") cursor: String? = null,
        @Query("limit") limit: Int? = null,
    ): ProfileFollowListPageResponseDto

    @GET("profile/{userId}/following")
    suspend fun getFollowing(
        @Path("userId") userId: Long,
        @Query("search") search: String? = null,
        @Query("cursor") cursor: String? = null,
        @Query("limit") limit: Int? = null,
    ): ProfileFollowListPageResponseDto

    @GET("profile/me/violations")
    suspend fun getMyViolations(): List<ActiveViolationResponseDto>

    @GET("complaints/reasons")
    suspend fun getComplaintReasons(): List<ComplaintReasonItemDto>

    @POST("complaints/{postId}")
    suspend fun createComplaint(
        @Path("postId") postId: Long,
        @Body request: CreateComplaintRequestDto,
    ): CreateComplaintResponseDto

    @GET("posts/categories")
    suspend fun getCategories(
        @Query("search") search: String? = null,
    ): List<PostCategoryDto>

    @Multipart
    @POST("posts")
    suspend fun createPost(
        @Part audio: MultipartBody.Part,
    ): PostDto

    @GET("posts/{postId}")
    suspend fun getPost(
        @Path("postId") postId: Long,
    ): PostDto

    @GET("posts/popular")
    suspend fun getPopularPosts(
        @Query("snapshotId") snapshotId: String? = null,
        @Query("cursor") cursor: String? = null,
        @Query("limit") limit: Int? = null,
    ): PopularPostsResponseDto

    @GET("posts/search")
    suspend fun searchPosts(
        @Query("search") search: String? = null,
        @Query("categoryId") categoryId: Long? = null,
        @Query("sortBy") sortBy: String? = null,
        @Query("offset") offset: Int? = null,
        @Query("limit") limit: Int? = null,
    ): PostListResponseDto

    @GET("posts/feed")
    suspend fun getSubscriptionFeed(
        @Query("cursor") cursor: String? = null,
        @Query("limit") limit: Int? = null,
    ): PostFeedResponseDto

    @GET("posts/liked")
    suspend fun getLikedPosts(
        @Query("offset") offset: Int? = null,
        @Query("limit") limit: Int? = null,
    ): PostListResponseDto

    @PATCH("posts/{postId}")
    suspend fun updatePost(
        @Path("postId") postId: Long,
        @Body request: UpdatePostRequestDto,
    ): PostDto

    @PATCH("posts/{postId}/text-synchronization")
    suspend fun updatePostTextSynchronization(
        @Path("postId") postId: Long,
        @Body request: UpdatePostTextSynchronizationRequestDto,
    ): PostDto

    @Multipart
    @PATCH("posts/{postId}/audio")
    suspend fun replacePostAudio(
        @Path("postId") postId: Long,
        @Part audio: MultipartBody.Part,
    ): PostDto

    @GET("posts/me")
    suspend fun getMyPosts(
        @Query("search") search: String? = null,
        @Query("status") status: String? = null,
        @Query("sortBy") sortBy: String? = null,
        @Query("sortOrder") sortOrder: String? = null,
        @Query("offset") offset: Int? = null,
        @Query("limit") limit: Int? = null,
    ): MyPostsResponseDto

    @GET("profile/{userId}/posts")
    suspend fun getProfilePosts(
        @Path("userId") userId: Long,
        @Query("sortBy") sortBy: String? = null,
        @Query("sortOrder") sortOrder: String? = null,
        @Query("authorType") authorType: String? = null,
        @Query("offset") offset: Int? = null,
        @Query("limit") limit: Int? = null,
    ): PostListResponseDto

    @GET("profile/username/{username}/posts")
    suspend fun getProfilePostsByUsername(
        @Path("username") username: String,
        @Query("sortBy") sortBy: String? = null,
        @Query("sortOrder") sortOrder: String? = null,
        @Query("authorType") authorType: String? = null,
        @Query("offset") offset: Int? = null,
        @Query("limit") limit: Int? = null,
    ): PostListResponseDto

    @POST("posts/{postId}/listen/start")
    suspend fun startListen(
        @Path("postId") postId: Long,
        @Body request: ListenStartRequestDto,
    ): ListenStartResponseDto

    @POST("posts/{postId}/listen/progress")
    suspend fun updateListenProgress(
        @Path("postId") postId: Long,
        @Body request: ListenProgressRequestDto,
    ): ListenProgressResponseDto

    @POST("posts/{postId}/listen/end")
    suspend fun endListen(
        @Path("postId") postId: Long,
        @Body request: ListenEndRequestDto,
    ): ListenEndResponseDto

    @GET("posts/{postId}/comments")
    suspend fun getPostComments(
        @Path("postId") postId: Long,
        @Query("limit") limit: Int? = null,
        @Query("cursor") cursor: String? = null,
        @Query("sort") sort: String? = null,
    ): PostCommentsResponseDto

    @GET("posts/comments/{commentId}/replies")
    suspend fun getCommentReplies(
        @Path("commentId") commentId: Long,
        @Query("limit") limit: Int? = null,
        @Query("cursor") cursor: String? = null,
        @Query("sort") sort: String? = null,
    ): PostCommentsResponseDto

    @POST("posts/{postId}/like")
    suspend fun likePost(
        @Path("postId") postId: Long,
    ): PostLikeResponseDto

    @DELETE("posts/{postId}/like")
    suspend fun unlikePost(
        @Path("postId") postId: Long,
    ): PostLikeResponseDto

    @POST("posts/{postId}/comments")
    suspend fun createComment(
        @Path("postId") postId: Long,
        @Body request: CreateCommentRequestDto,
    ): PostCommentDto

    @POST("posts/comments/{commentId}/like")
    suspend fun likeComment(
        @Path("commentId") commentId: Long,
    ): CommentLikeResponseDto

    @DELETE("posts/comments/{commentId}/like")
    suspend fun unlikeComment(
        @Path("commentId") commentId: Long,
    ): CommentLikeResponseDto

    @DELETE("posts/comments/{commentId}")
    suspend fun deleteComment(
        @Path("commentId") commentId: Long,
    ): DeletePostResponseDto

    @DELETE("posts/{postId}")
    suspend fun deletePost(
        @Path("postId") postId: Long,
    ): DeletePostResponseDto

    @NoAuth
    @POST("auth/logout")
    suspend fun logout()

    @GET("payments/subscription")
    suspend fun getSubscription(): Response<ResponseBody>

    @POST("payments/subscription/checkout")
    suspend fun createSubscriptionCheckout(): CheckoutResultDto

    @DELETE("payments/subscription")
    suspend fun cancelSubscription(): CancelSubscriptionResponseDto

    @GET("payments/subscription/transactions")
    suspend fun getSubscriptionTransactions(
        @Query("offset") offset: Int? = null,
        @Query("limit") limit: Int? = null,
    ): SubscriptionTransactionsResponseDto

    @POST("payments/subscription/card/update")
    suspend fun updateSubscriptionCard(): CheckoutResultDto
}
