package com.nestorian87.eter.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class PostAudioAnalysisDto(
    val version: Int,
    val durationMs: Long,
    val frameMs: Int,
    val features: List<String> = emptyList(),
    val frames: String,
    val waveform: String,
    val accents: List<List<Double>> = emptyList(),
    val silences: List<List<Long>> = emptyList(),
)
