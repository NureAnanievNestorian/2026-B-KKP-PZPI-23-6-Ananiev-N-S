package com.nestorian87.eter.ui.screens.feed

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nestorian87.eter.R
import com.nestorian87.eter.ui.app.PostPlayerViewModel
import com.nestorian87.eter.ui.screens.notifications.NotificationBadgeViewModel
import com.nestorian87.eter.ui.theme.EterPreview
import com.nestorian87.eter.ui.theme.EterScreenPreviews

@Composable
fun FeedScreen(
    modifier: Modifier = Modifier,
    onOpenPost: (Long) -> Unit = {},
    onOpenComments: (Long) -> Unit = {},
    onOpenSearch: () -> Unit = {},
    onOpenNotifications: () -> Unit = {},
    onOpenAuthor: (Long) -> Unit = {},
    onCategoryClick: ((Long) -> Unit)? = null,
    viewModel: FeedViewModel = hiltViewModel(),
    notificationBadgeViewModel: NotificationBadgeViewModel = hiltViewModel(),
    playerViewModel: PostPlayerViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val notificationBadgeCount by notificationBadgeViewModel.unseenCount.collectAsStateWithLifecycle()
    val playerUiState by playerViewModel.uiState.collectAsStateWithLifecycle()

    PostListScreenContent(
        title = stringResource(R.string.feed_popular_title),
        listState = uiState.posts,
        activePlaybackPostId = playerUiState.activePost?.postId,
        isActivePostPlaying = playerUiState.isPlaying,
        emptyTitle = stringResource(R.string.feed_empty_title),
        emptySubtitle = stringResource(R.string.feed_empty_subtitle),
        modifier = modifier,
        visualStyle = PostListVisualStyle.Editorial,
        showHeaderLogo = true,
        showSearchAction = true,
        showNotificationsAction = true,
        notificationsBadgeCount = notificationBadgeCount,
        onRetry = viewModel::loadInitial,
        onLoadMore = viewModel::onLoadMore,
        onToggleLike = viewModel::onToggleLike,
        onTogglePlayback = { post -> playerViewModel.togglePlayback(post) },
        onOpenPost = onOpenPost,
        onOpenComments = onOpenComments,
        onOpenAuthor = onOpenAuthor,
        onCategoryClick = onCategoryClick,
        onOpenSearch = onOpenSearch,
        onOpenNotifications = onOpenNotifications,
    )
}

@EterScreenPreviews
@Composable
private fun FeedScreenPreview() {
    EterPreview {
        PostListScreenContent(
            title = stringResource(R.string.feed_popular_title),
            listState = PostListUiState(
                isInitialLoading = false,
            ),
            activePlaybackPostId = null,
            isActivePostPlaying = false,
            emptyTitle = stringResource(R.string.feed_empty_title),
            emptySubtitle = stringResource(R.string.feed_empty_subtitle),
            visualStyle = PostListVisualStyle.Editorial,
            showHeaderLogo = true,
            showSearchAction = true,
            showNotificationsAction = true,
            notificationsBadgeCount = 3,
            onRetry = {},
            onLoadMore = {},
            onToggleLike = { _ -> },
            onTogglePlayback = { _ -> },
            onOpenPost = { _ -> },
            onOpenComments = { _ -> },
            onOpenSearch = {},
            onOpenNotifications = {},
        )
    }
}
