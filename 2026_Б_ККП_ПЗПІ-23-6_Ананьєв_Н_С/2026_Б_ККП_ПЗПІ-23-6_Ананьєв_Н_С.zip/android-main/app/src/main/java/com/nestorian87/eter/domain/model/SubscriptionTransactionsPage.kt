package com.nestorian87.eter.domain.model

data class SubscriptionTransactionsPage(
    val items: List<SubscriptionTransaction>,
    val total: Int,
    val offset: Int,
)
