package com.nestorian87.eter.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class NotificationsCountsResponseDto(
    val unreadCount: Int = 0,
    val unseenCount: Int = 0,
)
