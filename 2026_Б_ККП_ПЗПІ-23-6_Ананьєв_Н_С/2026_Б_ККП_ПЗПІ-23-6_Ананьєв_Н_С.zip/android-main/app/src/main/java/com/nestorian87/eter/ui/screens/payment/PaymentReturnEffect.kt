package com.nestorian87.eter.ui.screens.payment

sealed class PaymentReturnEffect {
    data object NavigateAway : PaymentReturnEffect()
}
