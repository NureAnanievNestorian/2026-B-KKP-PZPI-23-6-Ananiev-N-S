package com.nestorian87.eter.domain.model

data class NotificationsQuery(
    val limit: Int = 20,
    val cursor: String? = null,
    val status: NotificationStatus = NotificationStatus.ALL,
    val type: NotificationListType? = null,
)
