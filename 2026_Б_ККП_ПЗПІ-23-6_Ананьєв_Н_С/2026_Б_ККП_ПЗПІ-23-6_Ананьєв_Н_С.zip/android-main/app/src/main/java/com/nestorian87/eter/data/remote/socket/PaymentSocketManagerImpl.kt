package com.nestorian87.eter.data.remote.socket

import android.util.Log
import com.nestorian87.eter.BuildConfig
import com.nestorian87.eter.data.local.datastore.AuthSessionStore
import com.nestorian87.eter.data.mapper.toDomain
import com.nestorian87.eter.data.remote.dto.CardLinkedDto
import com.nestorian87.eter.data.remote.dto.CheckoutResultDto
import com.nestorian87.eter.data.remote.dto.SubscriptionTransactionDto
import com.nestorian87.eter.domain.model.PaymentSocketEvent
import com.nestorian87.eter.domain.repository.PaymentSocketManager
import io.socket.client.IO
import io.socket.client.Socket
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.json.Json
import java.net.URI
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PaymentSocketManagerImpl @Inject constructor(
    private val authSessionStore: AuthSessionStore,
    private val json: Json,
) : PaymentSocketManager {
    private val _events = MutableSharedFlow<PaymentSocketEvent>(extraBufferCapacity = 64)
    override val events: SharedFlow<PaymentSocketEvent> = _events.asSharedFlow()

    private val _connected = MutableStateFlow(false)
    override val connected: StateFlow<Boolean> = _connected.asStateFlow()

    private var socket: Socket? = null
    private var refCount = 0

    override fun connect() {
        refCount++
        if (refCount > 1) return
        val token = authSessionStore.accessToken ?: return
        disconnectSocket()

        val opts = IO.Options().apply {
            auth = mapOf("token" to token)
        }
        val serverUrl = BuildConfig.API_BASE_URL.trimEnd('/')

        socket = IO.socket(URI.create("$serverUrl/payments"), opts).also { s ->
            s.on(Socket.EVENT_CONNECT) { _connected.value = true }
            s.on(Socket.EVENT_DISCONNECT) { _connected.value = false }
            s.on(EVENT_CHECKOUT_CREATED) { args ->
                parseAndEmit<CheckoutResultDto>(args) {
                    PaymentSocketEvent.CheckoutCreated(it.toDomain())
                }
            }
            s.on(EVENT_TRANSACTION_UPDATED) { args ->
                parseAndEmit<SubscriptionTransactionDto>(args) {
                    PaymentSocketEvent.TransactionUpdated(it.toDomain())
                }
            }
            s.on(EVENT_CARD_LINKED) { args ->
                parseAndEmit<CardLinkedDto>(args) {
                    PaymentSocketEvent.CardLinked(
                        card = it.card.toDomain(),
                        subscription = it.subscription.toDomain(),
                    )
                }
            }
            s.connect()
        }
    }

    override fun disconnect() {
        refCount = (refCount - 1).coerceAtLeast(0)
        if (refCount > 0) return
        disconnectSocket()
    }

    private fun disconnectSocket() {
        socket?.apply {
            off()
            disconnect()
        }
        socket = null
        _connected.value = false
    }

    private inline fun <reified T> parseAndEmit(
        args: Array<Any>,
        crossinline transform: (T) -> PaymentSocketEvent,
    ) {
        val raw = args.firstOrNull()?.toString() ?: return
        val dto = runCatching { json.decodeFromString<T>(raw) }
            .onFailure { error ->
                Log.w(
                    PAYMENT_SOCKET_LOG_TAG,
                    "Failed to parse payment socket event payload: $raw",
                    error
                )
            }
            .getOrNull()
            ?: return
        _events.tryEmit(transform(dto))
    }

    private companion object {
        const val PAYMENT_SOCKET_LOG_TAG = "PaymentSocketManager"
        const val EVENT_CHECKOUT_CREATED = "checkout_created"
        const val EVENT_TRANSACTION_UPDATED = "transaction_updated"
        const val EVENT_CARD_LINKED = "card_linked"
    }
}
