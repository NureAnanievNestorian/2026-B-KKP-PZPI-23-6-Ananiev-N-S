package com.nestorian87.eter.domain.model

data class NotificationTargetRoutePayload(
    val postId: Long? = null,
    val postSlug: String? = null,
    val commentId: Long? = null,
    val postComplaintId: Long? = null,
    val username: String? = null,
)
