package com.nestorian87.eter.data.local.datastore

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import com.nestorian87.eter.domain.model.PendingPayment
import com.nestorian87.eter.domain.repository.PendingPaymentStore
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PendingPaymentStoreImpl @Inject constructor(
    private val dataStore: DataStore<Preferences>,
    private val json: Json,
) : PendingPaymentStore {
    override suspend fun read(): PendingPayment? =
        dataStore.data
            .catch { emit(emptyPreferences()) }
            .map { it[Key] }
            .first()
            ?.let { encoded ->
                runCatching {
                    json.decodeFromString(
                        PendingPayment.serializer(),
                        encoded
                    )
                }.getOrNull()
            }

    override suspend fun save(payment: PendingPayment) {
        dataStore.edit { it[Key] = json.encodeToString(PendingPayment.serializer(), payment) }
    }

    override suspend fun clear() {
        dataStore.edit { it.remove(Key) }
    }

    companion object {
        private val Key = stringPreferencesKey("pending_payment")
    }
}
