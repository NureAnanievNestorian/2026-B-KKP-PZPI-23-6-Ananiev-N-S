package com.nestorian87.eter.domain.model

data class ProfilePostsQuery(
    val sortBy: ProfilePostsSortBy = ProfilePostsSortBy.CREATED_AT,
    val sortOrder: SortOrder = SortOrder.DESC,
    val authorType: ProfilePostsAuthorType = ProfilePostsAuthorType.ALL,
    val offset: Int? = null,
    val limit: Int? = null,
)

enum class ProfilePostsSortBy {
    CREATED_AT,
    LISTENS,
}

enum class ProfilePostsAuthorType {
    ALL,
    AUTHOR,
    ORIGINAL,
}
