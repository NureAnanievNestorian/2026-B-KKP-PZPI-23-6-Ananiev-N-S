package com.nestorian87.eter.data.repository

import android.content.Context
import android.provider.Settings
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.google.firebase.messaging.FirebaseMessaging
import com.nestorian87.eter.BuildConfig
import com.nestorian87.eter.data.local.datastore.AuthSessionStore
import com.nestorian87.eter.data.local.datastore.PushTokenStore
import com.nestorian87.eter.data.remote.api.Api
import com.nestorian87.eter.data.remote.dto.DeleteAndroidPushTokenRequestDto
import com.nestorian87.eter.data.remote.dto.RegisterAndroidPushTokenRequestDto
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.tasks.await
import retrofit2.HttpException
import java.io.IOException
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AndroidPushTokenSyncer @Inject constructor(
    private val api: Api,
    private val authSessionStore: AuthSessionStore,
    private val pushTokenStore: PushTokenStore,
    private val workManager: WorkManager,
    @param:ApplicationContext private val context: Context,
) {
    suspend fun syncCurrentTokenIfAuthenticated() {
        val token = fetchFirebaseToken()
        if (token == null) {
            if (!authSessionStore.accessToken.isNullOrBlank()) {
                scheduleRetry()
            }
            return
        }
        syncTokenIfAuthenticated(token)
    }

    suspend fun syncTokenIfAuthenticated(token: String) {
        val normalizedToken = token.trim()
        if (normalizedToken.isEmpty()) {
            return
        }
        pushTokenStore.saveToken(normalizedToken)
        if (authSessionStore.accessToken.isNullOrBlank()) {
            return
        }
        val syncResult = runCatching {
            api.registerAndroidPushToken(
                request = RegisterAndroidPushTokenRequestDto(
                    token = normalizedToken,
                    deviceId = resolveDeviceId(),
                    appVersion = BuildConfig.VERSION_NAME,
                ),
            )
        }
        syncResult.onSuccess {
            cancelRetry()
        }.onFailure { error ->
            if (error.shouldRetryTokenSync()) {
                scheduleRetry()
            }
        }
    }

    suspend fun deleteStoredTokenIfAuthenticated() {
        val token = pushTokenStore.readToken() ?: fetchFirebaseToken() ?: return
        if (authSessionStore.accessToken.isNullOrBlank()) {
            return
        }
        val deleteResult = runCatching {
            api.deleteAndroidPushToken(
                request = DeleteAndroidPushTokenRequestDto(token = token),
            )
        }
        cancelRetry()
        deleteResult.onSuccess {
            pushTokenStore.clearToken()
        }
    }

    private suspend fun fetchFirebaseToken(): String? = runCatching {
        FirebaseMessaging.getInstance().token.await().trim().ifEmpty { null }
    }.getOrNull()

    private fun resolveDeviceId(): String? = Settings.Secure.getString(
        context.contentResolver,
        Settings.Secure.ANDROID_ID,
    )?.trim()?.takeIf { it.isNotEmpty() }

    private fun scheduleRetry() {
        workManager.enqueueUniqueWork(
            TOKEN_SYNC_WORK_NAME,
            ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<AndroidPushTokenSyncWorker>()
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build(),
                )
                .setBackoffCriteria(
                    BackoffPolicy.EXPONENTIAL,
                    TOKEN_SYNC_BACKOFF_MINUTES,
                    TimeUnit.MINUTES,
                )
                .build(),
        )
    }

    private fun cancelRetry() {
        workManager.cancelUniqueWork(TOKEN_SYNC_WORK_NAME)
    }

    private fun Throwable.shouldRetryTokenSync(): Boolean = when (this) {
        is IOException -> true
        is HttpException -> code() in 500..599
        else -> false
    }

    companion object {
        private const val TOKEN_SYNC_WORK_NAME = "android_push_token_sync"
        private const val TOKEN_SYNC_BACKOFF_MINUTES = 15L
    }
}
