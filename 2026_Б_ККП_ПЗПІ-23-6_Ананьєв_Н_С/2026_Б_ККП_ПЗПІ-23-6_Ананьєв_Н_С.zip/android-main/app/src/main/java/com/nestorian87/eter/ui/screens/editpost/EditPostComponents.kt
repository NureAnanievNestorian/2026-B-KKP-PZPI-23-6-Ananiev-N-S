package com.nestorian87.eter.ui.screens.editpost

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import androidx.compose.ui.unit.dp
import com.nestorian87.eter.R
import com.nestorian87.eter.ui.components.dialog.EterBottomSheet
import com.nestorian87.eter.ui.components.dialog.EterSheetTitle
import com.nestorian87.eter.ui.components.forms.SearchInputField
import com.nestorian87.eter.ui.theme.EditorialPanelShape
import com.nestorian87.eter.ui.theme.EterSpacing

@Composable
fun EditPostCategoryPickerTrigger(
    selectionSummary: String,
    onClick: () -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.18f),
        shape = EditorialPanelShape,
        border = BorderStroke(
            width = 1.dp,
            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f),
        ),
        onClick = onClick,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = EterSpacing.medium, vertical = EterSpacing.medium),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(MaterialTheme.shapes.small)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Rounded.Search,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                )
            }
            Spacer(modifier = Modifier.width(EterSpacing.medium))
            Column(
                modifier = Modifier.weight(1f),
            ) {
                Text(
                    text = stringResource(R.string.publish_categories_picker_cta),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                if (selectionSummary.isNotBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = selectionSummary,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditPostCategoryPickerSheet(
    uiState: EditPostUiState,
    onDismissRequest: () -> Unit,
    onCategorySearchChanged: (String) -> Unit,
    onCategorySelected: (EditPostCategoryUiState) -> Unit,
    onCategoryRemoved: (Long) -> Unit,
) {
    EterBottomSheet(onDismissRequest = onDismissRequest) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.82f)
                .imePadding()
                .padding(horizontal = EterSpacing.medium)
                .padding(bottom = EterSpacing.large),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
            ) {
                EterSheetTitle(
                    text = stringResource(R.string.publish_categories_title),
                    modifier = Modifier.weight(1f),
                )
                Text(
                    text = stringResource(
                        R.string.publish_categories_selected_count,
                        uiState.selectedCountLabel,
                    ),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(modifier = Modifier.height(EterSpacing.small))
            Text(
                text = stringResource(R.string.publish_categories_sheet_helper),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(EterSpacing.small))
            EditPostSearchField(
                value = uiState.categorySearchQuery,
                onValueChange = onCategorySearchChanged,
                placeholder = stringResource(R.string.publish_categories_search_placeholder),
            )
            if (uiState.selectedCategories.isNotEmpty()) {
                Spacer(modifier = Modifier.height(EterSpacing.medium))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(EterSpacing.small),
                    verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
                ) {
                    uiState.selectedCategories.forEach { category ->
                        EditPostSelectableChip(
                            text = category.categoryName,
                            selected = true,
                            onClick = { onCategoryRemoved(category.categoryId) },
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(EterSpacing.large))
            if (uiState.selectedCategories.size >= EditPostUiDefaults.CATEGORY_LIMIT) {
                EditPostCategoryLimitNotice()
                Spacer(modifier = Modifier.height(EterSpacing.small))
            }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = true),
            ) {
                Text(
                    text = stringResource(R.string.publish_categories_results_title),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Spacer(modifier = Modifier.height(EterSpacing.small))
                when {
                    uiState.isLoadingCategories -> {
                        Text(
                            text = stringResource(R.string.publish_categories_loading),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontStyle = FontStyle.Italic,
                        )
                    }

                    uiState.availableCategories.isNotEmpty() -> {
                        EditPostCategoryResultList(
                            modifier = Modifier.weight(1f, fill = true),
                            categories = uiState.availableCategories,
                            isSelectionLimitReached = uiState.selectedCategories.size >= EditPostUiDefaults.CATEGORY_LIMIT,
                            onCategorySelected = onCategorySelected,
                        )
                    }

                    else -> {
                        Text(
                            text = stringResource(R.string.publish_categories_empty),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun EditPostCategoryResultList(
    categories: List<EditPostCategoryUiState>,
    isSelectionLimitReached: Boolean,
    onCategorySelected: (EditPostCategoryUiState) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = rememberEditPostCategorySheetColors()

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = colors.listContainer,
        shape = MaterialTheme.shapes.medium,
        border = BorderStroke(
            width = 1.dp,
            color = colors.listBorder,
        ),
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxHeight(),
        ) {
            itemsIndexed(
                items = categories,
                key = { _, category -> category.categoryId },
            ) { index, category ->
                EditPostCategoryResultRow(
                    category = category,
                    enabled = !isSelectionLimitReached,
                    onClick = { onCategorySelected(category) },
                )
                if (index != categories.lastIndex) {
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.10f),
                    )
                }
            }
        }
    }
}

@Composable
fun EditPostCategoryLimitNotice() {
    val colors = rememberEditPostCategorySheetColors()

    Surface(
        color = colors.noticeBackground,
        shape = MaterialTheme.shapes.small,
        border = BorderStroke(
            width = 1.dp,
            color = colors.noticeBorder,
        ),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = EterSpacing.medium, vertical = EterSpacing.small),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = Icons.Rounded.Info,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
            )
            Spacer(modifier = Modifier.width(EterSpacing.small))
            Column {
                Text(
                    text = stringResource(R.string.publish_categories_limit_reached_title),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = stringResource(R.string.publish_categories_limit_reached_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
fun EditPostCategoryResultRow(
    category: EditPostCategoryUiState,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    val colors = rememberEditPostCategorySheetColors()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                enabled = enabled,
                onClick = onClick,
            )
            .padding(horizontal = EterSpacing.medium, vertical = EterSpacing.medium),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(
            modifier = Modifier.weight(1f),
        ) {
            Text(
                text = category.categoryName,
                style = MaterialTheme.typography.titleMedium,
                color = if (enabled) {
                    MaterialTheme.colorScheme.onSurface
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
            )
        }
        Spacer(modifier = Modifier.width(EterSpacing.medium))
        Row(
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (enabled) {
                Icon(
                    imageVector = Icons.Rounded.Add,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = stringResource(R.string.publish_categories_add_cta),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                )
            } else {
                Surface(
                    color = colors.disabledBadgeBackground,
                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    shape = MaterialTheme.shapes.small,
                ) {
                    Text(
                        text = stringResource(R.string.publish_categories_limit_reached_inline),
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    )
                }
            }
        }
    }
}

@Composable
fun EditPostSection(
    title: String,
    subtitle: String,
    content: @Composable () -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = EditorialPanelShape,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.18f),
        border = BorderStroke(
            width = 1.dp,
            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f),
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(EterSpacing.large),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(EterSpacing.medium))
            content()
        }
    }
}

@Composable
fun CopyrightRow(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    val primaryColor = MaterialTheme.colorScheme.primary
    val fullText = stringResource(R.string.publish_copyright_confirmation_text)
    val copyrightWord = stringResource(R.string.publish_copyright_clickable_word)
    val annotatedText = buildAnnotatedString {
        val idx = fullText.indexOf(copyrightWord, ignoreCase = true)
        if (idx < 0) {
            append(fullText)
        } else {
            append(fullText.substring(0, idx))
            withLink(
                LinkAnnotation.Url(
                    url = COPYRIGHT_POLICY_URL,
                    styles = TextLinkStyles(
                        style = SpanStyle(
                            color = primaryColor,
                            textDecoration = TextDecoration.Underline,
                        ),
                    ),
                )
            ) {
                append(fullText.substring(idx, idx + copyrightWord.length))
            }
            append(fullText.substring(idx + copyrightWord.length))
        }
    }

    Row(
        modifier = Modifier.clickable { onCheckedChange(!checked) },
        verticalAlignment = Alignment.Top,
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = null,
            colors = CheckboxDefaults.colors(
                checkedColor = MaterialTheme.colorScheme.primary,
                uncheckedColor = MaterialTheme.colorScheme.outline,
                checkmarkColor = MaterialTheme.colorScheme.onPrimary,
            ),
        )
        Spacer(modifier = Modifier.width(EterSpacing.small))
        Text(
            modifier = Modifier.padding(top = 10.dp),
            text = annotatedText,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface,
        )
    }
}

private const val COPYRIGHT_POLICY_URL = "https://eter.pp.ua/copyright"

@Composable
fun EditPostSearchField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
) {
    SearchInputField(
        value = value,
        onValueChange = onValueChange,
        placeholder = placeholder,
    )
}

@Composable
fun EditPostSelectableChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val colors = rememberEditPostCategorySheetColors()

    Surface(
        color = if (selected) {
            colors.selectedChipBackground
        } else {
            colors.idleChipBackground
        },
        contentColor = if (selected) {
            MaterialTheme.colorScheme.primary
        } else {
            MaterialTheme.colorScheme.onSurface
        },
        border = BorderStroke(
            width = 1.dp,
            color = if (selected) {
                colors.selectedChipBorder
            } else {
                colors.idleChipBorder
            },
        ),
        shape = MaterialTheme.shapes.small,
        modifier = Modifier.clickable(onClick = onClick),
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(
                horizontal = EterSpacing.medium,
                vertical = 10.dp,
            ),
        )
    }
}

@Composable
fun rememberEditPostCategorySheetColors(): EditPostCategorySheetColors {
    return EditPostCategorySheetColors(
        listContainer = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f),
        listBorder = MaterialTheme.colorScheme.outline.copy(alpha = 0.18f),
        inputBackground = MaterialTheme.colorScheme.background,
        inputBorder = MaterialTheme.colorScheme.outline.copy(alpha = 0.32f),
        selectedChipBackground = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f),
        selectedChipBorder = MaterialTheme.colorScheme.primary.copy(alpha = 0.72f),
        idleChipBackground = MaterialTheme.colorScheme.surface,
        idleChipBorder = MaterialTheme.colorScheme.outline.copy(alpha = 0.26f),
        noticeBackground = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.92f),
        noticeBorder = MaterialTheme.colorScheme.outline.copy(alpha = 0.22f),
        disabledBadgeBackground = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.88f),
    )
}

data class EditPostCategorySheetColors(
    val listContainer: Color,
    val listBorder: Color,
    val inputBackground: Color,
    val inputBorder: Color,
    val selectedChipBackground: Color,
    val selectedChipBorder: Color,
    val idleChipBackground: Color,
    val idleChipBorder: Color,
    val noticeBackground: Color,
    val noticeBorder: Color,
    val disabledBadgeBackground: Color,
)
