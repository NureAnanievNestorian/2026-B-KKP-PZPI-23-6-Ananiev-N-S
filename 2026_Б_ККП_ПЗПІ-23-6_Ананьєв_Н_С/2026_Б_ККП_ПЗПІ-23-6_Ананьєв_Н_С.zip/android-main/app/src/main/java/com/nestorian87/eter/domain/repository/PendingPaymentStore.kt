package com.nestorian87.eter.domain.repository

import com.nestorian87.eter.domain.model.PendingPayment

interface PendingPaymentStore {
    suspend fun read(): PendingPayment?

    suspend fun save(payment: PendingPayment)

    suspend fun clear()
}
