package com.nestorian87.eter.domain.model

enum class NotificationListType {
    COMMENTS,
    FOLLOWS,
    LIKES,
    SYSTEM,
}
