package com.nestorian87.eter.ui.screens.postsynchronization

data class SyncableLineUiModel(
    val position: Int,
    val lineIndex: Int,
    val text: String,
    val isLocked: Boolean,
)

enum class PostSynchronizationBlockingReason {
    ACCESS_DENIED,
    PREMIUM_REQUIRED,
    POST_IS_PROCESSING,
    MISSING_TEXT,
    MISSING_AUDIO,
}

enum class PostSynchronizationValidationKind {
    MISSING,
    OUT_OF_ORDER,
    EXCEEDS_DURATION,
}

data class PostSynchronizationValidationIssue(
    val kind: PostSynchronizationValidationKind,
)

fun buildSyncableLines(text: String): List<SyncableLineUiModel> {
    val lines = text.split('\n')
    return lines.mapIndexedNotNull { index, line ->
        val trimmed = line.trim()
        if (trimmed.isEmpty()) {
            null
        } else {
            SyncableLineUiModel(
                position = 0,
                lineIndex = index,
                text = line,
                isLocked = false,
            )
        }
    }.mapIndexed { position, line ->
        line.copy(
            position = position,
            isLocked = position == 0,
        )
    }
}
