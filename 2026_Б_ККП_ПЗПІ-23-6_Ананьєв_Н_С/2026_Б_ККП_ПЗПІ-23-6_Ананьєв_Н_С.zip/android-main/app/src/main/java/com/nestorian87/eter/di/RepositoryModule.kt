package com.nestorian87.eter.di

import com.nestorian87.eter.data.local.datastore.PendingPaymentStoreImpl
import com.nestorian87.eter.data.local.datastore.PostCommentDraftRepositoryImpl
import com.nestorian87.eter.data.local.editpost.EditPostDraftStore
import com.nestorian87.eter.data.media.AudioDraftStore
import com.nestorian87.eter.data.media.AudioRecorder
import com.nestorian87.eter.data.remote.socket.PaymentSocketManagerImpl
import com.nestorian87.eter.data.repository.AuthRepositoryImpl
import com.nestorian87.eter.data.repository.NotificationRepositoryImpl
import com.nestorian87.eter.data.repository.PaymentRepositoryImpl
import com.nestorian87.eter.data.repository.PostInteractionStoreImpl
import com.nestorian87.eter.data.repository.PostLikeControllerImpl
import com.nestorian87.eter.data.repository.PostRepositoryImpl
import com.nestorian87.eter.data.repository.ProfileRepositoryImpl
import com.nestorian87.eter.domain.repository.AudioDraftRepository
import com.nestorian87.eter.domain.repository.AudioRecorderRepository
import com.nestorian87.eter.domain.repository.AuthRepository
import com.nestorian87.eter.domain.repository.EditPostDraftRepository
import com.nestorian87.eter.domain.repository.NotificationRepository
import com.nestorian87.eter.domain.repository.PaymentRepository
import com.nestorian87.eter.domain.repository.PaymentSocketManager
import com.nestorian87.eter.domain.repository.PendingPaymentStore
import com.nestorian87.eter.domain.repository.PostCommentDraftRepository
import com.nestorian87.eter.domain.repository.PostInteractionStore
import com.nestorian87.eter.domain.repository.PostLikeController
import com.nestorian87.eter.domain.repository.PostRepository
import com.nestorian87.eter.domain.repository.ProfileRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindAuthRepository(
        impl: AuthRepositoryImpl,
    ): AuthRepository

    @Binds
    @Singleton
    abstract fun bindNotificationRepository(
        impl: NotificationRepositoryImpl,
    ): NotificationRepository

    @Binds
    @Singleton
    abstract fun bindPostRepository(
        impl: PostRepositoryImpl,
    ): PostRepository

    @Binds
    @Singleton
    abstract fun bindProfileRepository(
        impl: ProfileRepositoryImpl,
    ): ProfileRepository

    @Binds
    @Singleton
    abstract fun bindAudioDraftRepository(
        impl: AudioDraftStore,
    ): AudioDraftRepository

    @Binds
    @Singleton
    abstract fun bindAudioRecorderRepository(
        impl: AudioRecorder,
    ): AudioRecorderRepository

    @Binds
    @Singleton
    abstract fun bindEditPostDraftRepository(
        impl: EditPostDraftStore,
    ): EditPostDraftRepository

    @Binds
    @Singleton
    abstract fun bindPostCommentDraftRepository(
        impl: PostCommentDraftRepositoryImpl,
    ): PostCommentDraftRepository

    @Binds
    @Singleton
    abstract fun bindPaymentRepository(
        impl: PaymentRepositoryImpl,
    ): PaymentRepository

    @Binds
    @Singleton
    abstract fun bindPendingPaymentStore(
        impl: PendingPaymentStoreImpl,
    ): PendingPaymentStore

    @Binds
    @Singleton
    abstract fun bindPaymentSocketManager(
        impl: PaymentSocketManagerImpl,
    ): PaymentSocketManager

    @Binds
    @Singleton
    abstract fun bindPostInteractionStore(
        impl: PostInteractionStoreImpl,
    ): PostInteractionStore

    @Binds
    @Singleton
    abstract fun bindPostLikeController(
        impl: PostLikeControllerImpl,
    ): PostLikeController
}
