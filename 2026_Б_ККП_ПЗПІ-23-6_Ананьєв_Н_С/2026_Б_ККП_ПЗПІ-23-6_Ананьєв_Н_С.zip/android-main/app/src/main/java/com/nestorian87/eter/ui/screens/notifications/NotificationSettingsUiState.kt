package com.nestorian87.eter.ui.screens.notifications

import com.nestorian87.eter.domain.model.NotificationType

data class NotificationSettingsUiState(
    val disabledTypes: Set<NotificationType> = emptySet(),
    val hasLoaded: Boolean = false,
    val isLoading: Boolean = false,
    val savingTypes: Set<NotificationType> = emptySet(),
    val error: Throwable? = null,
)
