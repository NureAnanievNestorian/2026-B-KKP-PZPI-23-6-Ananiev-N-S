package com.nestorian87.eter.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nestorian87.eter.R
import com.nestorian87.eter.domain.model.Subscription
import com.nestorian87.eter.domain.model.SubscriptionCard
import com.nestorian87.eter.domain.model.SubscriptionStatus
import com.nestorian87.eter.domain.model.SubscriptionTransaction
import com.nestorian87.eter.domain.model.TransactionStatus
import com.nestorian87.eter.domain.model.TransactionType
import com.nestorian87.eter.domain.model.toCurrencySymbol
import com.nestorian87.eter.ui.components.buttons.BackIconButton
import com.nestorian87.eter.ui.components.buttons.PrimaryActionButton
import com.nestorian87.eter.ui.components.buttons.SecondaryActionButton
import com.nestorian87.eter.ui.components.dialog.EterConfirmationDialog
import com.nestorian87.eter.ui.components.feedback.EterLoadingIndicator
import com.nestorian87.eter.ui.components.layout.LabeledDivider
import com.nestorian87.eter.ui.theme.EditorialPanelShape
import com.nestorian87.eter.ui.theme.EterPreview
import com.nestorian87.eter.ui.theme.EterScreenPreviews
import com.nestorian87.eter.ui.theme.EterSpacing
import java.util.Locale

@Composable
fun SubscriptionManagementScreen(
    modifier: Modifier = Modifier,
    onBack: () -> Unit = {},
    onOpenPaymentWebView: (url: String, invoiceId: String, paymentType: String) -> Unit = { _, _, _ -> },
) {
    val viewModel: SubscriptionManagementViewModel = hiltViewModel()
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        viewModel.effects.collect { effect ->
            when (effect) {
                is SubscriptionManagementEffect.OpenUrl ->
                    onOpenPaymentWebView(effect.url, effect.invoiceId, effect.paymentType)
            }
        }
    }

    SubscriptionManagementScreenContent(
        uiState = uiState,
        onBack = onBack,
        onBuyPremium = viewModel::onBuyPremiumClick,
        onLoadMoreTransactions = viewModel::onLoadMoreTransactions,
        onCancelClick = viewModel::onCancelClick,
        onCancelDismiss = viewModel::onCancelDismiss,
        onCancelConfirm = viewModel::onCancelConfirm,
        onChangeCard = viewModel::onChangeCardClick,
        onRetry = viewModel::onRetryClick,
        modifier = modifier,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SubscriptionManagementScreenContent(
    uiState: SubscriptionManagementUiState,
    onBack: () -> Unit,
    onBuyPremium: () -> Unit,
    onLoadMoreTransactions: () -> Unit,
    onCancelClick: () -> Unit,
    onCancelDismiss: () -> Unit,
    onCancelConfirm: () -> Unit,
    onChangeCard: () -> Unit,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val isPremiumOrPastDue = uiState.subscription?.status?.let {
        it == SubscriptionStatus.ACTIVE || it == SubscriptionStatus.PAST_DUE
    } ?: false
    val title = if (isPremiumOrPastDue) {
        stringResource(R.string.subscription_manage_title)
    } else {
        stringResource(R.string.subscription_upgrade_title)
    }

    Scaffold(
        modifier = modifier,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                windowInsets = WindowInsets(0, 0, 0, 0),
                title = {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.headlineLarge,
                    )
                },
                navigationIcon = {
                    BackIconButton(onClick = onBack)
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                ),
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { innerPadding ->
        when {
            uiState.isLoading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentAlignment = Alignment.Center,
                ) {
                    EterLoadingIndicator()
                }
            }

            uiState.loadError != null -> {
                SubscriptionErrorContent(
                    error = uiState.loadError,
                    onRetry = onRetry,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(
                            start = EterSpacing.xxLarge,
                            top = EterSpacing.xSmall,
                            end = EterSpacing.xxLarge,
                            bottom = EterSpacing.xxLarge,
                        ),
                )
            }

            isPremiumOrPastDue -> {
                ManagementContent(
                    uiState = uiState,
                    onLoadMoreTransactions = onLoadMoreTransactions,
                    onCancelClick = onCancelClick,
                    onChangeCard = onChangeCard,
                    onRenewClick = onBuyPremium,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                )
            }

            else -> {
                UpgradeContent(
                    uiState = uiState,
                    onBuyPremium = onBuyPremium,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                )
            }
        }
    }

    if (uiState.showCancelDialog) {
        val cancelErrorText = when (uiState.cancelError) {
            "network" -> stringResource(R.string.subscription_error_network)
            "not_allowed" -> stringResource(R.string.subscription_error_cancel_not_allowed)
            else -> if (uiState.cancelError != null) stringResource(R.string.subscription_error_generic) else null
        }
        EterConfirmationDialog(
            title = stringResource(R.string.subscription_cancel_dialog_title),
            message = stringResource(R.string.subscription_cancel_dialog_message),
            confirmText = stringResource(R.string.subscription_cancel_dialog_confirm),
            dismissText = stringResource(R.string.subscription_cancel_dialog_dismiss),
            isConfirmLoading = uiState.isCancelLoading,
            errorMessage = cancelErrorText,
            onConfirm = onCancelConfirm,
            onDismiss = onCancelDismiss,
        )
    }
}

@Composable
private fun UpgradeContent(
    uiState: SubscriptionManagementUiState,
    onBuyPremium: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .padding(
                start = EterSpacing.xxLarge,
                top = EterSpacing.large,
                end = EterSpacing.xxLarge,
                bottom = EterSpacing.xxLarge,
            ),
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(EterSpacing.large),
        ) {
            CompactSubscriptionHeader(
                title = stringResource(R.string.subscription_upgrade_title),
                subtitle = stringResource(R.string.subscription_upgrade_subtitle),
            )

            PlanCard(
                title = stringResource(R.string.subscription_free_plan_label),
                accentColor = MaterialTheme.colorScheme.onSurface,
                features = listOf(
                    PlanFeature(
                        title = stringResource(R.string.subscription_feature_recording_title),
                        subtitle = uiState.freeDurationMinutes?.let {
                            stringResource(R.string.subscription_feature_recording_value, it)
                        },
                        available = false,
                    ),
                    PlanFeature(
                        title = stringResource(R.string.subscription_feature_text_sync_title),
                        subtitle = stringResource(R.string.subscription_feature_text_sync_free),
                        available = false,
                    ),
                ),
            )

            PlanCard(
                title = stringResource(R.string.subscription_premium_plan_label),
                accentColor = MaterialTheme.colorScheme.primary,
                features = listOf(
                    PlanFeature(
                        title = stringResource(R.string.subscription_feature_recording_title),
                        subtitle = uiState.premiumDurationMinutes?.let {
                            stringResource(R.string.subscription_feature_recording_value, it)
                        },
                        available = true,
                    ),
                    PlanFeature(
                        title = stringResource(R.string.subscription_feature_text_sync_title),
                        subtitle = stringResource(R.string.subscription_feature_text_sync_premium),
                        available = true,
                    ),
                ),
            )
        }

        Spacer(modifier = Modifier.weight(1f))

        Column(
            verticalArrangement = Arrangement.spacedBy(EterSpacing.large),
        ) {
            LabeledDivider(text = stringResource(R.string.subscription_cancel_anytime))

            uiState.priceUsd?.let { price ->
                Text(
                    text = stringResource(
                        R.string.subscription_price_per_month,
                        price.formatPrice()
                    ),
                    style = MaterialTheme.typography.headlineMedium.copy(
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            PrimaryActionButton(
                text = stringResource(R.string.subscription_buy_cta),
                isLoading = uiState.isCheckoutLoading,
                enabled = !uiState.isCheckoutLoading,
                onClick = onBuyPremium,
            )
        }
    }
}

@Composable
private fun PlanCard(
    title: String,
    accentColor: Color,
    features: List<PlanFeature>,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = EditorialPanelShape,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.18f),
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f),
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(EterSpacing.large),
            verticalArrangement = Arrangement.spacedBy(EterSpacing.medium),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = accentColor,
            )
            features.forEach { feature ->
                PlanFeatureRow(feature = feature)
            }
        }
    }
}

@Composable
private fun PlanFeatureRow(
    feature: PlanFeature,
    modifier: Modifier = Modifier,
) {
    val iconBg = if (feature.available) {
        MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.12f)
    }
    val iconTint = if (feature.available) {
        MaterialTheme.colorScheme.primary
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant
    }

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(EterSpacing.small),
        verticalAlignment = Alignment.Top,
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(iconBg),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = if (feature.available) Icons.Filled.Check else Icons.Filled.Close,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(16.dp),
            )
        }
        Column(
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text(
                text = feature.title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                color = MaterialTheme.colorScheme.onSurface,
            )
            feature.subtitle?.let { subtitle ->
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun ManagementContent(
    uiState: SubscriptionManagementUiState,
    onLoadMoreTransactions: () -> Unit,
    onCancelClick: () -> Unit,
    onChangeCard: () -> Unit,
    onRenewClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = EterSpacing.xxLarge,
            top = EterSpacing.xSmall,
            end = EterSpacing.xxLarge,
            bottom = EterSpacing.xxLarge,
        ),
        verticalArrangement = Arrangement.spacedBy(EterSpacing.xxLarge),
    ) {
        item {
            SubscriptionStatusSection(
                subscription = uiState.subscription,
                isCheckoutLoading = uiState.isCheckoutLoading,
                onCancelClick = onCancelClick,
                onRenewClick = onRenewClick,
            )
        }

        if (uiState.subscription?.status == SubscriptionStatus.PAST_DUE) {
            item {
                PastDueNotice()
            }
        }

        uiState.subscription?.card?.let { card ->
            item {
                PaymentCardSection(
                    paymentSystem = card.paymentSystem,
                    maskedNumber = card.maskedNumber,
                    isLoading = uiState.isCardUpdateLoading,
                    onChangeCard = onChangeCard,
                )
            }
        } ?: if (uiState.isCardLinking) {
            item {
                SectionCard(title = stringResource(R.string.subscription_payment_card_title)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = EterSpacing.medium),
                        contentAlignment = Alignment.Center,
                    ) {
                        EterLoadingIndicator()
                    }
                }
            }
        } else {
            item {
                SectionCard(title = stringResource(R.string.subscription_payment_card_title)) {
                    Text(
                        text = stringResource(R.string.subscription_no_card),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        if (uiState.isTransactionsLoading) {
            item {
                SectionCard(title = stringResource(R.string.subscription_transactions_title)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = EterSpacing.large),
                        contentAlignment = Alignment.Center,
                    ) {
                        EterLoadingIndicator()
                    }
                }
            }
        } else if (uiState.transactions.isEmpty()) {
            item {
                SectionCard(title = stringResource(R.string.subscription_transactions_title)) {
                    Text(
                        text = stringResource(R.string.subscription_transactions_empty),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        } else {
            item {
                Text(
                    text = stringResource(R.string.subscription_transactions_title),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
            }
            itemsIndexed(
                items = uiState.transactions,
                key = { _, transaction -> transaction.transactionId },
            ) { index, transaction ->
                if (
                    index >= uiState.transactions.lastIndex - 2 &&
                    uiState.canLoadMoreTransactions &&
                    !uiState.isLoadingMoreTransactions
                ) {
                    LaunchedEffect(
                        index,
                        uiState.transactions.size,
                        uiState.canLoadMoreTransactions
                    ) {
                        onLoadMoreTransactions()
                    }
                }

                SectionCard(title = transaction.createdAt.formatIsoToDisplay()) {
                    TransactionRow(transaction = transaction)
                }
            }
            if (uiState.isLoadingMoreTransactions) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = EterSpacing.small),
                        contentAlignment = Alignment.Center,
                    ) {
                        EterLoadingIndicator()
                    }
                }
            }
        }
    }
}

@Composable
private fun SubscriptionStatusSection(
    subscription: Subscription?,
    isCheckoutLoading: Boolean,
    onCancelClick: () -> Unit,
    onRenewClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val status = subscription?.status ?: SubscriptionStatus.UNKNOWN
    val isPastDue = status == SubscriptionStatus.PAST_DUE
    val hasAction = status == SubscriptionStatus.ACTIVE || isPastDue

    val statusLabel = stringResource(
        when (status) {
            SubscriptionStatus.ACTIVE -> R.string.subscription_status_active
            SubscriptionStatus.PAST_DUE -> R.string.subscription_status_past_due
            SubscriptionStatus.CANCELLED -> R.string.subscription_status_cancelled
            SubscriptionStatus.CREATED -> R.string.subscription_status_created
            SubscriptionStatus.EXPIRED -> R.string.subscription_status_expired
            SubscriptionStatus.UNKNOWN -> R.string.subscription_status_unknown
        },
    )
    val statusColor = when (status) {
        SubscriptionStatus.ACTIVE -> Color(0xFF4CAF50)
        SubscriptionStatus.PAST_DUE -> MaterialTheme.colorScheme.error
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    SectionCard(
        title = stringResource(R.string.subscription_status_label, statusLabel),
        modifier = modifier,
        titleColor = statusColor,
    ) {
        subscription?.nextPaymentDate?.let { date ->
            Text(
                text = stringResource(
                    R.string.subscription_next_payment_label,
                    date.formatYmdToDisplay()
                ),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary,
            )
        }
        subscription?.cancellationDate?.let { date ->
            Text(
                text = stringResource(
                    R.string.subscription_cancellation_label,
                    date.formatYmdToDisplay()
                ),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (hasAction) {
            Spacer(modifier = Modifier.height(EterSpacing.small))
            if (isPastDue) {
                PrimaryActionButton(
                    text = stringResource(R.string.subscription_renew_cta),
                    isLoading = isCheckoutLoading,
                    enabled = !isCheckoutLoading,
                    onClick = onRenewClick,
                )
            } else {
                SecondaryActionButton(
                    text = stringResource(R.string.subscription_cancel_cta),
                    onClick = onCancelClick,
                    outlineColor = MaterialTheme.colorScheme.error,
                )
            }
        }
    }
}

@Composable
private fun PastDueNotice(modifier: Modifier = Modifier) {
    Text(
        text = stringResource(R.string.subscription_past_due_notice),
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.error,
        modifier = modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.small)
            .background(MaterialTheme.colorScheme.error.copy(alpha = 0.08f))
            .padding(EterSpacing.medium),
    )
}

@Composable
private fun PaymentCardSection(
    paymentSystem: String,
    maskedNumber: String,
    isLoading: Boolean,
    onChangeCard: () -> Unit,
    modifier: Modifier = Modifier,
) {
    SectionCard(
        title = stringResource(R.string.subscription_payment_card_title),
        modifier = modifier,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = EterSpacing.xSmall),
            horizontalArrangement = Arrangement.spacedBy(EterSpacing.medium),
            verticalAlignment = Alignment.Top,
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text(
                    text = paymentSystem.uppercase(),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary,
                )
                Text(
                    text = maskedNumber,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
            }
            SecondaryActionButton(
                text = stringResource(R.string.subscription_change_card_cta),
                enabled = !isLoading,
                onClick = onChangeCard,
                modifier = Modifier.width(120.dp),
            )
        }
    }
}

@Composable
private fun TransactionRow(
    transaction: SubscriptionTransaction,
    modifier: Modifier = Modifier,
) {
    val statusText = stringResource(
        when (transaction.status) {
            TransactionStatus.SUCCESS -> R.string.subscription_transaction_status_success
            TransactionStatus.FAILURE -> R.string.subscription_transaction_status_failure
            TransactionStatus.PROCESSING -> R.string.subscription_transaction_status_processing
            TransactionStatus.CREATED -> R.string.subscription_transaction_status_pending
            TransactionStatus.HOLD -> R.string.subscription_transaction_status_hold
            TransactionStatus.REVERSED -> R.string.subscription_transaction_status_reversed
            TransactionStatus.EXPIRED -> R.string.subscription_transaction_status_expired
            TransactionStatus.UNKNOWN, null -> R.string.subscription_transaction_status_unknown
        },
    )
    val statusColor = when (transaction.status) {
        TransactionStatus.SUCCESS -> Color(0xFF4CAF50)
        TransactionStatus.FAILURE -> MaterialTheme.colorScheme.error
        else -> MaterialTheme.colorScheme.onSurface
    }
    val amountText =
        "${transaction.amount.formatAmount()}${transaction.currency.toCurrencySymbol()}"

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = EterSpacing.xSmall),
        verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
    ) {
        TransactionDetailRow(
            label = stringResource(R.string.subscription_transaction_amount_label),
            value = amountText,
            valueColor = MaterialTheme.colorScheme.onSurface,
            valueStyle = MaterialTheme.typography.titleMedium,
        )
        TransactionDetailRow(
            label = stringResource(R.string.subscription_transaction_status_label),
            value = statusText,
            valueColor = statusColor,
            valueStyle = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
        )
    }
}

@Composable
private fun SubscriptionErrorContent(
    error: String,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val errorText = when (error) {
        "network" -> stringResource(R.string.subscription_error_network)
        else -> stringResource(R.string.subscription_error_generic)
    }
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            text = errorText,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(EterSpacing.xxLarge))
        PrimaryActionButton(
            text = stringResource(R.string.subscription_retry_cta),
            onClick = onRetry,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun SectionCard(
    title: String,
    modifier: Modifier = Modifier,
    titleColor: Color = MaterialTheme.colorScheme.onSurface,
    content: @Composable ColumnScope.() -> Unit,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = EditorialPanelShape,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.18f),
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f),
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(EterSpacing.large),
            verticalArrangement = Arrangement.spacedBy(EterSpacing.small),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                color = titleColor,
            )
            content()
        }
    }
}

@Composable
private fun CompactSubscriptionHeader(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(EterSpacing.xSmall),
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun TransactionDetailRow(
    label: String,
    value: String,
    valueColor: Color,
    valueStyle: androidx.compose.ui.text.TextStyle,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            text = value,
            style = valueStyle,
            color = valueColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

private data class PlanFeature(
    val title: String,
    val subtitle: String?,
    val available: Boolean,
)

private fun String.formatYmdToDisplay(): String {
    if (length < 10 || this[4] != '-') return this
    val parts = substring(0, 10).split("-")
    return "${parts[2]}.${parts[1]}.${parts[0]}"
}

private fun String.formatIsoToDisplay(): String = take(10).formatYmdToDisplay()

private fun String.formatAmount(): String {
    val cents = toLongOrNull() ?: return this
    val value = cents / 100.0
    return if (value % 1.0 == 0.0) {
        value.toLong().toString()
    } else {
        String.format(Locale.US, "%.2f", value)
    }
}

private fun Int.formatPrice(): String {
    val dollars = this / 100.0
    return if (dollars % 1.0 == 0.0) {
        dollars.toLong().toString()
    } else {
        String.format(Locale.US, "%.2f", dollars)
    }
}

@EterScreenPreviews
@Composable
private fun SubscriptionUpgradePreview() {
    EterPreview {
        SubscriptionManagementScreenContent(
            uiState = SubscriptionManagementUiState(
                isLoading = false,
                priceUsd = 500,
                freeDurationMinutes = 7,
                premiumDurationMinutes = 15,
            ),
            onBack = {},
            onBuyPremium = {},
            onLoadMoreTransactions = {},
            onCancelClick = {},
            onCancelDismiss = {},
            onCancelConfirm = {},
            onChangeCard = {},
            onRetry = {},
        )
    }
}

@EterScreenPreviews
@Composable
private fun SubscriptionManagementPreview() {
    EterPreview {
        SubscriptionManagementScreenContent(
            uiState = SubscriptionManagementUiState(
                isLoading = false,
                subscription = Subscription(
                    subscriptionId = 1,
                    userId = 1,
                    status = SubscriptionStatus.ACTIVE,
                    startDate = "2025-03-02",
                    nextPaymentDate = "2025-04-02",
                    cancellationDate = null,
                    walletId = null,
                    card = SubscriptionCard(
                        cardId = 1,
                        paymentSystem = "Visa",
                        maskedNumber = "•••• 4242",
                    ),
                ),
                transactions = listOf(
                    SubscriptionTransaction(
                        transactionId = 1,
                        invoiceId = "inv1",
                        status = TransactionStatus.SUCCESS,
                        type = TransactionType.CHARGE,
                        amount = "500",
                        currency = "USD",
                        isCardUpdating = false,
                        modifiedDate = null,
                        createdAt = "2025-03-02T10:00:00.000Z",
                        updatedAt = "2025-03-02T10:00:00.000Z",
                    ),
                    SubscriptionTransaction(
                        transactionId = 2,
                        invoiceId = "inv2",
                        status = TransactionStatus.FAILURE,
                        type = TransactionType.CHARGE,
                        amount = "500",
                        currency = "USD",
                        isCardUpdating = false,
                        modifiedDate = null,
                        createdAt = "2025-02-02T10:00:00.000Z",
                        updatedAt = "2025-02-02T10:00:00.000Z",
                    ),
                ),
            ),
            onBack = {},
            onBuyPremium = {},
            onLoadMoreTransactions = {},
            onCancelClick = {},
            onCancelDismiss = {},
            onCancelConfirm = {},
            onChangeCard = {},
            onRetry = {},
        )
    }
}
