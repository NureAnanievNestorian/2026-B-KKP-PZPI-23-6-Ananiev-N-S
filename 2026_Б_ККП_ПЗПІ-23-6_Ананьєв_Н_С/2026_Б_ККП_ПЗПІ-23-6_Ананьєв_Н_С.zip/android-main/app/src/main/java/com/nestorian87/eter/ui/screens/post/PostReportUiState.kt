package com.nestorian87.eter.ui.screens.post

import com.nestorian87.eter.domain.model.ComplaintReasonItem

enum class ComplaintSubmitError { ALREADY_REPORTED, GENERIC }

data class PostReportUiState(
    val isVisible: Boolean = false,
    val isLoadingReasons: Boolean = false,
    val reasons: List<ComplaintReasonItem> = emptyList(),
    val reasonsError: Boolean = false,
    val selectedReasonKey: String? = null,
    val isSubmitting: Boolean = false,
    val isSuccess: Boolean = false,
    val submitError: ComplaintSubmitError? = null,
)
