package com.nestorian87.eter.domain.repository

import com.nestorian87.eter.domain.model.PostCommentDraft

interface PostCommentDraftRepository {
    suspend fun getDraft(postId: Long): PostCommentDraft?

    suspend fun saveDraft(draft: PostCommentDraft)

    suspend fun deleteDraft(postId: Long)
}
