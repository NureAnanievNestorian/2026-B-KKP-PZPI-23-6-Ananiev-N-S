package com.nestorian87.eter.ui.components.immersive

import android.util.Base64
import com.nestorian87.eter.domain.model.PostAudioAnalysis
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.sin

private val NumberRegex = Regex("[-+]?\\d*\\.?\\d+(?:[eE][-+]?\\d+)?")

internal fun PostAudioAnalysis.decodeVoiceAnalysis(): DecodedVoiceAnalysis? {
    val resolvedFrameMs = frameMs.coerceAtLeast(1)
    val stride = features.size.takeIf { it > 0 } ?: 6
    val expectedFrames =
        ceil(durationMs.toDouble() / resolvedFrameMs.toDouble()).toInt().coerceAtLeast(1)

    val parsed = parseFramesBase64(frames, features, stride, expectedFrames).ifEmpty {
        parseFramesText(frames, features, stride)
    }

    if (parsed.isEmpty()) return null
    return DecodedVoiceAnalysis(durationMs = durationMs, frameMs = resolvedFrameMs, frames = parsed)
}

private fun parseFramesText(raw: String, features: List<String>, stride: Int): List<VoiceFrame> {
    val looksTextual = raw.any {
        it == ',' || it == ';' || it == '[' || it == ']' || it == '|' || it == '\n' || it == '\t' || it == ' '
    }
    if (!looksTextual) return emptyList()
    val numbers = NumberRegex.findAll(raw).mapNotNull { it.value.toFloatOrNull() }.toList()
    if (numbers.size < stride) return emptyList()
    val maxValue = numbers.maxOrNull() ?: 1f
    val shouldNormalize = maxValue > 1.5f
    return numbers
        .chunked(stride)
        .filter { it.size >= stride }
        .map { row -> row.toVoiceFrame(features, shouldNormalize) }
}

private fun parseFramesBase64(
    raw: String,
    features: List<String>,
    stride: Int,
    expectedFrames: Int,
): List<VoiceFrame> {
    val clean = raw.trim()
    if (clean.isEmpty()) return emptyList()
    val decoded =
        runCatching { Base64.decode(clean, Base64.DEFAULT) }.getOrNull() ?: return emptyList()
    if (decoded.size < stride) return emptyList()
    val usableFrames = minOf(decoded.size / stride, expectedFrames)
    if (usableFrames <= 0) return emptyList()
    return List(usableFrames) { frameIndex ->
        val offset = frameIndex * stride
        List(stride) { featureIndex ->
            (decoded[offset + featureIndex].toInt() and 0xFF) / 255f
        }.toVoiceFrame(features, normalizeByteRange = false)
    }
}

private fun List<Float>.toVoiceFrame(
    features: List<String>,
    normalizeByteRange: Boolean
): VoiceFrame {
    fun valueOf(vararg aliases: String, fallbackIndex: Int): Float {
        val index = aliases
            .map { alias -> features.indexOfFirst { it.equals(alias, ignoreCase = true) } }
            .firstOrNull { it >= 0 } ?: fallbackIndex
        val raw = getOrNull(index) ?: 0f
        return (if (normalizeByteRange) raw / 255f else raw).coerceIn(0f, 1f)
    }

    return VoiceFrame(
        energy = valueOf("energy", "rms", "volume", fallbackIndex = 0),
        peak = valueOf("peak", "transient", fallbackIndex = 1),
        low = valueOf("low", "bass", fallbackIndex = 2),
        mid = valueOf("mid", "middle", fallbackIndex = 3),
        high = valueOf("high", "treble", fallbackIndex = 4),
        zcr = valueOf("zcr", "zeroCrossingRate", "zero_crossing_rate", fallbackIndex = 5),
    )
}

internal fun DecodedVoiceAnalysis.readFrameAt(timeMs: Long): VoiceFrame {
    if (frames.isEmpty()) return VoiceFrame()
    val position = (timeMs.coerceAtLeast(0).toFloat() / frameMs.toFloat()).coerceAtLeast(0f)
    val leftIndex = floor(position).toInt().coerceIn(0, frames.lastIndex)
    val rightIndex = (leftIndex + 1).coerceAtMost(frames.lastIndex)
    val t = (position - leftIndex).coerceIn(0f, 1f)
    return frames[leftIndex].lerpTo(frames[rightIndex], t)
}

internal fun PostAudioAnalysis.accentAt(timeMs: Long): Float {
    if (accents.isEmpty()) return 0f
    var strength = 0f
    accents.forEach { accent ->
        val distance = abs(accent.timestampMs - timeMs).toFloat()
        if (distance <= AccentDecayWindowMs) {
            val factor = 1f - distance / AccentDecayWindowMs
            strength = max(strength, accent.intensity.coerceIn(0f, 1f) * factor)
        }
    }
    return strength.coerceIn(0f, 1f)
}

internal fun PostAudioAnalysis.isSilenceAt(timeMs: Long): Boolean =
    silences.any { silence -> timeMs in silence.startMs..silence.endMs }

internal fun proceduralFrame(timeMs: Float, isPlaying: Boolean): VoiceFrame {
    val t = timeMs / 1000f
    if (!isPlaying) {
        return VoiceFrame(
            energy = 0.08f + sin(t * 0.7f).positive() * 0.04f,
            peak = 0.05f,
            low = 0.10f + sin(t * 0.45f).positive() * 0.05f,
            mid = 0.07f + sin(t * 0.62f + 1.2f).positive() * 0.04f,
            high = 0.05f + sin(t * 0.82f + 2.1f).positive() * 0.035f,
            zcr = 0.04f,
        )
    }

    val low = 0.18f + sin(t * 1.15f).positive() * 0.34f + sin(t * 0.37f + 0.8f).positive() * 0.10f
    val mid = 0.14f + sin(t * 1.9f + 1.1f).positive() * 0.38f + sin(t * 0.71f).positive() * 0.08f
    val high = 0.10f + sin(t * 2.8f + 2.3f).positive() * 0.30f + sin(t * 6.1f).positive() * 0.08f
    val beat = if ((timeMs % 1280f) < 110f) 0.42f else 0f
    val phrase = sin(t * 0.21f).positive() * 0.18f
    val energy = (low * 0.38f + mid * 0.36f + high * 0.26f + beat + phrase).coerceIn(0f, 1f)
    return VoiceFrame(
        energy = energy,
        peak = (beat + energy * 0.45f).coerceIn(0f, 1f),
        low = low.coerceIn(0f, 1f),
        mid = mid.coerceIn(0f, 1f),
        high = high.coerceIn(0f, 1f),
        zcr = (0.08f + high * 0.42f).coerceIn(0f, 1f),
    )
}

internal fun VoiceFrame.withPulse(pulse: Float): VoiceFrame = copy(
    peak = max(peak, pulse),
    energy = max(energy, pulse * 0.72f),
)

internal fun VoiceFrame.towards(target: VoiceFrame): VoiceFrame = VoiceFrame(
    energy = smooth(energy, target.energy, 0.13f, 0.07f),
    low = smooth(low, target.low, 0.10f, 0.055f),
    mid = smooth(mid, target.mid, 0.14f, 0.07f),
    high = smooth(high, target.high, 0.11f, 0.055f),
    zcr = smooth(zcr, target.zcr, 0.10f, 0.05f),
    peak = smooth(peak, target.peak, 0.30f, 0.065f),
)

private fun VoiceFrame.lerpTo(other: VoiceFrame, t: Float): VoiceFrame = VoiceFrame(
    energy = energy + (other.energy - energy) * t,
    peak = peak + (other.peak - peak) * t,
    low = low + (other.low - low) * t,
    mid = mid + (other.mid - mid) * t,
    high = high + (other.high - high) * t,
    zcr = zcr + (other.zcr - zcr) * t,
)

private fun smooth(current: Float, next: Float, attack: Float, release: Float): Float {
    val speed = if (next > current) attack else release
    return current + (next - current) * speed
}

internal fun accentFor(timeMs: Float, isPlaying: Boolean): Float {
    if (!isPlaying) return 0f
    val local = (timeMs % 1280f) / 1280f
    return if (local < 0.42f) (1f - local / 0.42f).coerceIn(0f, 1f) else 0f
}

private fun Float.positive(): Float = ((this + 1f) / 2f).coerceIn(0f, 1f)
