package com.nestorian87.eter.data.mapper

import com.nestorian87.eter.data.remote.dto.NotificationActorDto
import com.nestorian87.eter.data.remote.dto.NotificationItemDto
import com.nestorian87.eter.data.remote.dto.NotificationTargetRoutePayloadDto
import com.nestorian87.eter.data.remote.dto.NotificationsCountsResponseDto
import com.nestorian87.eter.data.remote.dto.NotificationsPageResponseDto
import com.nestorian87.eter.data.remote.dto.PushNotificationSettingsDto
import com.nestorian87.eter.data.remote.dto.UpdatePushNotificationSettingsResponseDto
import com.nestorian87.eter.domain.model.NotificationActor
import com.nestorian87.eter.domain.model.NotificationCounts
import com.nestorian87.eter.domain.model.NotificationItem
import com.nestorian87.eter.domain.model.NotificationTargetRoutePayload
import com.nestorian87.eter.domain.model.NotificationType
import com.nestorian87.eter.domain.model.NotificationsPage
import com.nestorian87.eter.domain.model.PushNotificationSettings

fun NotificationsPageResponseDto.toDomain(): NotificationsPage = NotificationsPage(
    items = items.map(NotificationItemDto::toDomain),
    limit = limit,
    nextCursor = nextCursor,
    hasMore = hasMore,
    unreadCount = unreadCount,
    unseenCount = unseenCount,
)

fun NotificationsCountsResponseDto.toDomain(): NotificationCounts = NotificationCounts(
    unreadCount = unreadCount,
    unseenCount = unseenCount,
)

fun PushNotificationSettingsDto.toDomain(): PushNotificationSettings = PushNotificationSettings(
    disabledTypes = disabledTypes.map(String::toNotificationType)
        .filterNot { it == NotificationType.UNKNOWN }
        .toSet(),
)

fun UpdatePushNotificationSettingsResponseDto.toDomain(): PushNotificationSettings =
    PushNotificationSettings(
        disabledTypes = disabledTypes.map(String::toNotificationType)
            .filterNot { it == NotificationType.UNKNOWN }
            .toSet(),
    )

fun NotificationItemDto.toDomain(): NotificationItem = NotificationItem(
    notificationId = notificationId,
    notificationType = notificationType.toNotificationType(),
    eventsCount = eventsCount,
    isRead = isRead,
    isSeen = isSeen,
    postId = postId,
    postSlug = postSlug,
    postTitle = postTitle,
    commentId = commentId,
    postComplaintId = postComplaintId,
    previewText = previewText,
    commentPreviewText = commentPreviewText,
    replyPreviewText = replyPreviewText,
    targetType = targetType,
    targetLabel = targetLabel,
    targetRoutePayload = targetRoutePayload?.toDomain(),
    lastEventAt = lastEventAt,
    createdAt = createdAt,
    readAt = readAt,
    seenAt = seenAt,
    lastActor = lastActor?.toDomain(),
)

fun NotificationTargetRoutePayloadDto.toDomain(): NotificationTargetRoutePayload =
    NotificationTargetRoutePayload(
        postId = postId,
        postSlug = postSlug,
        commentId = commentId,
        postComplaintId = postComplaintId,
        username = username,
    )

fun NotificationActorDto.toDomain(): NotificationActor = NotificationActor(
    userId = userId,
    name = name,
    username = username,
    photo = photo,
    isPremium = isPremium,
)

fun NotificationType.toApiValue(): String = when (this) {
    NotificationType.POST_LIKED -> "post_liked"
    NotificationType.POST_COMMENTED -> "post_commented"
    NotificationType.COMMENT_REPLIED -> "comment_replied"
    NotificationType.COMMENT_LIKED -> "comment_liked"
    NotificationType.USER_FOLLOWED -> "user_followed"
    NotificationType.POST_VIOLATION_CONFIRMED -> "post_violation_confirmed"
    NotificationType.UNKNOWN -> "unknown"
}

private fun String.toNotificationType(): NotificationType = when (lowercase()) {
    "post_liked" -> NotificationType.POST_LIKED
    "post_commented" -> NotificationType.POST_COMMENTED
    "comment_replied" -> NotificationType.COMMENT_REPLIED
    "comment_liked" -> NotificationType.COMMENT_LIKED
    "user_followed" -> NotificationType.USER_FOLLOWED
    "post_violation_confirmed" -> NotificationType.POST_VIOLATION_CONFIRMED
    else -> NotificationType.UNKNOWN
}
