package com.nestorian87.eter.service

import android.net.Uri
import android.os.Bundle
import com.nestorian87.eter.ui.navigation.EterDeepLink
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive

internal object PushNotificationNavigation {
    private const val KEY_NOTIFICATION = "notification"
    private const val KEY_POST_ID = "postId"
    private const val KEY_COMMENT_ID = "commentId"
    private const val KEY_USERNAME = "username"

    private val json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
        isLenient = true
    }

    fun targetRoute(data: Map<String, String>): TargetRoute? {
        val directPostId = data[KEY_POST_ID]?.toLongOrNull()
        val directCommentId = data[KEY_COMMENT_ID]?.toLongOrNull()
        if (directPostId != null) {
            return TargetRoute.Post(
                postId = directPostId,
                focusComments = directCommentId != null,
            )
        }

        val directUsername = data[KEY_USERNAME]?.trim()?.takeIf { it.isNotEmpty() }
        if (directUsername != null) {
            return TargetRoute.Profile(username = directUsername)
        }

        val notificationJson = data[KEY_NOTIFICATION].orEmpty().trim()
        if (notificationJson.isEmpty()) {
            return null
        }

        val rootElement =
            runCatching { json.parseToJsonElement(notificationJson) }.getOrNull() ?: return null
        val postId = findLong(rootElement, KEY_POST_ID)
        val commentId = findLong(rootElement, KEY_COMMENT_ID)
        if (postId != null) {
            return TargetRoute.Post(
                postId = postId,
                focusComments = commentId != null,
            )
        }

        val username = findString(rootElement, KEY_USERNAME)
        if (username != null) {
            return TargetRoute.Profile(username = username)
        }

        return null
    }

    fun targetRouteValues(data: Map<String, *>): TargetRoute? = targetRoute(data.toStringMap())

    fun targetUri(data: Map<String, String>): Uri? {
        return when (val route = targetRoute(data)) {
            is TargetRoute.Post -> EterDeepLink.postUri(
                postId = route.postId,
                focusComments = route.focusComments,
            )

            is TargetRoute.Profile -> EterDeepLink.profileUri(route.username)
            null -> null
        }
    }

    fun targetUri(extras: Bundle?): Uri? = targetUriValues(extras.toValueMap())

    fun targetUriValues(data: Map<String, *>): Uri? = targetUri(data.toStringMap())

    private fun Bundle?.toValueMap(): Map<String, Any?> {
        if (this == null) {
            return emptyMap()
        }
        return keySet().associateWith { key -> get(key) }
    }

    private fun Map<String, *>.toStringMap(): Map<String, String> =
        entries.mapNotNull { (key, value) ->
            when (value) {
                null -> null
                is String -> key to value
                is Number -> key to value.toString()
                is Boolean -> key to value.toString()
                else -> null
            }
        }.toMap()

    private fun findLong(element: JsonElement, key: String): Long? = when (element) {
        is JsonObject -> {
            element[key]?.jsonPrimitive?.contentOrNull?.toLongOrNull()
                ?: element.values.firstNotNullOfOrNull { child -> findLong(child, key) }
        }

        is JsonArray -> element.firstNotNullOfOrNull { child -> findLong(child, key) }
        is JsonPrimitive -> null
    }

    private fun findString(element: JsonElement, key: String): String? = when (element) {
        is JsonObject -> {
            element[key]?.jsonPrimitive?.contentOrNull?.trim()?.takeIf { it.isNotEmpty() }
                ?: element.values.firstNotNullOfOrNull { child -> findString(child, key) }
        }

        is JsonArray -> element.firstNotNullOfOrNull { child -> findString(child, key) }
        is JsonPrimitive -> null
    }

    sealed interface TargetRoute {
        data class Post(
            val postId: Long,
            val focusComments: Boolean,
        ) : TargetRoute

        data class Profile(
            val username: String,
        ) : TargetRoute
    }
}
