package com.nestorian87.eter.domain.repository

import com.nestorian87.eter.domain.model.NotificationCounts
import com.nestorian87.eter.domain.model.NotificationRealtimeEvent
import com.nestorian87.eter.domain.model.NotificationType
import com.nestorian87.eter.domain.model.NotificationsPage
import com.nestorian87.eter.domain.model.NotificationsQuery
import com.nestorian87.eter.domain.model.PushNotificationSettings
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

interface NotificationRepository {
    val counts: StateFlow<NotificationCounts>
    val events: SharedFlow<NotificationRealtimeEvent>

    suspend fun getNotifications(query: NotificationsQuery = NotificationsQuery()): NotificationsPage

    suspend fun getPushSettings(): PushNotificationSettings

    suspend fun updatePushSettings(disabledTypes: Set<NotificationType>): PushNotificationSettings

    suspend fun markAllSeen(): NotificationCounts

    suspend fun markSeen(notificationId: Long): NotificationCounts

    suspend fun markRead(notificationId: Long)

    suspend fun markAllRead()
}
