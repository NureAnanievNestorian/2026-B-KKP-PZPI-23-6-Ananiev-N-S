package com.nestorian87.eter.domain.util

import java.io.File
import java.net.URLConnection

object ProfileAvatarUpload {
    fun detectMediaType(file: File): String {
        val mediaTypeFromName = URLConnection.guessContentTypeFromName(file.name)
            ?.takeIf(::isSupportedImageType)
        if (mediaTypeFromName != null) {
            return mediaTypeFromName
        }

        return file.inputStream().use { input ->
            val header = ByteArray(HEADER_BYTE_COUNT)
            val bytesRead = input.read(header)
            detectMediaType(header.copyOf(bytesRead.coerceAtLeast(0))) ?: DEFAULT_MEDIA_TYPE
        }
    }

    fun resolveFileSuffix(
        contentType: String?,
        displayName: String?,
    ): String {
        extensionForContentType(contentType)?.let { return it }
        extensionFromDisplayName(displayName)?.let { return it }
        return DEFAULT_FILE_SUFFIX
    }

    internal fun detectMediaType(headerBytes: ByteArray): String? = when {
        headerBytes.isJpeg() -> JPEG_MEDIA_TYPE
        headerBytes.isPng() -> PNG_MEDIA_TYPE
        headerBytes.isWebp() -> WEBP_MEDIA_TYPE
        else -> null
    }

    private fun extensionForContentType(contentType: String?): String? =
        when (contentType?.lowercase()) {
            JPEG_MEDIA_TYPE -> ".jpg"
            PNG_MEDIA_TYPE -> ".png"
            WEBP_MEDIA_TYPE -> ".webp"
            else -> null
        }

    private fun extensionFromDisplayName(displayName: String?): String? {
        val extension = displayName
            ?.substringAfterLast('.', missingDelimiterValue = "")
            ?.lowercase()
            ?.takeIf { it.isNotBlank() }

        return when (extension) {
            "jpg", "jpeg" -> ".jpg"
            "png" -> ".png"
            "webp" -> ".webp"
            else -> null
        }
    }

    private fun isSupportedImageType(mediaType: String): Boolean = mediaType in supportedMediaTypes

    private fun ByteArray.isJpeg(): Boolean = size >= 3 &&
            this[0] == 0xFF.toByte() &&
            this[1] == 0xD8.toByte() &&
            this[2] == 0xFF.toByte()

    private fun ByteArray.isPng(): Boolean = size >= 8 &&
            this[0] == 0x89.toByte() &&
            this[1] == 0x50.toByte() &&
            this[2] == 0x4E.toByte() &&
            this[3] == 0x47.toByte() &&
            this[4] == 0x0D.toByte() &&
            this[5] == 0x0A.toByte() &&
            this[6] == 0x1A.toByte() &&
            this[7] == 0x0A.toByte()

    private fun ByteArray.isWebp(): Boolean = size >= 12 &&
            this[0] == 'R'.code.toByte() &&
            this[1] == 'I'.code.toByte() &&
            this[2] == 'F'.code.toByte() &&
            this[3] == 'F'.code.toByte() &&
            this[8] == 'W'.code.toByte() &&
            this[9] == 'E'.code.toByte() &&
            this[10] == 'B'.code.toByte() &&
            this[11] == 'P'.code.toByte()

    private const val JPEG_MEDIA_TYPE = "image/jpeg"
    private const val PNG_MEDIA_TYPE = "image/png"
    private const val WEBP_MEDIA_TYPE = "image/webp"
    private val supportedMediaTypes = setOf(
        JPEG_MEDIA_TYPE,
        PNG_MEDIA_TYPE,
        WEBP_MEDIA_TYPE,
    )

    private const val HEADER_BYTE_COUNT = 12
    private const val DEFAULT_FILE_SUFFIX = ".tmp"
    const val DEFAULT_MEDIA_TYPE: String = "application/octet-stream"
}
